-- HealthWarning
-- By Szandos
-- Flashes the edges of the screen when you get low on health
	
-- Create a frame to hold the texture
local f = CreateFrame("Frame", "HealthWarningFrame", UIParent)
f:SetFrameStrata("BACKGROUND")
f:SetAllPoints() 
f:Hide()
local flashing = false

-- Create a texture for the flash effect
local t = f:CreateTexture(nil,"BACKGROUND")
t:SetTexture("Interface\\FullScreenTextures\\LowHealth")
t:SetBlendMode("ADD")
t:SetAllPoints(f)
f.texture = t

-- Animation for the flashing
local HealthWarningFrameAnimationGroup = HealthWarningFrame:CreateAnimationGroup()
local faderOut = HealthWarningFrameAnimationGroup:CreateAnimation("Alpha")
faderOut:SetChange(-1)
faderOut:SetDuration(0.3)
faderOut:SetOrder(1)
local faderIn = HealthWarningFrameAnimationGroup:CreateAnimation("Alpha")
faderIn:SetChange(1)
faderIn:SetDuration(0.3)
faderIn:SetOrder(2)
HealthWarningFrameAnimationGroup:SetScript("OnFinished", function(self) self:Play() end)
HealthWarningFrameAnimationGroup:Play()

-- Frame to catch events
local HealthWarning_eventFrame = CreateFrame("Frame")
HealthWarning_eventFrame:RegisterEvent("VARIABLES_LOADED")
HealthWarning_eventFrame:SetScript("OnEvent",function(self,event,...) self[event](self,event,...);end)
HealthWarning_eventFrame:SetScript("OnUpdate", function(self, elapsed) HealthWarning_OnUpdate(self, elapsed) end)

-- OnUpdate: Start/Stop flashing
function HealthWarning_OnUpdate()
	if UnitIsDeadOrGhost("player") then
		if flashing then
			flashing = false
			f:Hide()
		end
	else
		local lowHealth = (UnitHealth("player")/UnitHealthMax("player") < HealthWarningDB["treshold"] / 100)
		if lowHealth and not flashing then
			flashing = true
			f:Show()
		elseif not lowHealth and flashing then
			flashing = false
			f:Hide()
		end
	end
end

-- VARIABLE_LOADED: Prepare SavedVariables
function HealthWarning_eventFrame:VARIABLES_LOADED()
	if (not HealthWarningDB) then
		HealthWarningDB = {}
		HealthWarningDB["treshold"] = 20
	end
end

-- Create slash command
SLASH_HEALTHWARNING1 = "/healthwarning"
SLASH_HEALTHWARNING2 = "/hw"
local color = "|cff00ffff"

-- Handle slash commands
function SlashCmdList.HEALTHWARNING(msg)
	local newTreshold = tonumber(msg)
	if not newTreshold or newTreshold < 0 or newTreshold > 100 then
		DEFAULT_CHAT_FRAME:AddMessage(color.."HealthWarning by Szandos")
		DEFAULT_CHAT_FRAME:AddMessage(color.."Usage:")
		DEFAULT_CHAT_FRAME:AddMessage(color.."/hw <treshold> - Sets the warning treshold in percent")
		DEFAULT_CHAT_FRAME:AddMessage(color.."Example: \"/hw 20\" - Sets the treshold to 20% health")
		DEFAULT_CHAT_FRAME:AddMessage(color.."Current treshold: "..HealthWarningDB["treshold"].."%")
	else
		DEFAULT_CHAT_FRAME:AddMessage(color.."HealthWarning by Szandos")
		DEFAULT_CHAT_FRAME:AddMessage(color.."New treshold set to "..newTreshold.."%")
		HealthWarningDB["treshold"] = newTreshold
	end
end