GLDG_HelpText = "Not yet available"

if (GetLocale() == "deDE") then
	GLDG_HelpText = "Noch nicht verf�gbar"
end
