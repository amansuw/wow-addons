﻿ExtraCD = LibStub("AceAddon-3.0"):NewAddon("ExtraCD", "AceEvent-3.0","AceConsole-3.0","AceTimer-3.0")

local AceConfigDialog = LibStub("AceConfigDialog-3.0")
local AceConfig = LibStub("AceConfig-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("ExtraCD")
local LSM = LibStub("LibSharedMedia-3.0")
local mod = ExtraCD
local tinsert , tremove = table.insert , table.remove
local tonumber = tonumber
local ECD_TEXT="ExtraCD"
local ECD_VERSION= " v0.9.6"
local ECD_AUTHOR=" by superk"
local ecddb
local bars = {}
local active = {}
local talents
local items 
local itemset
local enchants
local equippedItems = {}
local cdcache = {}
local cdreset

local dbDefaults = {
	profile = {
		Position = nil,
		talent = true,
		enchant = true,
		item = true,
		itemset = true,
		lock = false,
		combat = false,
		glow = true,
		tip = true,
		showtext = true,
		textsize = 12,
		iconsize = 25,
		textfont = "Friz Quadrata TT",
		iconborder = "Blizzard Tooltip",
		iconinterval = 4,
		rowmax = 10,
		blacklist = {},
	}	
}

local events = {
	["SPELL_DAMAGE"] = true,
	["SPELL_PERIODIC_HEAL"] = true,
	["SPELL_HEAL"] = true,
	["SPELL_AURA_APPLIED"] = true,
	["SPELL_ENERGIZE"] = true,
	["SPELL_CAST_SUCCESS"] = true,
	["SPELL_CAST_START"] = true, -- for early frost
	["SPELL_SUMMON"] = true, -- for t12 2p
}
local function setOption(info, value)
	local name = info[#info]
	ecddb[name] = value
	mod:ResetAllIcons()
end

local function getOption(info)
	local name = info[#info]
	return ecddb[name]
end
function mod:OnInitialize()
	if not talents then talents = self:GetTalents() end
	if not items then items = self:GetItems() itemset = self:GetItemSet() end
	if not itemset then itemset = self:GetItemSet() end
	if not enchants then enchants = self:GetEnchants() end
	if not cdreset then cdreset = self:GetCDReset() end
	self.db1 = LibStub("AceDB-3.0"):New("ExtraCDDB",dbDefaults, "Default");
	--DEFAULT_CHAT_FRAME:AddMessage(ECD_TEXT .. ECD_VERSION .. ECD_AUTHOR .."  - /ecd ");
	self:RegisterChatCommand("ExtraCD", function() InterfaceOptionsFrame_OpenToCategory(GetAddOnMetadata("ExtraCD", "Title")) end)
	self:RegisterChatCommand("ecd", function() InterfaceOptionsFrame_OpenToCategory(GetAddOnMetadata("ExtraCD", "Title")) end)
	self.db1.RegisterCallback(self, "OnProfileChanged", "ChangeProfile")
	self.db1.RegisterCallback(self, "OnProfileCopied", "ChangeProfile")
	self.db1.RegisterCallback(self, "OnProfileReset", "ChangeProfile")
	ecddb = self.db1.profile
	self.options = {
		type = "group",
		name = GetAddOnMetadata("ExtraCD", "Title"),
		args = {
			general = {
				type = "group",
				name = "",
				get = getOption,
				set = setOption,
				order = 1,
				inline = true,
				args = {
					ecddesc = {
						type = "description",
						order = 0,
						name = GetAddOnMetadata("ExtraCD", "Notes"),
					},
					talent = {
						name = L["Talent icd"],
						desc = L["Scan and show internal cooldown of player's talent."],
						type = "toggle",
						order = 100,
						width = "full",
					},
					enchant = {
						name = L["Enchant icd"],
						desc = L["Scan and show internal cooldown of player's enchant."],
						type = "toggle",
						order = 200,
						width = "full",
					},
					item = {
						name = L["Trinket icd"],
						desc = L["Scan and show internal cooldown of player's trinket."],
						type = "toggle",
						order = 300,
						width = "full",
					},
					itemset = {
						name = L["Item Set icd"],
						desc = L["Scan and show internal cooldown of player's item set."],
						type = "toggle",
						order = 301,
						width = "full",
					},
					lock = {
						name = L["Lock frame"],
						desc = L["Set the frame locked."],
						type = "toggle",
						order = 305,
						width = "full",
					},
					combat = {
						name = L["Combat only"],
						desc = L["Show the icon only in combat."],
						type = "toggle",
						order = 306,
						width = "full",
					},
					glow = {
						name = L["Show glow"],
						desc = L["Show glow around the icon not cooldowns."],
						type = "toggle",
						order = 308,
						width = "full",
					},
					tip = {
						name = L["Show tooltip"],
						desc = L["Show tooltip for the icons."],
						type = "toggle",
						order = 309,
						width = "full",
					},
					rowmax = {
						name = L["Icons each row"],
						desc = L["Set the icons in each row"],
						type = "range",
						max = 20,
						min = 1,
						step = 1,
						order = 333,
					},
					showtext = {
						name = L["Cooldown text"],
						desc = L["Show or hide the cooldown text."],
						type = "toggle",
						order = 310,
					},
					NewLine1 = {
						type= 'description',
						order = 311,
						name= '',
						width = "full",
					},
					NewLine2 = {
						type= 'description',
						order = 322,
						name= '',
						width = "full",
					},
					NewLine3 = {
						type= 'description',
						order = 331,
						name= '',
						width = "full",
					},
					NewLine4 = {
						type= 'description',
						order = 345,
						name= '',
						width = "full",
					},
					textsize = {
						name = L["Text size"],
						desc = L["Set the cooldown text size"],
						type = "range",
						max = 30,
						min = 12,
						step = 1,
						order = 320,
						disabled = function() return not ecddb.showtext end,						
					},
					textfont = {
						name = L["Text font"],
						desc = L["Set the font of the text"],
						type = "select",
						dialogControl = 'LSM30_Font',
						values = LSM:HashTable("font"),
						order = 321,
					},
					iconinterval = {
						name = L["Icon interval"],
						desc = L["Set the interval size between icons"],
						type ="range",
						max = 20,
						min = 0,
						step = 1,
						order = 323,
					},
					iconsize = {
						name = L["Icon size"],
						desc = L["Set the icon size"],
						type = "range",
						max = 60,
						min = 1,
						step = 1,
						order = 330,					
					},
					blacklist = {
						name = L["Blacklist"],
						desc = L["When you crtl+right click at the icon, it will be added in the blacklist. And select any item in this list will remove it from list and show it again."],
						type = "select",
						values = ecddb.blacklist,
						get = function() return false end,
						set = function(info , value)  ecddb.blacklist[value] = nil mod:ResetAllIcons() end, 
						order = 350,
					},
					iconborder = {
						name = L["Icon border"],
						desc = L["Set the icon border"],
						type = "select",
						dialogControl = 'LSM30_Border',
						values = LSM:HashTable("border"),
						order = 340,
					},
					
				}
			},
		},
	}
	self.options.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db1)
	LibStub("AceConfig-3.0"):RegisterOptionsTable("ExtraCD", ExtraCD.options)
	AceConfigDialog:AddToBlizOptions("ExtraCD", GetAddOnMetadata("ExtraCD", "Title"), nil, "general")
	AceConfigDialog:AddToBlizOptions("ExtraCD", L["Profiles"], "ExtraCD", "profiles")
end
function mod:OnEnable()
	self:RegisterEvent("PLAYER_ENTERING_WORLD")
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	self:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED","OnTalentChanged")
	self:RegisterEvent("PLAYER_TALENT_UPDATE","OnTalentChanged")
	self:RegisterEvent("UNIT_INVENTORY_CHANGED","OnInventoryChanged")
	self:RegisterEvent("PLAYER_REGEN_DISABLED","EnterCombat")
	self:RegisterEvent("PLAYER_REGEN_ENABLED","LeaveCombat")
	self.bar = self:CreateBar()
	self:LoadPosition()
	if ecddb.talent then self:ScanPlayerTalent() end
	if ecddb.enchant then self:ScanPlayerEnchant() end
	if ecddb.item then self:ScanPlayerItem() end
	if ecddb.itemset then self:ScanPlayerItemSet() end
	self:AddIcon(self.bar)
end
function mod:OnDisable()

end

function mod:ChangeProfile()
	ecddb = self.db1.profile
end
function mod:AddOption(key, table)
	self.options.args[key] = table
	AceConfigDialog:AddToBlizOptions("ExtraCD", L[key], "ExtraCD", key)
end

function mod:CreateBar()
	local bar = CreateFrame("Frame", nil, UIParent)
	bar:SetMovable(true)
	bar:SetWidth(120)
	bar:SetHeight(30)
	bar:SetClampedToScreen(true)
	bar:EnableMouse(false)
	--bar:SetScript("OnMouseDown",function(self,button) if button == "LeftButton" and bar:IsMovable() then self:StartMoving() end end)
	--bar:SetScript("OnMouseUp",function(self,button) if button == "LeftButton" and bar:IsMovable() then self:StopMovingOrSizing() ExtraCD:SavePosition() end end)
	bar:Show()
	return bar
end
function mod:LoadPosition()
	if ecddb.Position then
		self.bar:SetPoint(ecddb.Position.point,UIParent,ecddb.Position.relativePoint,ecddb.Position.xOfs,ecddb.Position.yOfs)
	else
		self.bar:SetPoint("CENTER", UIParent, "CENTER")
	end
end
function mod:SavePosition()
	local point, _, relativePoint, xOfs, yOfs = self.bar:GetPoint()
	if not ecddb.Position then 
		ecddb.Position = {}
	end
	ecddb.Position.point = point
	ecddb.Position.relativePoint = relativePoint
	ecddb.Position.xOfs = xOfs
	ecddb.Position.yOfs = yOfs
end
function mod:AddIcon(bar)
	local inCombat = UnitAffectingCombat("player")
	if ecddb.lock then bar:SetMovable(false) else bar:SetMovable(true) end
	if ecddb.combat and not inCombat then bar:Hide() else bar:Show() end
	for k,_ in pairs (active) do
		self:CreateIcon (k,bar)
	end
end
function mod:CreateIcon(order,bar)
	local isize = ecddb.iconsize or 30
	local fsize = ecddb.textsize or 12 
	local btn = CreateFrame("Button",nil,bar)
	btn:EnableMouse(true)
	btn:RegisterForClicks("AnyUp", "AnyDown")
	btn:SetWidth(isize)
	btn:SetHeight(isize)
	local row = math.ceil(order / ecddb.rowmax) - 1
	if (order - 1) % ecddb.rowmax == 0 then 
		btn:SetPoint("TOPLEFT",bar,0, -(isize + ecddb.iconinterval) * row )
	else
		btn:SetPoint("TOPLEFT",bar[order-1],isize + ecddb.iconinterval, 0)
	end
	--btn:SetFrameStrata("LOW")
	btn:Show()
	local cd = CreateFrame("Cooldown",nil,btn)
	cd.noomnicc = true
	cd.noCooldownCount = true
	cd:SetAllPoints(btn)
	--cd:SetFrameStrata("MEDIUM")
	cd:Hide()
	--[[local texture = btn:CreateTexture(nil,"BACKGROUND")
	texture:SetAllPoints(btn)
	texture:SetTexture(active[order].icon)
	texture:SetTexCoord(0.07,0.9,0.07,0.90)
	texture:Show()]]
	local backdrop = {
		-- path to the background texture
		bgFile = active[order].icon,  
		-- path to the border texture
		edgeFile = LSM:Fetch("border", ecddb.iconborder),
		-- true to repeat the background texture to fill the frame, false to scale it
		-- tile = true,
		-- size (width or height) of the square repeating background tiles (in pixels)
		tileSize = isize + 2,
		-- thickness of edge segments and square size of edge corners (in pixels)
		edgeSize = 0.3*isize,
		-- distance from the edges of the frame to those of the background texture (in pixels)
		--[[ insets = {
			left = 12,
			right = 12,
			top = 12,
			bottom =12
		}]]
	}
	btn:SetBackdrop(backdrop)
	--[[border:SetTexture(ecddb.iconborder)
	border:SetTexCoord(1,1,1,0.6)
	border:Show()]]
	local text = cd:CreateFontString(nil,"ARTWORK")
	text:SetFont(LSM:Fetch("font", ecddb.textfont) or STANDARD_TEXT_FONT,fsize,"OUTLINE")
	text:SetTextColor(1,1,0,1)
	text:SetPoint("CENTER",btn,"CENTER",0,0)
	local overlay = CreateFrame("Frame", nil, btn, "ActionBarButtonSpellActivationAlert")
	overlay:SetPoint("TOPLEFT", btn, "TOPLEFT", -isize * 0.4, isize * 0.4)
	overlay:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", isize * 0.4, -isize * 0.4);
	if ecddb.glow then overlay.animIn:Play() end
	-- btn.texture = texture
	btn.backrop = backdrop
	btn.text = text
	btn.cd = cd
	-- btn.border = border
	btn.cooldown = active[order].cd
	btn.duration = active[order].duration
	btn.link = GetSpellLink(active[order].id)
	btn.overlay = overlay
	btn.order = order
	bar[order] = btn
	if ecddb.tip then 
		btn:SetScript("OnEnter",function(self,motion)
			if self.link then
				GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
				GameTooltip:SetHyperlink(self.link)
				GameTooltip:Show()
			end 
		end)
		btn:SetScript("OnLeave",function(self,motion)
			GameTooltip:Hide() 
		end)
	end
	btn:SetScript("OnMouseDown",function(self,button) if button == "LeftButton" and bar:IsMovable() then bar:StartMoving() end end)
	btn:SetScript("OnMouseUp",function(self,button) if button == "LeftButton" and bar:IsMovable() then bar:StopMovingOrSizing() mod:SavePosition() end end)
	btn:SetScript("OnClick",function(self,button) if button == "RightButton" and IsControlKeyDown() then local name = GetSpellInfo(active[order].id) rawset (ecddb.blacklist,active[order].id, name) mod:ResetAllIcons() end end)
end
function mod:ScanPlayerTalent()
	local _,class = UnitClass ("player")
	for k, v in pairs(talents) do 
		if not ecddb.blacklist[k] then
			if v[1] == class then
				local _,icon,_,_,rank = GetTalentInfo(v[2],v[3])
				if rank ~= 0 then
					if type(k) == "table" then k = k[rank] end
					if not ecddb.blacklist[k] then
						if type(v[4]) == "table" then v[4] = v[4][rank] end
						if type(v[5]) == "table" then v[5] = v[5][rank] end
						tinsert (active, {cd = v[4] , icon = icon, id = k, type = "talent", duration = v[5] or 0 } )
					end
				end
			end
		end
	end
end
function mod:ScanPlayerEnchant()
	for k,v in pairs(enchants) do
		if not ecddb.blacklist[k] then
			local link = GetInventoryItemLink("player", v[2])
			if link then
				local itemID, enchant = link:match("item:(%d+):(%d+)")
				if tonumber(enchant or -1) == v[1] then
					--local icon = GetItemIcon(tonumber(itemID))
					local _,_,icon = GetSpellInfo(k)
					tinsert (active, {cd = v[3] or 45 , icon = icon, id = k, type = "enchant", eid = enchant, duration = v[4] or 0} ) 
				end
			end
		end
	end
end
function mod:ScanPlayerItem()
	local link1 = GetInventoryItemLink("player", 13)
	local link2 = GetInventoryItemLink("player", 14)
	local link3 = GetInventoryItemLink("player", 16)
	local trinket1
	local trinket2
	local waepon1
	if link1 then trinket1 = link1:match("item:(%d+)") end
	if link2 then trinket2 = link2:match("item:(%d+)") end
	if link3 then weapon1 = link3:match("item:(%d+)") end
	for k,v in pairs(items) do
		k = math.floor(k)
		if not ecddb.blacklist[k] then
			if type(v[1]) == "table" then
				local fg = UnitFactionGroup("player")
				if fg == "Horde" then v[1] = v[1][1] else v[1] = v[1][2] end
			end
			if tonumber(trinket1 or -1) == v[1] then
				local icon = GetItemIcon(v[1])
				tinsert (active, {cd = v[2] or 45, icon = icon, id = k, type = "item", slot = 13, duration = v[3] or 0} ) 
			elseif tonumber(trinket2 or -1) == v[1]  then
				local icon = GetItemIcon(v[1])
				tinsert (active, {cd = v[2] or 45, icon = icon, id = k, type = "item", slot = 14, duration = v[3] or 0} ) 
			elseif tonumber(weapon1 or -1) == v[1]  then
				local icon = GetItemIcon(v[1])
				tinsert (active, {cd = v[2] or 45, icon = icon, id = k, type = "item", slot = 16, duration = v[3] or 0} ) 
			end
		end
	end
end
function mod:ScanPlayerItemSet()
	local items = {}
	for i = 1, 19 do
		local link = GetInventoryItemLink("player", i)
		if link then
			items[tonumber(link:match("item:(%d+)"))] = true
		end
	end
	for k,v in pairs(itemset) do
		if not ecddb.blacklist[k] then
			local p = 0
			for _,item in ipairs(v[1]) do
				if items[item] then
					p = p + 1
				end
			end
			local _,_,icon = GetSpellInfo(k)
			if p >= v[2] then
				local _,_,icon = GetSpellInfo(k)
				tinsert (active, {cd = v[3] or 45, icon = icon, id = k, type = "itemset", duration = v[4] or 0})
			end
		end
	end
end
function mod:IsEquipedChanged()
	local changed = {}
	changed [20] = false
	for i = 1, 19 do
		changed[i] = false
		local link = GetInventoryItemLink("player", i)
		if link then
			local itemid = tonumber(link:match("item:(%d+)"))
			if equippedItems[i] ~= itemid then
				equippedItems[i] = itemid
				changed[i] = true
				changed[20] = true
			end
		else
			if equippedItems[i] then
				equippedItems[i] = nil
				changed[i] = true
				changed[20] = true
			end
		end				
	end
	return changed
end
function mod:OnTalentChanged()
	if ecddb.talent then
		self:ResetAllIcons()
	end
end
function mod:OnInventoryChanged(event,uid)
	local changed = self:IsEquipedChanged()
	if uid ~= "player" then return end
	if ecddb.item or ecddb.enchant then
		if changed[20] then self:ResetAllIcons() end
	end
	for k,v in pairs(active) do
		if v.slot and changed[v.slot] then 
			self:StartTimer(k,true)
		end
	end
end
function mod:ResetAllIcons()
	self:ReleaseAllIcons()
	active = {}
	if ecddb.talent then self:ScanPlayerTalent() end
	if ecddb.enchant then self:ScanPlayerEnchant() end
	if ecddb.item then self:ScanPlayerItem() end
	if ecddb.itemset then self:ScanPlayerItemSet() end
	self:AddIcon(self.bar)
	for k1, v1 in pairs(cdcache) do
		for k2, v2 in pairs(active) do
			if k1 == v2.id then 
				if v1.cd + v1.start > GetTime() then
					self:StartTimer(k2,false, GetTime() - v1.start )
				end
			end
		end
	end
end
function mod:ReleaseAllIcons()
	for k,v in pairs (active) do
		local btn = self.bar[k]
		if btn then
			cdcache[v.id] = {start = btn.start or 0, cd = btn.cooldown}
			btn:Hide()
			active[k]= nil
		end
	end
end
local time = {}
local function UpdateIcon(btn, elapsed)
	if not time[btn] then time[btn] = 0 end
	time[btn] = time[btn] + elapsed
	if time[btn] > 0.2 then
		if btn.duration + btn.start > GetTime() then
			if not btn.overlay:IsShown() then btn.overlay:Show() end
			btn.timeleft = btn.start + btn.duration - GetTime()
			btn.text:SetTextColor(0,1,0,1)
		else
			if btn.overlay:IsShown() then btn.overlay:Hide() end
			btn.timeleft = btn.start + btn.cooldown - GetTime()
			btn.text:SetTextColor(1,0,0,1)
		end
		if btn.timeleft <= 0 then
			mod:EndTimer(btn.order)
		else 
			mod:UpdateText(btn.text,floor(btn.timeleft+0.5))
		end
		time[btn] = time[btn] - 0.2
	end
end
function mod:EndTimer(order)
	local btn = self.bar[order]
	btn.timeleft = -1
	btn.start = nil
	btn.text:SetText("")
	btn.cd:Hide()
	btn.overlay:Show()
	btn:SetScript("OnUpdate", nil)
end
function mod:UpdateText(text,timeleft)
	if not ecddb.showtext then
		text:SetText("")
	else
		text:SetFormattedText("%d",timeleft)
	end
	--[[if timeleft < 6 then 
		text:SetTextColor(1,0,0,1)
	else 
		text:SetTextColor(1,1,0,1) 
	end]]--
end
function mod:StartTimer(order,...)
	local precd,past = select (1 , ...)
	local btn = self.bar[order]
	if precd then 
		btn.duration = 0
	else
		btn.duration = active[order].duration
	end
	if btn.start and btn.start + btn.cooldown > GetTime() then return end
	btn.cd:Show()
	btn.start = GetTime() - (past or 0)
	btn.cd:SetCooldown(btn.start, active[order].cd)
	--self:UpdateText(bar[order].text, active[order].cd)
	--btn.overlay:Hide()
	btn:SetScript("OnUpdate",UpdateIcon)
end
function mod:PLAYER_ENTERING_WORLD()
	self:IsEquipedChanged()
end

function mod:EnterCombat()
	if ecddb.combat then self.bar:Show() end
end
function mod:LeaveCombat()
	if ecddb.combat then self.bar:Hide() end
end
function mod:COMBAT_LOG_EVENT_UNFILTERED(event, ...)
	local timestamp,event,hideCaster,sourceGUID,sourceName,sourceFlags,sourceFlags2,destGUID,destName,destFlags,destFlags2,spellID,spellName= select ( 1 , ... )
	if sourceGUID == UnitGUID("player") then 
		--print(sourceName,destName,destFlags,event,spellName,spellID)
	
		if events[event] then
			if talents[spellID] or enchants[spellID] or items[spellID] or itemset[spellID] then
				for k,v in pairs (active) do
					if v.id == spellID then
						if v.id == 116 and event ~= "SPELL_CAST_START" then
							return
						else
							self:StartTimer(k)
							return
						end
					end
				end
			end
			if cdreset[spellID] then
				for k,v in pairs (active) do
					if v.id == cdreset[spellID] then self:EndTimer(k) return end
				end
			end
		end
	end
end
