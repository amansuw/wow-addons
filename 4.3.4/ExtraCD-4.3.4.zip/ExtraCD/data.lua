﻿local mod = ExtraCD
function mod:GetTalents() -- [spellid] = {"CLASS",TalentGroup,TalentTab,cooldown[,duration]}
	return {
		-- druid
		[80861] = {"DRUID",2,5,3}, -- 3 Fury Swipes
		[34299] = {"DRUID",2,12,6}, -- 6 Leader of the Pack
		[16886] = {"DRUID",1,1,60,15}, -- 60 Nature's Grace (but can be renew by solar or lunar eclipse)
		[81094] = {"DRUID",3,9,12}, -- 12 Revitalize
		-- dk
		[96171] = {"DEATHKNIGHT",1,15,45,8}, -- 45 Will of the Necropolis	
		-- hunter
		[56453] = {"HUNTER",3,10,10}, -- 10 Lock and Load
		--[82898] = -- 2 Crouching Tiger, Hidden Chimera
		--[82899] = 
		-- mage
		[12536] = {"MAGE",1,1,15}, -- 15 Clearcasting
		[87023] = {"MAGE",2,8,60,6}, -- 60 Cauterize
		[116] = {"MAGE",3,1,15}, -- 15 Early Frost
		[{83046,83047}] = {"MAGE",1,12,10}, -- 10 Improved Polymorph
		-- paladin
		[89023] = {"PALADIN",1,19,8}, -- 8 Blessed Life
		[96263] = {"PALADIN",3,11,60,15}, -- 30 Sacred Shield
		-- priest
		[47755] = {"PRIEST",1,12,12},-- 12 Rapture
		-- rogue
		[45182] = {"ROGUE",3,14,90,3}, -- 60 Cheated Death
		[51699] = {"ROGUE",3,11,4}, -- 4 Honor Among Thieves
		-- shaman
		[31616] = {"SHAMAN",3,7,30}, -- 30 Nature's Guardian
		-- warlock
		[34936] = {"WARLOCK",3,12,8,8}, -- 8 Backlash
		[89140] = {"WARLOCK",2,4,120,10}, -- 120 Demonic Rebirth
		-- warrior
		[{85386,86624}] = {"WARRIOR",2,11,120,{4,8}}, -- 120 Die by the Sword
		[23694] = {"WARRIOR",1,11,{60,30}}, -- 60/30 Improved Hamstring
		[60503] = {"WARRIOR",1,8,5}, -- 5 Taste for Blood
	}
end
function mod:GetItemSet() -- [spellid] = {{{itemset1},{itemset2},...},minimum,cooldown[,duration]}
	return {
		[105919] = {{77028,77029,77030,77031,77032,78793,78832,78756,78769,78804,78698,78737,78661,78674,78709},4,105,15}, -- Hunter T13 4P Bonus
		[105582] = {{77008,77009,77010,77011,77012,78792,78846,78758,78773,78881,78697,78751,78663,78678,78716},2,45}, -- Tank DK T13 2P Bonus 
		[99063] = {{71286,71287,71288,71289,71290,71507,71508,71509,71510,71511},2,45,15}, -- Mage T12 2P Bonus
		[99221] = {{71281,71282,71283,71284,71295,71594,71595,71596,71597,71598},2,45,15}, -- Warlock T12 2P Bonus
		[99035] = {{71107,71108,71109,71110,71111,71496,71497,71498,71499,71500},2,45,15}, -- Balance Druid T12 2P Bonus
		[99202] = {{71552,71553,71554,71555,71556,71291,71292,71293,71294,71295},2,90}, -- Elemental Shaman T12 2P Bonus 
	}
end
function mod:GetItems() -- [spellid] = {itemid,cooldown[,duration]}
	return {
		
		-- Cataclysm 4.3
		-- Ti'tahk, the Steps of Time
		[109844] = {78477,45,10}, -- H
		[107804] = {77190,45,10}, -- N
		[109842] = {78486,45,10}, -- LFR
		-- Maw of the Dragonlord
		[109849] = {78476,15}, -- H
		[107835] = {77196,15}, -- N
		[109847] = {78485,15}, -- LFR
		-- Rathrak, the Poisonous Mind
		[109854] = {78475,15,10}, -- H
		[107831] = {77195,15,10}, -- N
		[109851] = {78484,15,10}, -- LFR
		-- Kiril, Fury of Beasts
		[109864] = {78473,55,20}, -- H
		[108011] = {77194,55,20}, -- N
		[109861] = {78482,55,20}, -- LFR
		-- Creche of the Final Dragon
		[109744] = {77992,100,20}, -- H
		[107988] = {77205,100,20}, -- N
		[109742] = {77972,100,20}, -- LFR
		-- Indomitable Pride
		[108008] = {78003,60,6}, -- H
		[108008.1] = {77211,60,6}, -- N
		[108008.2] = {77983,60,6}, -- LFR
		-- Insignia of the Corrupted Mind
		[109789] = {77991,100,20}, -- H
		[107982] = {77203,100,20}, -- N
		[109787] = {77971,100,20}, -- LFR
		-- Seal of the Seven Signs
		[109804] = {77989,100,20}, -- H
		[107982.1] = {77204,100,20}, -- N
		[109802] = {77969,100,20}, -- LFR
		-- Soulshifter Vortex
		[109776] = {77990,100,20}, -- H
		[107986] = {77206,100,20}, -- N
		[109774] = {77970,100,20}, -- LFR
		-- Starcatcher Compass
		[109711] = {77993,100,20}, -- H
		[107982.2] = {77202,100,20}, -- N
		[109709] = {77973,100,20}, -- LFR
		-- Windward Heart
		[109825] = {78001,25}, -- H
		[108000] = {77209,25}, -- N
		[109822] = {77981,25}, -- LFR
		
		-- Bone-Link Fetish
		[109754] = {78002,25}, -- H
		[107997] = {77210,25}, -- N
		[109752] = {77982,25}, -- LFR
		-- Cunning of the Cruel
		[109800] = {78000,10}, -- H
		[108005] = {77208,10}, -- N
		[109798] = {77980,10}, -- LFR
		-- Vial of Shadows
		[109724] = {77999,10}, -- H
		[107994] = {77207,10}, -- N
		[109721] = {77979,10}, -- LFR
		-- S11 PVP
		[105135] = {73643,50,20},
		[105137] = {73497,50,20},
		[105139] = {73491,50,20},
		
		[102439] = {72309,50,20},
		[102435] = {72449,50,20},
		[102432] = {72455,50,20},
		
		-- 378 others
		[102659] = {72897,50,20},
		[102662] = {72898,50,20},
		[102664] = {72899,50,20},
		
		[109993] = {74035,50,20},
		[102660] = {72901,50,20},
		[102667] = {72900,50,20},
		
		-- Cataclysm Raid T12 378 - 397
		-- Matrix Restabilizer H
		[97139] = {69150,105,30},
		[97140] = {69150,105,30},
		[97141] = {69150,105,30},
		-- Matrix Restabilizer
		[96978] = {68994,105,30},
		[96977] = {68994,105,30},
		[96979] = {68994,105,30},
		[97136] = {69149,45}, -- Eye of Blazing Power H
		[96966] = {68983,45}, -- Eye of Blazing Power
		[97129] = {69138,60}, -- Spidersilk Spindle H
		[96945] = {68981,60}, -- Spidersilk Spindle
		[97125] = {69112,60,15}, -- The Hungerer H
		[96911] = {68927,60,15}, -- The Hungerer
		
		-- S10 PVP
		[99721] = {70579,50,20},
		[99719] = {70578,50,20},
		[99717] = {70577,50,20},
		[99742] = {70402,50,20},
		[99748] = {70404,50,20},
		[99746] = {70403,50,20},
		
		-- Festival Trinket 365
		[101289] = {71336,50,10}, -- Petrified Pickled Egg
		[101291] = {71337,50,10}, -- Mithril Stopwatch
		[101287] = {71335,50,10}, -- Coren's Chilled Chromium Coaster
		
		-- Mount Hyjal 365
		[100322] = {70141,45,20}, -- Dwyer's Caber
		
		-- Darkmoon Cards
		[89091] = {62047,45,12}, -- Darkmoon Card: Volcano

		-- Tol Barad factions
		[91192] = {{62467, 62472},50,10}, -- Mandala of Stirring Patterns
		[91047] = {{62465, 62470},75,15}, -- Stump of Time

		-- Valour Vendor 4.0
		[92233] = {58182,30,10}, -- Bedrock Talisman

		-- Cataclysm Raid 372
		[92320] = {65105,90,20}, -- Theralion's Mirror
		[92355] = {65048,30,10}, -- Symbiotic Worm
		[92349] = {65026,75,15}, -- Prestor's Talisman of Machination
		[92345] = {65072,100,20}, -- Heart of Rage
		[92332] = {65124,75,15}, -- Fall of Mortality
		[92351] = {65140,50,10}, -- Essence of the Cyclone
		[92342] = {65118,75,15}, -- Crushing Weight
		[92318] = {65053,100,20}, -- Bell of Enraging Resonance
		
		-- Cataclysm Raid 359
		[92108] = {59520,50,10}, -- Unheeded Warning
		[91024] = {59519,90,20}, -- Theralion's Mirror
		[92235] = {59332,30,10}, -- Symbiotic Worm
		[92124] = {59441,75,15}, -- Prestor's Talisman of Machination
		[91816] = {59224,100,20}, -- Heart of Rage
		[91184] = {59500,75,15}, -- Fall of Mortality
		[92126] = {59473,50,10}, -- Essence of the Cyclone
		[91821] = {59506,75,15}, -- Crushing Weight
		[91007] = {59326,100,20}, -- Bell of Enraging Resonance
		
		-- Cataclysm Dungeon 346
		[90992] = {56407,50,10}, -- Anhuur's Hymnal
		[91149] = {56414,100,20}, -- Blood of Isiset
		[92087] = {56295,50,10}, -- Grace of the Herald
		[91364] = {56393,100,20}, -- Heart of Solace
		[92091] = {56328,75,15}, -- Key to the Endless Chamber
		[92184] = {56347,30,10}, -- Leaden Despair
		[92094] = {56427,50,10}, -- Left Eye of Rajh
		[92174] = {56280,80,20}, -- Porcelain Crab
		[91143] = {56377,75,15}, -- Rainsong
		[91368] = {56431,50,10}, -- Right Eye of Rajh
		[91002] = {56400,20,10}, -- Sorrowsong
		[91139] = {56351,75,15}, -- Tear of Blood
		[90898] = {56339,75,15}, -- Tendrils of Burrowing Dark
		[92205] = {56449,60,12}, -- Throngus's Finger
		[90887] = {56320,75,15}, -- Witching Hourglass

		-- Cataclysm Dungeon and World drops 308-333
		[90989] = {55889,50,10}, -- Anhuur's Hymnal
		[91147] = {55995,100,20}, -- Blood of Isiset
		[91363] = {55868,100,20}, -- Heart of Solace
		[92096] = {56102,50,10}, -- Left Eye of Rajh
		[91370] = {56100,50,10}, -- Right Eye of Rajh
		[90996] = {55879,20,10}, -- Sorrowsong
		[92208] = {56121,60,12}, -- Throngus's Finger
		[92052] = {66969,50,10}, -- Heart of the Vile
		[92069] = {55795,75,15}, -- Key to the Endless Chamber
		[92179] = {55816,30,10}, -- Leaden Despair
		[91141] = {55854,75,15}, -- Rainsong
		[91138] = {55819,75,15}, -- Tear of Blood
		[90896] = {55810,75,15}, -- Tendrils of Burrowing Dark
		[92052] = {55266,50,10}, -- Grace of the Herald
		[90885] = {55787,75,15}, -- Witching Hourglass

		-- S9 PvP
		[85027] = {61045,50,20}, -- Vicious Gladiator's Insignia of Dominance
		[85032] = {61046,50,20}, -- Vicious Gladiator's Insignia of Victory
		[85022] = {61047,50,20}, -- Vicious Gladiator's Insignia of Conquest
		[92218] = {64762,50,20}, -- Bloodthirsty Gladiator's Insignia of Dominance
		[92216] = {64763,50,20}, -- Bloodthirsty Gladiator's Insignia of Victory
		[92220] = {64761,50,20}, -- Bloodthirsty Gladiator's Insignia of Conquest
	}
end
function mod:GetEnchants() -- [spellid] = {enchantid,slot,cooldown[,duration]}
	return {
		-- Cataclysm
		[74241] = {4097,16,45,12}, -- Power Torrent
		[99621] = {4267,18,40,10}, -- Flintlocke's Woodchucker
		--[74221] = {4083,{16,17},45,12}, -- Hurricane (still have some problem)
		[74221] = {4083,16,45,12}, -- Hurricane
		[74224] = {4084,16,20,15}, -- Heartsong
		[75173] = {4116,15,50,15}, -- Darkglow Embroidery (Rank2)
		[75170] = {4115,15,65,15}, -- Lightweave Embroidery (Rank2)
		[75176] = {4118,15,55,15}, -- Swordguard Embroidery (Rank2)
		-- WotLK
		[55637] = {3722,15,45,15}, -- Lightweave Embroidery (Rank 1)
		[55775] = {3730,15,45,15}, -- Swordguard Embroidery (Rank 1)
		[55767] = {3728,15,45},	-- Darkglow Embroidery (Rank 1)
		[59626] = {3790,16,35,10}, -- Black Magic
	}
end
function mod:GetCDReset() -- [spellid] = reseted spellid
	return {
		[48517] = 16886,
		[48518] = 16886,
	}
end
