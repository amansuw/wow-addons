local CCReport = CreateFrame("Frame")
CCReport.playername = UnitName("player")
local enabled = 'true';
SLASH_CCR1 = '/CCR';
SLASH_CCR2 = '/CCReport';
local function SlashCmd(cmd,self)
	if (cmd == 'enable') then
		enabled = 'true';
		DEFAULT_CHAT_FRAME:AddMessage("CCReport Enabled",0,1,0);
        elseif (cmd == 'disable') then
                enabled = 'false';
		DEFAULT_CHAT_FRAME:AddMessage("CCReport Disabled",1,0,0);
        else
                DEFAULT_CHAT_FRAME:AddMessage("Unknown command. Enter either '/ccr enable' to activate CCReport, or '/ccr disable' to deactivate it.",1,1,0);
        end
end
SlashCmdList["CCR"] = SlashCmd;

CCReport:SetScript("OnEvent",function(...)
	local args = {...}

------------------------------------------
--					--
--		Crowd Controls		--
--					--
------------------------------------------

if (enabled == 'true') then
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 5782 or args[14] == 6213 or args[14] == 6215))
	then
		SendChatMessage("{rt8}FEARED{rt8}", "PARTY")
	end
--Fear^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 5782 or args[14] == 6213 or args[14] == 6215))
	then
		SendChatMessage("{rt8}FEAR REFRESHED{rt8}", "PARTY")
	end
--Fear (Refreshed)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 118 or args[14] == 12824 or args[14] == 12825 or args[14] ==  12826 or args[14] == 61305 or args[14] == 28272 or args[14] == 61721 or args[14] == 61780 or args[14] == 28271))
	then
		SendChatMessage("{rt8}POLY'D{rt8}", "PARTY")
	end
--Polymorph^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 118 or args[14] == 12824 or args[14] == 12825 or args[14] ==  12826 or args[14] == 61305 or args[14] == 28272 or args[14] == 61721 or args[14] == 61780 or args[14] == 28271))
	then
		SendChatMessage("{rt8}POLY REFRESHED{rt8}", "PARTY")
	end
--Polymorph (Refreshed)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 51514))
	then
		SendChatMessage("{rt8}HEXED{rt8}", "PARTY")
	end
--Hex^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 2094))
	then
		SendChatMessage("{rt8}BLINDED{rt8}", "PARTY")
	end
--Blind^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 6358))
	then
		SendChatMessage("{rt8}SEDUCED{rt8}", "PARTY")
	end
--Seduction (Succubus)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 6358))
	then
		SendChatMessage("{rt8}SEDUCE REFRESHED{rt8}", "PARTY")
	end
--Seduction (Succubus) (Refreshed)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 33786))
	then
		SendChatMessage("{rt8}CYCLONED{rt8}", "PARTY")
	end
--Cyclone^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 51724 or args[14] == 11297 or args[14] == 2070 or args[14] ==  6770))
	then
		SendChatMessage("{rt8}SAPPED{rt8}", "PARTY")
	end
--Sap^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 51724 or args[14] == 11297 or args[14] == 2070 or args[14] ==  6770))
	then
		SendChatMessage("{rt8}SAP REFRESHED{rt8}", "PARTY")
	end
--Sap (Refreshed)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 605))
	then
		SendChatMessage("{rt8}MIND CONTROLLED{rt8}", "PARTY")
	end
--Mind Control^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 8122 or args[14] == 8124 or args[14] == 10888 or args[14] == 10890))
	then
		SendChatMessage("{rt8}FEARED{rt8}", "PARTY")
	end
--Psychic Scream^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 20511))
	then
		SendChatMessage("{rt8}FEARED{rt8}", "PARTY")
	end
--Intimidating Shout^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 20066))
	then
		SendChatMessage("{rt8}REPENTANCED{rt8}", "PARTY")
	end
--Repentance^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 14309 or args[14] == 60210))
	then
		SendChatMessage("{rt8}FROZEN{rt8}", "PARTY")
	end
--Freezing Trap / Arrow^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 710 or args[14] == 18647))
	then
		SendChatMessage("{rt8}BANISHED{rt8}", "PARTY")
	end
--Banish^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 710 or args[14] == 18647))
	then
		SendChatMessage("{rt8}BANISH REFRESHED{rt8}", "PARTY")
	end
--Banish (Refreshed)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 2637 or args[14] == 18657 or args[14] == 18658))
	then
		SendChatMessage("{rt8}HIBERNATED{rt8}", "PARTY")
	end
--Hibernate^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 2637 or args[14] == 18657 or args[14] == 18658))
	then
		SendChatMessage("{rt8}HIBERNATE REFRESHED{rt8}", "PARTY")
	end
--Hibernate (Refreshed)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 51209))
	then
		SendChatMessage("{rt8}FROZEN{rt8}", "PARTY")
	end
--Hungering Cold^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 5211))
	then
		SendChatMessage("{rt8}BASHED{rt8}", "PARTY")
	end
--Bash^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 53308))
	then
		SendChatMessage("{rt8}ROOTED{rt8}", "PARTY")
	end
--Entangling Roots^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 1513))
	then
		SendChatMessage("{rt8}FEARED{rt8}", "PARTY")
	end
--Scare Beast^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 1513))
	then
		SendChatMessage("{rt8}FEAR REFRESHED{rt8}", "PARTY")
	end
--Scare Beast (Refreshed)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 49012))
	then
		SendChatMessage("{rt8}STUNNED{rt8}", "PARTY")
	end
--Wyvern Sting^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 10308))
	then
		SendChatMessage("{rt8}HoJ'd{rt8}", "PARTY")
	end
--Hammer Of Justice^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 10326))
	then
		SendChatMessage("{rt8}FEARED{rt8}", "PARTY")
	end
--Turn Evil^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 10326))
	then
		SendChatMessage("{rt8}FEAR REFRESHED{rt8}", "PARTY")
	end
--Turn Evil (Refreshed)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 10955))
	then
		SendChatMessage("{rt8}SHACKLED{rt8}", "PARTY")
	end
--Shackle Undead^
	if ((args[11] == CCReport.playername)
	and ( args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 10955))
	then
		SendChatMessage("{rt8}SHACKLE REFRESHED{rt8}", "PARTY")
	end
--Shackle Undead (Refreshed)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 58582))
	then
		SendChatMessage("{rt8}I JUST HIT STONECLAW TOTEM /PALM{rt8}", "PARTY")
	end
--Stoneclaw Stun^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 17928))
	then
		SendChatMessage("{rt8}FEARED{rt8}", "PARTY")
	end
--Howl Of Terror^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 42917 or args[14] == 33395))
	then
		SendChatMessage("{rt8}FROZEN{rt8}", "PARTY")
	end
--Frost Nova / Water Elemental Freeze^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 44572))
	then
		SendChatMessage("{rt8}DEEP FREEZE{rt8}", "PARTY")
	end
--Deep Freeze^

------------------------------------------
--					--
--		Silences		--
--					--
------------------------------------------

	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 78675))
	then
		SendChatMessage("{rt8}SILENCED{rt8}", "PARTY")
	end
--Solar Beam^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 47476 or args[14] == 58618))
	then
		SendChatMessage("{rt8}SILENCED{rt8}", "PARTY")
	end
--Strangulate^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 34490))
	then
		SendChatMessage("{rt8}SILENCED{rt8}", "PARTY")
	end
--Silencing Shot^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 31117 or args[14] == 43523 or args[14] == 65813))
	then
		SendChatMessage("{rt8}SILENCED{rt8}", "PARTY")
	end
--Unstable Affliction Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 55021 or args[14] == 18469))
	then
		SendChatMessage("{rt8}SILENCED{rt8}", "PARTY")
	end
--Counterspell^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 18425))
	then
		SendChatMessage("{rt8}SILENCED{rt8}", "PARTY")
	end
--Kick^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 1330))
	then
		SendChatMessage("{rt8}SILENCED{rt8}", "PARTY")
	end
--Garrote^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 15487))
	then
		SendChatMessage("{rt8}SILENCED{rt8}", "PARTY")
	end
--Silence (Priest)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 24259))
	then
		SendChatMessage("{rt8}SILENCED{rt8}", "PARTY")
	end
--Spell Lock (Fel Hunter)^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 18498))
	then
		SendChatMessage("{rt8}SILENCED{rt8}", "PARTY")
	end
--Silence (Warrior)^

------------------------------------------
--					--
--		Debuffs			--
--					--
------------------------------------------

	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED" or args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 77606))
	then
		SendChatMessage("{rt7}SIMULACRUM APPLIED{rt7}", "PARTY")
	end
--Dark Simulacrum^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_APPLIED")
	and (args[14] == 30108 or args[14] == 30404 or args[14] == 30405 or args[14] == 47841 or args[14] == 47843))
	then
		SendChatMessage("{rt7}UA APPLIED{rt7}", "PARTY")
	end
--Unstable Affliction Applied^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 30108 or args[14] == 30404 or args[14] == 30405 or args[14] == 47841 or args[14] == 47843))
	then
		SendChatMessage("{rt7}UA REMOVED{rt7}", "PARTY")
	end
--Unstable Affliction Removed^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REFRESH")
	and (args[14] == 30108 or args[14] == 30404 or args[14] == 30405 or args[14] == 47841 or args[14] == 47843))
	then
		SendChatMessage("{rt7}UA REFRESHED{rt7}", "PARTY")
	end
--Unstable Affliction Refreshed^

------------------------------------------
--					--
--		Dispels			--
--					--
------------------------------------------

	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 20217))
	then
		SendChatMessage("{rt4}KINGS - REMOVED{rt4}", "PARTY")
	end
--Blessing of Kings Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 48936))
	then
		SendChatMessage("{rt4}WISDOM - REMOVED{rt4}", "PARTY")
	end
--Blessing of Wisdom Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 19740))
	then
		SendChatMessage("{rt4}MIGHT - REMOVED{rt4}", "PARTY")
	end
--Blessing of Might Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 53307))
	then
		SendChatMessage("{rt4}THORNS - REMOVED{rt4}", "PARTY")
	end
--Thorns Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 1126))
	then
		SendChatMessage("{rt4}MotW - REMOVED{rt4}", "PARTY")
	end
--Mark of the Wild Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 48043))
	then
		SendChatMessage("{rt4}SPIRIT - REMOVED{rt4}", "PARTY")
	end
--Prayer of Spirit Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 27683))
	then
		SendChatMessage("{rt4}SHADOW PROTECTION - REMOVED{rt4}", "PARTY")
	end
--Shadow Protection Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 1459 or args[14] == 61024))
	then
		SendChatMessage("{rt4}INTELLECT - REMOVED{rt4}", "PARTY")
	end
--Arcane Intellect / Dalaran Intellect Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 21562))
	then
		SendChatMessage("{rt4}FORTITUDE - REMOVED{rt4}", "PARTY")
	end
--Power Word: Fortitude Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 54646))
	then
		SendChatMessage("{rt4}FOCUS MAGIC - REMOVED{rt4}", "PARTY")
	end
--Focus Magic Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 20911 or args[14] == 84629))
	then
		SendChatMessage("{rt4}SANCTUARY - REMOVED{rt4}", "PARTY")
	end
--Blessing of Sanctuary Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 53563))
	then
		SendChatMessage("{rt4}BEACON - REMOVED{rt4}", "PARTY")
	end
--Beacon of Light Dispelled^
	if ((args[11] == CCReport.playername)
	and (args[4] == "SPELL_AURA_REMOVED")
	and (args[14] == 25780))
	then
		SendChatMessage("{rt4}RIGHTEOUS FURY - REMOVED{rt4}", "PARTY")
	end
--Righteous Fury Dispelled^
end
end)


CCReport:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
DEFAULT_CHAT_FRAME:AddMessage("CCReport loaded - Sup bro.",1,0,0)

