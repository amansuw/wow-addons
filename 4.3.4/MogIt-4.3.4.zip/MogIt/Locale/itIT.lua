﻿if GetLocale() ~= "itIT" then return end;
local MogIt,mog = ...;
local L = mog.L;

