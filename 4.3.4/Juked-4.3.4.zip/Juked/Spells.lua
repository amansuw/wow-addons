--CHANGELOG:
--Modified {spellID=8177, time=22, prio=false},--Grounding Totem
--Added {spellID=30283, time=20, prio=false},--Shadowfury (v1.3.5)
--Modified {spellID=31224, time=90, prio=false},--Cloak of Shadows (v1.3.5)
--Modified {spellID=74001, time=90, prio=false},--Combat Readiness (v1.3.5)
--Added {spellID=98008, time=180, prio=false},--Spirit Link Totem (v1.3.4)
--Thanks to Pielo for these
--Added {spellID=1719, time=300, prio=false},--Recklessness(Arms) (v1.3.4)
--Added {spellID=51271, time=60, prio=false},--Pillar of Frost (v1.3.4)
--Added {spellID=31884, time=180, prio=false},--Avenging Wrath (v1.3.4)
--Added {spellID=85730, time=120, prio=false},--Deadly Calm (v1.3.4)
--Added {spellID=1953, time=15, prio=false},--Blink(v1.3.4)
--Added {spellID=20511, time=120, prio=false},--Intimidating Shout(v1.3.4) 
--Reordered the table (v1.3.4)
--Added  {spellID=23920, time=25, prio=false},--Spell Reflection (v1.3.3)

spell_table = {
--Interrupts and Silences
{spellID=6552, time=10, prio=true},--Pummel
{spellID=23920, time=25, prio=false},--Spell Reflection
{spellID=1766, time=10, prio=true},--Kick 
{spellID=47528, time=10, prio=true},--Mind Freeze
{spellID=47476, time=120, prio=false},--Strangulate (unmodified)
{spellID=96231, time=10, prio=true},--Rebuke
{spellID=57994, time=6, prio=true},--Wind Shear
{spellID=2139, time=24, prio=true},--Counterspell
{spellID=19647, time=24, prio=true},--Spell Lock
{spellID=34490, time=20, prio=true},--Silencing Shot
{spellID=15487, time=45, prio=false},--Silence
{spellID=80965, time=10, prio=true},--Skull Bash
{spellID=78675, time=60, prio=false},--Solar Bream

--Gap Closers
{spellID=16979, time=15, prio=false},--Feral Charge 
{spellID=100, time=12, prio=false},--Charge 
{spellID=49576, time=25, prio=false},--Death Grip
{spellID=36554, time=24, prio=false},--Shadowstep 
{spellID=1953, time=15, prio=false},--Blink

--CC
{spellID=51514, time=35, prio=false},--Hex (glyphed)
{spellID=44572, time=30, prio=false},--Deep Freeze
{spellID=82676, time=120, prio=false},--Ring of Frost 
{spellID=19503, time=30, prio=false},--Scatter Shot
{spellID=2094, time=120, prio=false},--Blind 
{spellID=51722, time=60, prio=false},--Dismantle
{spellID=85388, time=45, prio=false},--Throwdown
{spellID=20511, time=120, prio=false},--Intimidating Shout
{spellID=676, time=60, prio=false},--Disarm
{spellID=6789, time=90, prio=false},--Death Coil
{spellID=5484, time=32, prio=false},--Howl of Terror
{spellID=30283, time=20, prio=false},--Shadowfury
{spellID=64044, time=90, prio=false},--Psychic Horror
{spellID=8122, time=23, prio=false},--Psychic Scream
{spellID=20066, time=60, prio=false},--Repentance
{spellID=853, time=40, prio=false},--Hammer of Justice
{spellID=91800, time=60, prio=false},--Gnaw
{spellID=49203, time=60, prio=false},--Hungering Cold

--Defensive
{spellID=31224, time=90, prio=false},--Cloak of Shadows (using lowest CD)
{spellID=74001, time=90, prio=false},--Combat Readiness
{spellID=47585, time=75, prio=false},--Dispersion (glyphed)
{spellID=33206, time=180, prio=false},--Pain Suppression
{spellID=48707, time=45, prio=false},--Anti-Magic Shell
{spellID=48792, time=180, prio=false},--Icebound Fortitude
{spellID=642, time=300, prio=false},--Divine Shield
{spellID=19263, time=110, prio=false},--Deterrence (glyphed)
{spellID=48020, time=26, prio=false},--Demonic Circle: Teleport
{spellID=22812, time=60, prio=false},--Barkskin
{spellID=45438, time=240, prio=false},--Ice Block
{spellID=98008, time=180, prio=false},--Spirit Link Totem


--Offensive
{spellID=46924, time=75, prio=false},--Bladestorm (glyphed)
{spellID=85730, time=120, prio=false},--Deadly Calm
{spellID=1719, time=300, prio=false},--Recklessness
{spellID=32379, time=10, prio=false},--Shadow Word: Death
{spellID=51713, time=60, prio=false},--Shadow Dance
{spellID=51271, time=60, prio=false},--Pillar of Frost
{spellID=31884, time=180, prio=false},--Avenging Wrath
{spellID=87151, time=90, prio=false},--Archangel
{spellID=50334, time=180, prio=false},--Berserk

--Other
{spellID=29166, time=180, prio=false},--Innervate
{spellID=14185, time=300, prio=false},--Preparation
{spellID=1856, time=120, prio=false},--Vanish 
{spellID=77606, time=60, prio=false},--Dark Simulacrum
{spellID=49039, time=120, prio=false},--Lichborne
{spellID=18499, time=24, prio=false},--Berserker Rage
{spellID=31821, time=120, prio=false},--Aura Mastery
{spellID=11958, time=384, prio=false},--Cold Snap
{spellID=16190, time=180, prio=false},--Mana Tide Totem.
{spellID=8143, time=60, prio=false},--Tremor Totem
{spellID=89485, time=45, prio=false},--Inner Focus
{spellID=8177, time=22, prio=false},--Grounding Totem
{spellID=23989, time=180, prio=false},--Readiness
}
