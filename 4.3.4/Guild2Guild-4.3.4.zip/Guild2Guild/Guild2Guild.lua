﻿--[[         
        
        Guild2Guild - addon for World of Warcraft
        Managed and written by Jaxom of Hellfire
        Copyright = All rights reserved
        05/03/2011
        
        Version = 8.1.3
        
        http://wow.curseforge.com/addons/guild2guild/
         
]]--	


-- Local Dump to clear a path--



local function dump(...)
	local out = "";
	local numVarArgs = select("#", ...);
	for i = 1, numVarArgs do
		local d = select(i, ...);
		local t = type(d);
		if (t == "table") then
			out = out .. "{";
			local first = true;
			if (d) then
				for k, v in pairs(d) do
					if (not first) then out = out .. ", "; end
					first = false;
					out = out .. dump(k);
					out = out .. " = ";
					out = out .. dump(v);
				end
			end
			out = out .. "}";
		elseif (t == "nil") then
			out = out .. "NIL";
		elseif (t == "number") then
			out = out .. d;
		elseif (t == "string") then
			out = out .. "\"" .. d .. "\"";
		elseif (t == "boolean") then
			if (d) then
				out = out .. "true";
			else
				out = out .. "false";
			end
		else
			out = out .. t:upper() .. "??";
		end

		if (i < numVarArgs) then out = out .. ", "; end
	end
	return out;
end

G2GOldChatHandler = nil;
G2GOldChangeChatColor = nil;

G2G_ONLINE 	= ".*%[(.+)%]%S*"..string.sub(ERR_FRIEND_ONLINE_SS, 20)
G2G_OFFLINE	= string.format(ERR_FRIEND_OFFLINE_S, "(.+)")
G2G_JOINED	= string.format(ERR_GUILD_JOIN_S, "(.+)")
G2G_LEFT	= string.format(ERR_GUILD_LEAVE_S, "(.+)")
G2G_PROMO	= string.format(ERR_GUILD_PROMOTE_SSS, "(.+)", "(.+)", "(.+)")
G2G_DEMOTE	= string.format(ERR_GUILD_DEMOTE_SSS, "(.+)", "(.+)", "(.+)")
G2G_ACHIEVEMENT = string.format(ACHIEVEMENT_BROADCAST, "(.+)", "(.+)")
G2G_F_ACHIEVEMENT = string.format(ACHIEVEMENT_BROADCAST, "|Hplayer:%s|h[%s]|h", "%s")

--[[ 		
		�������������������
		  Variable Setup	  
		�������������������
]]--	 

Guild2Guild = {
	Version = "8.1.3",
	VerNum = 813,
    beta = false, -- flags current version as beta.
	Loaded = false,
	Initialized = false,
	Finalizing = false,
	Ready = false,
	tColors = {
		cBlue = "|cff007fff",
		cLtGray = "|cffdfdfdf",
		cLtRed = "|cffff6060",
		cLtYellow = "|cffffff78",
		cGold = "|cffffd700",
		cGreen = "|cff00ff00",
		cRed = "|cffff0000",
		cSilver = "|cffc7c7cf",
		cWhite = "|cffffffff",
		cYellow = "|cffffff00",
		cCL = "|r",
	},
	LocalVars = {
		Leader = nil,
		gLeader = {},
		Magic = time(),
		CurrMax = 0,
		CurrMaxVersion = 0,
		LastUpdate = time (),
		LastCrossGuildUpdate = time (),
		Guilds = {},
		Relays = {},
		RejectedRelays = {},
		WarnedVersionNum = false,
		GuildInfoInitialized = false,
		OfficerRank = nil,
		PlayerIsOfficer = false,
		OfficersWarned = false,
		guildRankIndex = nil,
		AlliedGuilds = nil,
		sentQueryMessage = false,
		awaitingQueryResponse = false,
		OldestVersion = nil,
		ElectionCalled = false,
		sentInitLeaderMessage = false,
		debugStack = {},
		stackCount = 0,
		VerifiedGuilds = {},
		PreviousMessage = "",
		PreviousSender = "",
		GuildInfoText = "",
		Guis = {},
		lastAddonMessageTime = 0,
		lastElectionMessageTime = 0,
		guildRoster = {},
		friends = {},
		ignores = {},
		channelRoster = {},
		localRank = 0,
		versions = {},
		failedAttempts = 0
	},

--[[ 		
		������������������������
		  OnLoad/Init Methods	  
		������������������������
]]--


-----------------------------
-- ResetLocalVariables - resets all variables to their initial states
-----------------------------
	ResetLocalVariables = function(self)
		local GGlocal = Guild2Guild.LocalVars

		self.Initialized = false
		self.Finalizing = false
		self.Ready = false

		GGlocal.Leader = nil
		GGlocal.Magic = time()
		GGlocal.CurrMax = 0
		GGlocal.CurrMaxVersion = 0
		GGlocal.LastUpdate = time ()
		GGlocal.LastCrossGuildUpdate = time ()
		GGlocal.Guilds = {}
		GGlocal.Relays = {}
		GGlocal.RejectedRelays = {}
		GGlocal.WarnedVersionNum = false
		GGlocal.GuildInfoInitialized = false
		GGlocal.OfficerRank = nil
		GGlocal.PlayerIsOfficer = false
		GGlocal.OfficersWarned = false
		GGlocal.guildRankIndex = nil
		GGlocal.AlliedGuilds = nil
		GGlocal.sentQueryMessage = false
		GGlocal.awaitingQueryResponse = false
		GGlocal.OldestVersion = nil
		GGlocal.ElectionCalled = false
		GGlocal.sentInitLeaderMessage = false
		GGlocal.debugStack = {}
		GGlocal.stackCount = 0
		GGlocal.VerifiedGuilds = {}
		GGlocal.PreviousMessage = ""
		GGlocal.PreviousSender = ""
		GGlocal.GuildInfoText = ""
		GGlocal.lastAddonMessageTime = 0
		GGlocal.lastElectionMessageTime = 0
		GGlocal.guildRoster = {}
		GGlocal.friends = {}
		GGlocal.ignores = {}
		GGlocal.channelRoster = {}
		GGlocal.localRank = 0
		GGlocal.versions = {}
		GGlocal.failedAttempts = 0
	end,


-----------------------------
-- OnLoad - called on initial start up to prepare the add-on
-----------------------------
	OnLoad = function(self)
		local cColors = Guild2Guild.tColors
		self:DCF(cColors.cGreen.."v"..Guild2Guild.Version..cColors.cSilver.." loaded :: Type "..cColors.cGreen.."/g2g help"..cColors.cSilver.." for usage.",1)
		Guild2GuildFrame:RegisterEvent("ADDON_LOADED")
		SlashCmdList["GUILD2GUILD"] = function(sMsg)
			self:Slash_Command(sMsg)
		end
		SLASH_GUILD2GUILD1 = "/g2g";
	end,

-----------------------------
-- GG_Init - called after the add-on has loaded to prepare to handle future events
-----------------------------
	GG_Init = function(self)
		local playerName = UnitName("player");
		if((playerName) and (playerName == UNKNOWNOBJECT) or (playerName == UNKNOWNBEING)) then return end
	      
		if not self.Initialized then					  
			if Guild2Guild_Vars == nil then
				Guild2Guild_Vars = DefaultGuild2Guild_Vars
			end
			
			for key, value in pairs(DefaultGuild2Guild_Vars) do
				if (Guild2Guild_Vars[key] == nil) then
					Guild2Guild_Vars[key] = value
				end
			end	
			
			-- clear out the incorrect guild member notify
			Guild2Guild_Vars.G2GGuildMemberNotify = nil;
			-- end clearing out guildmember notify

			Guild2Guild_Vars.debugStack = {}
			Guild2Guild.LocalVars.OldestVersion = self.VerNum
			if (Guild2Guild_Vars.Startdelay == false) then
				Guild2Guild_Vars.Startdelay = 5
			end
			self:Event_Manager()
			self.Initialized = true
            --Gui now around line 2400--
			return Guild2GuildFrame:UnregisterEvent("ADDON_LOADED")
		end
	end,

-----------------------------
-- AddChatType - Adds the Guild2Guild chat type to the chat frame context menu
-----------------------------

	AddChatType = function(self)

		local v = {
				id = "G2G";
				menuText = "G2G";
			}
			
		setglobal("CHAT_"..v.id.."_GET", "["..v.menuText.."]: ");
		
		setglobal("CHAT_MSG_"..v.id, v.menuText);
		
		tinsert(ChatTypeGroup["GUILD"], "CHAT_MSG_"..v.id ); -- Fake event list
		
		ChatTypeInfo[v.id] = {};
		Guild2Guild_Vars.chatTypes = Guild2Guild_Vars.chatTypes or {}
		local chatType = Guild2Guild_Vars.chatTypes[v.id]
		if (not chatType) then
			chatType = {};
			chatType[DEFAULT_CHAT_FRAME:GetID()] = true;
			local info = ChatTypeInfo["GUILD"];
			chatType.r = info.r;
			chatType.g = info.g;
			chatType.b = info.b;
			Guild2Guild_Vars.chatTypes[v.id] = chatType;
			Guild2Guild_Vars.color = Guild2Guild.RGBToHex(info.r,info.g,info.b)
		end
		local chatFrame;
		for i=1, NUM_CHAT_WINDOWS do
			if (chatType[i]) then
				chatFrame = getglobal("ChatFrame"..i);
				if (not Guild2Guild.IsChatTypeVisible(v.id, chatFrame)) then
					ChatFrame_AddMessageGroup(chatFrame, v.id);
				end
			end
		end
		ChatTypeInfo[v.id].r = chatType.r;
		ChatTypeInfo[v.id].g = chatType.g;
		ChatTypeInfo[v.id].b = chatType.b;
		
		ChatTypeInfo[v.id].sticky = 0;
		
	end,
	
-----------------------------
-- IsChatTypeVisible - helper function to determine if a chat type is visible in the context menu
-----------------------------
	
	IsChatTypeVisible = function (chatTypeGroup, chatFrame)
		if (not chatFrame) then
			return;
		end
		local messageTypeList = chatFrame.messageTypeList
		if ( messageTypeList ) then
			for joinedIndex, joinedValue in pairs(messageTypeList) do
				if ( chatTypeGroup == joinedValue ) then
					return true;
				end
			end
		end
		return false;
	end,	
----------------------------
-- Event_Manager - Hooks the UI call back functions
----------------------------

	Event_Manager = function(self)
		local GGVars = Guild2Guild_Vars	
		if GGVars.Active then
			if GGVars.Debug then self:DCF("Register fired.",5,"Event_Manager") end
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_CHANNEL")	
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_GUILD")
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_OFFICER")
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_CHANNEL_JOIN")
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_CHANNEL_LEAVE")
			RegisterAddonMessagePrefix("G2G")
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_ADDON")
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_WHISPER")
			Guild2GuildFrame:RegisterEvent("GUILD_ROSTER_UPDATE")
			Guild2GuildFrame:RegisterEvent("PLAYER_ALIVE")
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_SYSTEM")
			Guild2GuildFrame:RegisterEvent("CVAR_UPDATE")
			Guild2GuildFrame:RegisterEvent("FRIENDLIST_UPDATE")
			Guild2GuildFrame:RegisterEvent("IGNORELIST_UPDATE")
			Guild2GuildFrame:RegisterEvent("CHANNEL_ROSTER_UPDATE")
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_GUILD_ACHIEVEMENT")
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_ACHIEVEMENT")
			Guild2GuildFrame:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE")
		else
			if GGVars.Debug then self:DCF("Unregister fired.",5,"Event_Manager") end
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_CHANNEL")	
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_GUILD")
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_OFFICER")
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_CHANNEL_JOIN")
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_CHANNEL_LEAVE")
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_ADDON")
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_WHISPER")
			Guild2GuildFrame:UnregisterEvent("GUILD_ROSTER_UPDATE")
			Guild2GuildFrame:UnregisterEvent("PLAYER_ALIVE")
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_SYSTEM")
			Guild2GuildFrame:UnregisterEvent("CVAR_UPDATE")
			Guild2GuildFrame:UnregisterEvent("FRIENDLIST_UPDATE")
			Guild2GuildFrame:UnregisterEvent("IGNORELIST_UPDATE")
			Guild2GuildFrame:UnregisterEvent("CHANNEL_ROSTER_UPDATE")
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_GUILD_ACHIEVEMENT")
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_ACHIEVEMENT")
			Guild2GuildFrame:UnregisterEvent("CHAT_MSG_CHANNEL_NOTICE")
		end
		self:Hook_UI()
	end,


----------------------------
-- ReadyToWork - returns false until the start delay time has passed, then initialized the final connection and returns true
----------------------------

	ReadyToWork = function(self)

		if self.Ready then return true end

		local GGlocal = Guild2Guild.LocalVars
		local GGVars = Guild2Guild_Vars
		local cColors = Guild2Guild.tColors

		if ((time() - GGlocal.Magic) < GGVars.Startdelay) then return false end
		if not GGlocal.GuildInfoInitialized then
			if (IsInGuild()) then
				GuildRoster();   -- calling GuildRoster will force a callback on which should call ParseGuildInfo that will eventually initialize GuildInfo
			elseif ((time() - GGlocal.Magic) > 90) then 
				self:Guild2Guild_PrintDEBUG("player not in guild","ReadyToWork")
				self:DCF(cColors.cRed.."Player is not in a guild:"..cColors.cWhite.."disabling guild2guild.",1)
				self:SetActive(false)
				
				GGlocal.GuildInfoInitialized = true 
			end
			return false 
		end

		local firstChannelNumber = GetChannelList();
  		if (firstChannelNumber == nil) then
			self:Guild2Guild_PrintDEBUG("no channels yet","Ready to work")
			GGlocal.Magic = time() - GGVars.Startdelay + 3;
			return false;
		end

		if (Guild2Guild_Vars.GuildMemberNotify == nil) then
			SetCVar("guildMemberNotify", "1");
			Guild2Guild_Vars.GuildMemberNotify = "1"
		end
				
		local gmn = GetCVar("guildMemberNotify");
		if (gmn == nil or gmn == "0") then
			Guild2Guild_Vars.GuildMemberNotify = "0"
		else
			Guild2Guild_Vars.GuildMemberNotify = "1"
		end
				
		self:Guild2Guild_PrintDEBUG("guildMemberNotify",gmn, Guild2Guild_Vars.GuildMemberNotify, "ReadyToWork")			

		IgnoreList_Update();
		self:ParseFriendList();
		self:ParseIgnoreList();

		if (self.Finalizing) then return end
		self.Finalizing = true                        -- cheap hacky form of locking
		if (self.Ready) then return end

		if not self:Init_Channel() then 
			self.Finalizing = false;
			return false 
		end

		self:AddChatType()
		self.Ready = true
		return true
	end,


----------------------------
-- ParseFriendList - updates the current friendlist
----------------------------

	ParseFriendList = function (self)
		local GGlocal = Guild2Guild.LocalVars

		local numFriends=GetNumFriends();
		
		GGlocal.friends = {}
		for idx=1,numFriends do
			local name = GetFriendInfo(idx);
			if(name~=nil)then
				GGlocal.friends[name] = true
			end
		end
		self:Guild2Guild_PrintDEBUG("numFriends: "..numFriends, "ParseFriendList")
	end,
	
----------------------------
-- ParseIgnoreList - updates the current ignorelist
----------------------------

	ParseIgnoreList = function (self)
		local GGlocal = Guild2Guild.LocalVars

		local numIgnores=GetNumIgnores();
		
		GGlocal.ignores = {}
		
		for idx=1,numIgnores do
			local name = GetIgnoreName(idx);
			if(name~=nil)then
				GGlocal.ignores[name] = true
			end
		end
		self:Guild2Guild_PrintDEBUG("numIgnores: "..numIgnores, "ParseIgnoreList")
		self:CalculateRank()
	end,	

----------------------------
-- ParseGuildInfo - Looks for the Officer Rank (R) or the Allied Guilds (A) in the guild information and sets the communication levels appropriately
----------------------------

	ParseGuildInfo = function(self)
		local GGlocal = Guild2Guild.LocalVars
		local GGVars = Guild2Guild_Vars

		if ((not IsInGuild()) and ((time() - GGlocal.Magic) > 90)) then 
			self:Guild2Guild_PrintDEBUG("player not in guild","ParseGuildInfo")
			GGlocal.GuildInfoInitialized = true 
			Guild2GuildFrame:UnregisterEvent("GUILD_ROSTER_UPDATE")
			return true
		else
--			self:Guild2Guild_PrintDEBUG("guildcheck: (inGuild, elapsed time)",IsInGuild(),time() - GGlocal.Magic, "ParseGuildInfo")
		end

		local guildname, _, gr = GetGuildInfo("player");  -- zero based

		local guildinfotext= GetGuildInfoText()
		
		if (GGlocal.GuildInfoInitialized and GGlocal.GuildInfoText ~= nil and GGlocal.GuildInfoText == guildinfotext) then
			self:Guild2Guild_PrintDEBUG("GuildInfo Unchanged")
			return;
		end
		GGlocal.GuildInfoText = guildinfotext;
		
		GGlocal.RejectedRelays = {};
		
		if (guildinfotext == nil or (guildinfotext == "" and ((time() - GGlocal.Magic) < 90)) or guildname == nil or guildname == "") then 
			self:Guild2Guild_PrintDEBUG("guildname or guildinfotext empty",guildname, guildinfotext, "ParseGuildInfo")
			return false 
		end
		local found, _, g2gCommand = string.find(guildinfotext,"<G2G;([^>]-)>")
		self:Guild2Guild_PrintDEBUG("full command",g2gCommand,"ParseGuildInfo")

		local i = 0;
		while i < 10 and GGlocal.OfficerRank == nil do
			if (not (self:G2G_isOfficerRank(i))) then
				GGlocal.OfficerRank = i-1
			end
			i = i + 1;
		end

		while (found ~= nil) do
			local cmd, value;
			found, _, cmd, value, g2gCommand = string.find(g2gCommand, "(%a):([^;]-);(.*)")

			self:Guild2Guild_PrintDEBUG("subcommand",cmd, value,"ParseGuildInfo")

			if (cmd == "A") then
				local guildName = GetGuildInfo("player");
				GGlocal.AlliedGuilds = {}
				GGlocal.VerifiedGuilds= {}
				GGlocal.AlliedGuilds[guildName] = true
				GGlocal.VerifiedGuilds[guildName] = true
				for w in string.gmatch(value, "[^,]+") do
					GGlocal.AlliedGuilds[w] = true
					GGlocal.VerifiedGuilds[w] = true
				end
			elseif (cmd == "C") then
				Guild2Guild_Vars.Channel = value;
			elseif (cmd == "P") then
				Guild2Guild_Vars.Password = value;
			end
		end
		
		if (GGlocal.OfficerRank ~= nil) then
			GGlocal.PlayerIsOfficer = gr <= GGlocal.OfficerRank
			if (GGlocal.PlayerIsOfficer) then
				GGlocal.guildRankIndex = 9
			else
				GGlocal.guildRankIndex = 0
			end
		else
			GGlocal.guildRankIndex = 9 - gr;
		end


		local numGuildMembers=GetNumGuildMembers(true);
		local showOfflineTemp=GetGuildRosterShowOffline();
		SetGuildRosterShowOffline(true);
		
		for idx=1,numGuildMembers do
			local name = GetGuildRosterInfo(idx);

			if(name~=nil)then
				GGlocal.guildRoster[name] = true
			end
		end
		SetGuildRosterShowOffline(showOfflineTemp);
		
		self:Guild2Guild_PrintDEBUG("final",GGlocal.AlliedGuilds, GGlocal.OfficerRank, Guild2Guild_Vars.Channel, Guild2Guild_Vars.Password, "ParseGuildInfo")

--		Guild2GuildFrame:UnregisterEvent("GUILD_ROSTER_UPDATE")

		GGlocal.GuildInfoInitialized = true
		return true
	end,
    


----------------------------
-- G2G_isOfficerRank - helper function for the above
----------------------------
	G2G_isOfficerRank = function (self,rankIndex)
	
	       --get permission flags for that player's guild rank number
	       --have to add one here because SetRank() numbers from 1, while GetInfo() above numbers from 0
	       GuildControlSetRank(rankIndex + 1)
	       local permissionFlags = {GuildControlGetRankFlags()}
	
	       --if player can chat in officer channel, we return true.  false otherwise
	       if permissionFlags[4] and permissionFlags[4] == 1 then return true end
	
	       return false
	
	end,

----------------------------
-- Init_Channel - initializes the cross guild synchronization channel
----------------------------
	Init_Channel = function(self)
		local GGlocal = Guild2Guild.LocalVars
		local GGVars = Guild2Guild_Vars
		local cColors = Guild2Guild.tColors
		local bState = GGVars.Active
		if GGVars.Debug then self:DCF("fired.",5,"Init_Channel") end

		if GGVars.Debug then self:DCF("Channel Initialized",5,"Init_Channel") end

		-- join the channel			
		if bState and GGVars.Channel then
			self:JoinChannel(GGVars.Channel,GGVars.Password)

			local id = GetChannelName(GGVars.Channel);
			SetSelectedDisplayChannel(3)
			local channelCount = GetNumDisplayChannels();
			for i=1, channelCount, 1 do
				local name, _, _, dispNum = GetChannelDisplayInfo(i)
				if (dispNum == id) then
					SetSelectedDisplayChannel(i)
					break
				end
			end
			
			if (id == 0) then
				self:DCF(cColors.cRed.."Guild2Guild failed to join channel: "..cColors.cWhite..GGVars.Channel..cColors.cSilver.." Shutting down.",1)
				self:SetActive(false)
				return false
			else
				self:DCF(cColors.cBlue.."using channel: "..cColors.cWhite..GGVars.Channel.." "..id,1)
				ChatFrame_RemoveChannel(DEFAULT_CHAT_FRAME,GGVars.Channel)
			end
			GGlocal.LastUpdate = time() - 30;                  -- pretend that we have just received a message
			return true

		elseif not bState and GGVars.Channel then
			self:Guild2Guild_PrintDEBUG("leave channel:",GGVars.Channel,"Init_Channel") 
			--leave chan
			LeaveChannelByName(GGVars.Channel)
		elseif bState and not GGVars.Channel then
			self:DCF(cColors.cRed.."You must set a channel using "..cColors.cWhite.."/g2g channel "..cColors.cSilver.."["..cColors.cGold.."MY_CHANNEL"..cColors.cSilver.."]"..cColors.cRed.." before using this addon. Guild2Guild has been turned off. Please set a channel and then re-enable Guild2Guild with "..cColors.cWhite	.."/g2g on"..cColors.cSilver..".",1)
			self:SetActive(false)
		end
		return false
	end,

----------------------------
-- SetupChannelRoster - counts the number of people in the channel
----------------------------

	SetupChannelRoster = function(self,channelID)
		local GGVars = Guild2Guild_Vars
		local GGlocal = Guild2Guild.LocalVars
		channelName, _, _, channelNumber, count = GetChannelDisplayInfo(channelID);
		self:Guild2Guild_PrintDEBUG(channelID, channelName, channelNumber, count, "SetupChannelRoster") 

		if (channelName ~= GGVars.Channel) then
			return
		end

		GGlocal.channelRoster = {}
		for id=1, count, 1 do
			name = GetChannelRosterInfo(channelID, id)
			if (name ~= nil) then
				GGlocal.channelRoster[name] = true
			end
		end
		Guild2GuildFrame:UnregisterEvent("CHANNEL_ROSTER_UPDATE")
	end,

----------------------------
-- Hook_UI - sets up the new chat handler which prevents messages from Guild2Guild from appearing on the screen
----------------------------

	Hook_UI = function(self)
		local GGVars = Guild2Guild_Vars

		local GGlocal = Guild2Guild.LocalVars
		self:Guild2Guild_PrintDEBUG("Hooking UI") 

		local GGVars = Guild2Guild_Vars
		local bState = GGVars.Active
	
		if (bState) then
			if (G2GOldChatHandler == nil) then
				G2GOldChatHandler = ChatFrame_OnEvent
				ChatFrame_OnEvent = Guild2Guild.NewChatHandler
				self:Guild2Guild_PrintDEBUG("set NewChatHandler") 
			end

			if (G2GOldChangeChatColor == nil) then
				G2GOldChangeChatColor = ChangeChatColor
				ChangeChatColor = Guild2Guild.NewChangeChatColor
				
				self:Guild2Guild_PrintDEBUG("set NewChangeChatColor") 
			end
				
			self:Guild2Guild_PrintDEBUG("UI Hooked") 

		else
			if (G2GOldChatHandler ~= nil) then
				ChatFrame_OnEvent = G2GOldChatHandler
				G2GOldChatHandler = nil
			end
				
			if (G2GOldChangeChatColor ~= nil) then
				ChangeChatColor = G2GOldChangeChatColor
				G2GOldChangeChatColor = nil
			end

			self:Guild2Guild_PrintDEBUG("UI Unhooked") 
		end
	end,

----------------------------
-- NewChatHandler - used to avoid displaying chat messages sent by Guild2Guild
----------------------------

	NewChatHandler = function (self,event,...)
		local msg, realSender, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13 = ...;
		
		-- use the gloabal arg1 and arg2 so that programs like Prat and Phanxchat work as expected.
		arg1 = msg;
		arg2 = realSender;
		
		-- Use a "return" command to prevent the incoming messsages that we don't want
		-- from appearing in the chat frame.

		if (event == "CHAT_MSG_WHISPER") then
			if (arg1 and arg1 ~= nil) then
				if (string.sub(arg1,1,3) == "G2G") then
					return;
				end
			end

		elseif (event == "CHAT_MSG_WHISPER_INFORM") then
			if (arg1 and arg1 ~= nil) then
				if (string.sub(arg1,1,3) == "G2G") then
					return;
				end
			end
  		elseif event == "CHAT_MSG_CHANNEL" and arg9 and arg9 ~= nil and strlower(arg9) == strlower(Guild2Guild_Vars.Channel) then
			return;
  		elseif event == "CHAT_MSG_GUILD" or event == "CHAT_MSG_OFFICER" then
--			Guild2Guild.Guild2Guild_PrintDEBUG(Guild2Guild,"inc", arg2, Guild2Guild.LocalVars.Leader, "NewChatHandler1")

		  	if (arg2 and arg2 ~=nil and Guild2Guild.LocalVars.Leader and Guild2Guild.LocalVars.Leader ~= nil and arg2 == Guild2Guild.LocalVars.Leader) then
				if (arg1 and arg1 ~= nil) then
					if (string.sub(arg1,1,1) == "[") then
--						Guild2Guild.Guild2Guild_PrintDEBUG(Guild2Guild,"inc", arg1,arg2, arg12,"NewChatHandler2")

						local found, realSender, msg
						found,_,realSender,msg = string.find(arg1, "%[([^%]]*)%]: (.*)")
						if (found) then
							if (Guild2Guild_Vars.Silent) then
								Guild2Guild.Guild2Guild_PrintDEBUG(Guild2Guild,"squelch", arg1,arg2,"NewChatHandler2")
								return
							end

							arg1 = Guild2Guild_Vars.color..msg
							arg2 = realSender -- to see if setting the global variable helps
                                                        guid = Guild2Guild_Vars.CachedPlayerIDs[arg2];
							if (guid) then
								arg12 = guid
                                                            else
                                                                arg12=""
							end
			
--							Guild2Guild.Guild2Guild_PrintDEBUG(Guild2Guild,"disp", arg1,realSender,arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11,arg12,"NewChatHandler3")
						end
						
						if (Guild2Guild.LocalVars.ignores[arg2]) then
							return
						end
					end			
				end
			end
		end
--		Guild2Guild.Guild2Guild_PrintDEBUG(Guild2Guild,"inc", event, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12)

	-- Call the original ChatFrame_OnEvent function for default handling of the event.
	G2GOldChatHandler(self, event, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13);

	end,

----------------------------
-- NewChangeChatColor - used to catch changes in chat text colour
----------------------------
	NewChangeChatColor = function(chatType, r, g, b)
		Guild2Guild.Guild2Guild_PrintDEBUG(Guild2Guild,chatType, r, g, b,"NewChangeChatColor")
		
		if ( chatType and chatType == "G2G" and ChatTypeInfo[chatType] ) then
			ChatTypeInfo[chatType].r = r;
			ChatTypeInfo[chatType].g = g;
			ChatTypeInfo[chatType].b = b;
			Guild2Guild_Vars.chatTypes[chatType].r = r;
			Guild2Guild_Vars.chatTypes[chatType].g = g;
			Guild2Guild_Vars.chatTypes[chatType].b = b;
			
			Guild2Guild_Vars.color = Guild2Guild.RGBToHex(r,g,b)
		end
		G2GOldChangeChatColor(chatType, r, g, b)
	end,
	
	RGBToHex = function (r, g, b)
		r = r * 255
		g = g * 255
		b = b * 255
		return string.format("|cff%02x%02x%02x", r, g, b)
	end, 

	
--[[ 		
		�������������������������
		  Main Event Processor	  
		�������������������������
]]--

----------------------------
-- SendG2GSyncMessage - Universal Synchronization message sender
----------------------------

	SendG2GSyncMessage = function(self, msgType, additionalMsg)
		local GGVars = Guild2Guild_Vars	   
		local GGlocal = Guild2Guild.LocalVars
		
		local sMsg = "<G2G"..self.VerNum..">"..msgType..GGlocal.localRank..GGlocal.Magic;
		
		if (not(additionalMsg == nil)) then
			sMsg = sMsg..";"..additionalMsg
		end
		ChatThrottleLib:SendAddonMessage("ALERT", "G2G", sMsg, "GUILD");
	end,

----------------------------
-- SendCrossGuildSyncMessage- Universal Synchronization message sender
----------------------------

	SendCrossGuildSyncMessage = function(self, msgType, dest, player)
		local GGVars = Guild2Guild_Vars	   
		local GGlocal = Guild2Guild.LocalVars
		local guildName = GetGuildInfo("player");

		local sID, sName = GetChannelName(GGVars.Channel)
		local sMsg = "<G2G"..self.VerNum..">"..guildName..";"..GGlocal.guildRankIndex..msgType
		
		if (dest == "CHANNEL") then
			ChatThrottleLib:SendChatMessage("ALERT", "G2G", sMsg,"CHANNEL",GetDefaultLanguage("player"),sID)
		elseif (dest == "PLAYER") then
			ChatThrottleLib:SendAddonMessage("ALERT", "G2G", sMsg, "WHISPER",player)
		end
	end,

----------------------------
-- SendLeaderMessage - send the message to inform the world that we are the relay
----------------------------

	SendLeaderMessage = function(self, sendToChannel)
		local GGlocal = Guild2Guild.LocalVars

		if (sendToChannel) then
			if (not GGlocal.sentInitLeaderMessage) then
				self:SendCrossGuildSyncMessage("I", "CHANNEL", nil)
				GGlocal.sentInitLeaderMessage = true
			end

			self:SendCrossGuildSyncMessage("L", "CHANNEL", nil)
			GGlocal.LastCrossGuildUpdate = time()
		end

		self:SendG2GSyncMessage("L")
		GGlocal.LastUpdate = time()
	end,

----------------------------
-- SendElectionMessage - send the info about ourselves to see if we should be the relay
----------------------------

	SendElectionMessage = function(self, reset)
		local GGlocal = Guild2Guild.LocalVars

		if (time() > GGlocal.lastElectionMessageTime) then
			GGlocal.ElectionCalled = true
			self:Guild2Guild_PrintDEBUG("calling election","SendElectionMessage")

			
			if (reset) then
				GGlocal.CurrMax = 0
				GGlocal.CurrMaxVersion = 0
			end
	
			self:SendG2GSyncMessage("E")
			GGlocal.LastUpdate = time()
			GGlocal.lastElectionMessageTime = time()
		end
	end,


----------------------------
-- SendLocalQueryMessage - send the info about ourselves to see if we should be the relay
----------------------------

	SendLocalQueryMessage = function(self)
		self:Guild2Guild_PrintDEBUG("sending query","SendQueryMessage")
		local GGlocal = Guild2Guild.LocalVars

		GGlocal.sentQueryMessage = true
		GGlocal.awaitingQueryResponse = true

		GGlocal.LastUpdate = time()
		self:SendG2GSyncMessage("Q")
	end,

----------------------------
-- SendRejectionLetter - 
----------------------------

	SendRejectionLetter = function(self, recipient)
		self:Guild2Guild_PrintDEBUG("sending rejection to "..recipient,"SendRejectionLetter")
		self:SendCrossGuildSyncMessage("R", "PLAYER" , recipient)
	end,

----------------------------
-- OnUpdate - makes sure that heartbeat messages get transmitted
----------------------------
	OnUpdate = function(self,event,arg1)
		local GGVars = Guild2Guild_Vars	   
		local GGlocal = Guild2Guild.LocalVars

		if not GGVars.Active then return end

		if not self:ReadyToWork() then return end

		if (GGlocal.Leader == UnitName("player")) then
			local timeout = 55
			if (GGlocal.ElectionCalled or GGlocal.OldestVersion < 810) then timeout = 10 end
			local shouldSendCrossGuildUpdate = (not GGlocal.ElectionCalled) and             -- don't send an update until the election is over
									time() - GGlocal.LastCrossGuildUpdate > 300    
			if (time() - GGlocal.LastUpdate > timeout or shouldSendCrossGuildUpdate) then
				local sendToChannel = GGlocal.ElectionCalled or shouldSendCrossGuildUpdate
				self:SendLeaderMessage(sendToChannel)
			end
		else
			local timeout = 65
			if (GGlocal.awaitingQueryResponse) then timeout = 10 end
			if (time() - GGlocal.LastUpdate > timeout) then  
				self:Guild2Guild_PrintDEBUG("Calling election due to no heartbeat") 
				self:SendElectionMessage(true)
			end
		end
--		self:executeGUIs("OnUpdate")
		
	end,

----------------------------
-- OnEvent - Main Event Handler
----------------------------

	OnEvent = function(self, event, ...)

		-- JAXOM TAKE NOTE !!!!! Need reworking in next version (NTS: Only set used variable for each events)
        
		local arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12 = ...;
		self:Guild2Guild_PrintDEBUG2(event,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12,"OnEvent")
		if (event == "ADDON_LOADED") then
			self.Loaded = true
			if Guild2Guild_Vars and Guild2Guild_Vars.Debug then self:DCF("ADDON_LOADED",5,"OnEvent") end
			return self:GG_Init()
		end

		if not self.Loaded then 
			if Guild2Guild_Vars and Guild2Guild_Vars.Debug then self:DCF("returning early because ADDON_LOADED = false",5,"OnEvent") end
			return 
		end
		if not self.Initialized then
			if Guild2Guild_Vars and Guild2Guild_Vars.Debug then self:DCF("returning early because self.Initialized = false",5,"OnEvent") end
			return self:GG_Init()
		end

		local GGVars = Guild2Guild_Vars

		if not GGVars.Active then return end

		if (event == "PLAYER_ALIVE") then
			GuildRoster();
			Guild2GuildFrame:UnregisterEvent("PLAYER_ALIVE")
			return
		elseif (event == "GUILD_ROSTER_UPDATE") then
			self:ParseGuildInfo()
			return
		elseif (event == "FRIENDLIST_UPDATE") then
			self:ParseFriendList()
			return
		elseif (event == "IGNORELIST_UPDATE") then
			self:ParseIgnoreList()
			return
		elseif (event == "CHANNEL_ROSTER_UPDATE") then
			self:SetupChannelRoster(arg1)
			return
		end

		local cColors = Guild2Guild.tColors
		local GGlocal = Guild2Guild.LocalVars

		if (event == "CHAT_MSG_CHANNEL_NOTICE" and arg1 == "WRONG_PASSWORD" and arg9 == GGVars.Channel) then
			GGlocal.failedAttempts = GGlocal.failedAttempts + 1;
			self:Guild2Guild_PrintDEBUG(event, GGlocal.failedAttempts, "WRONG_PASSWORD") 
			
			if (GGlocal.failedAttempts > 3) then
				self:Guild2Guild_PrintDEBUG("too many attempts","Ready to work")
				self:DCF(cColors.cRed.."Channel Password is set incorrectly "..cColors.cWhite.."disabling guild2guild.",1)
				self:SetActive(false)
				return
			end
		end
		
		if not self:ReadyToWork() then return end;

		local guildname = GetGuildInfo("player")
		if (not (IsInGuild()) or guildname == nil) then
			self:SetActive(false)
			self:DCF(cColors.cRed.."Player is not in a guild:"..cColors.cWhite.."disabling guild2guild.",1)
        elseif (GGlocal.AlliedGuilds == nil) then
            self:DCF(cColors.cRed.."There are no Allied Guilds:"..cColors.cWhite.."disabling guild2guild.",1)
		    self:SetActive(false)    
		end

		if (not GGlocal.sentQueryMessage) then
			self:SendLocalQueryMessage()
		end
		local sID, sName = GetChannelName(GGVars.Channel)	

		if GGVars.Channel then	
			if sID == 0 or sName == nil then
				if Guild2Guild_Vars and Guild2Guild_Vars.Debug then self:DCF("It should be impossible to get here but I did",5,"OnEvent") end
				if not self:Init_Channel() then return end
			end
		else
			if not self:Init_Channel() then return end
		end

		if (event == "CHAT_MSG_CHANNEL_LEAVE" and strlower(arg9) == strlower(GGVars.Channel)) then
			GGlocal.channelRoster[arg2] = nil
			if (GGlocal.ignores[arg2] ~= nil) then
				self:CalculateRank()
			end

			self:HandlePlayerLeaving(arg2)
		elseif (event == "CHAT_MSG_CHANNEL_JOIN" and strlower(arg9) == strlower(GGVars.Channel)) then
			GGlocal.channelRoster[arg2] = true
			GGVars.CachedPlayerIDs[arg2] = arg12
			if (GGlocal.ignores[arg2] ~= nil) then
				self:CalculateRank()
			end
		elseif (event == "CHAT_MSG_ADDON") then
			if (arg1 == "G2G") then
				if (arg3 == "GUILD") then
					self:HandleGuildSyncMessage(arg2,arg4)
				elseif (arg3 == "WHISPER") then
					self:HandleIncomingGuildMessage(arg2, arg4, arg12)
				end
			elseif ((arg3 == "GUILD") and (GGlocal.Leader == UnitName("player"))) then
				self:ForwardAddOnMessage(arg1, arg2,arg4)
			end
  		elseif event == "CHAT_MSG_CHANNEL" and strlower(arg9) == strlower(GGVars.Channel) then
  			local addOnMessage = false
			self:HandleChannelSyncMessage(arg1,arg2,addOnMessage,arg12)
		elseif event == "CVAR_UPDATE" and arg1 == "GUILDMEMBER_ALERT" then
			Guild2Guild_Vars.GuildMemberNotify = arg2
			self:Guild2Guild_PrintDEBUG(event,arg1,arg2, "OnEvent") 
			self:CalculateRank()
		end

		if ( not (GGlocal.Leader == (UnitName("player")))) then
			return    -- don't worry about these other messages if we aren't the leader
		end

		if (event == "CHAT_MSG_CHANNEL_JOIN" and strlower(arg9) == strlower(GGVars.Channel)) then
			local sendToChannel = true
			return self:SendLeaderMessage(sendToChannel)

		elseif (event == "CHAT_MSG_SYSTEM") then
			self:HandleChatMessageSystem(arg1,arg12)
			
		elseif (event == "CHAT_MSG_GUILD_ACHIEVEMENT" or (event == "CHAT_MSG_ACHIEVEMENT" and arg2 == UnitName("player"))) then
			self:HandleChatMessageAchievement(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12)
	
		elseif (event == "CHAT_MSG_GUILD" and GGVars.EchoGuild)
			or (event == "CHAT_MSG_OFFICER" and GGVars.EchoOfficer) then
			self:HandleOutgoingGuildMessage (event, arg1, arg2)
				
		elseif event == "CHAT_MSG_WHISPER" and string.sub(arg1,1,3) == "G2G" then
			self:HandleIncomingGuildMessage (arg1, arg2, arg12)
   		end
   	end,

----------------------------
-- HandlePlayerLeaving - 
----------------------------

	HandlePlayerLeaving = function(self, arg2)
		local GGlocal = Guild2Guild.LocalVars
		self:Guild2Guild_PrintDEBUG(arg2,"left","HandlePlayerLeaving") 

		if (GGlocal.Leader == arg2) then
			self:Guild2Guild_PrintDEBUG("leader left - calling election","HandlePlayerLeaving") 
			return self:SendElectionMessage(true)
		end

		local guild = GGlocal.Relays[arg2]
		if (guild ~= nil) then
			self:Guild2Guild_PrintDEBUG(arg2,"relay left","HandlePlayerLeaving") 
			GGlocal.Relays[arg2] = nil
			ChatThrottleLib:ClearPipe(ChatThrottleLib:PipeName("G2G", "WHISPER", arg2))
			if (not (GGlocal.Guilds[guild] == nil) and GGlocal.Guilds[guild][1] == arg2) then
				GGlocal.Guilds[guild]=nil
			end
		end
--		self:executeGUIs("sync", guild, arg2)
	end,

----------------------------
-- HandleGuildSyncMessage - 
----------------------------

	HandleGuildSyncMessage = function(self,message,sender)
		local GGlocal = Guild2Guild.LocalVars
		self:Guild2Guild_PrintDEBUG(message, sender, "HandleGuildSyncMessage")

		local found,sVersion,version,sCmd,sMsg,sMsg2,rest
		found,_,sVersion,sCmd,sMsg,sMsg2,rest = string.find(message,"<G2G([^>]+)>(%w)(.-);(.-);(.*)")
		if (found ~= 1) then
			found,_,sVersion,sCmd,sMsg = string.find(message,"<G2G([^>]+)>(%w)(.*)")
			sMsg2 = ""
		end
		if (found ~= 1) then
			sVersion = "808"
			found,_,sCmd,sMsg = string.find(message,"(%w)(.*)")
			if found ~= 1 then
				self:DCF("Guild2Guild: Obsolete version detected, please ask "..sender.." to upgrade", 1)
				return
			end
		end 
--		self:Guild2Guild_PrintDEBUG("parsed",found,sVersion,sCmd,sMsg,"HandleGuildSyncMessage")

		version = tonumber(sVersion)
		if (version > self.VerNum and not GGlocal.WarnedVersionNum) then
			self:DCF("A new version of Guild2Guild was detected, please upgrade",1)
			GGlocal.WarnedVersionNum = true;
		end

		GGlocal.versions[sender] = version
		
		if (GGlocal.OldestVersion > version) then 
			GGlocal.OldestVersion = version
		end

		if  sCmd== "L" then
			GGlocal.ElectionCalled = false
			self:ReceiveLeaderMessage(sMsg, version, sender)

		elseif sCmd == "E" then
			value = tonumber(sMsg)

--			self:Guild2Guild_PrintDEBUG("Election, magic: "..value.."curmax"..GGlocal.CurrMax.."ver"..version.."curmaxver"..GGlocal.CurrMaxVersion,"HandleGuildSyncMessage")
			if (version > GGlocal.CurrMaxVersion or (value >= GGlocal.CurrMax and version == GGlocal.CurrMaxVersion)) then
				GGlocal.CurrMax = value
				GGlocal.Leader = sender
				GGlocal.CurrMaxVersion = version
			elseif GGlocal.Leader == UnitName("player") then
				self:Guild2Guild_PrintDEBUG("Calling election - defending current position") 
				self:SendElectionMessage(false)
			end
		elseif (sCmd == "Q" and GGlocal.Leader == UnitName("player")) then
			local sendToChannel = false
			self:SendLeaderMessage(sendToChannel)
			
		elseif (sCmd == "X") then
			self:HandleGuildAuxMessage(rest)
		end
	end,

----------------------------
-- ReceiveLeaderMessage - 
----------------------------	
	ReceiveLeaderMessage = function(self, sMsg, version,sender)
		local GGlocal = Guild2Guild.LocalVars
		local relayIsAnOfficer = string.sub(sMsg,1,1) == "9"

		local leaderRank = tonumber(string.sub(sMsg, 1, 3))
		if (GGlocal.localRank >= leaderRank) and (version < self.VerNum) then
			self:Guild2Guild_PrintDEBUG("Calling election due to newer version") 
			self:SendElectionMessage(false)
			return
		end

		if (self.VerNum == version and GGlocal.localRank > leaderRank) then
			self:Guild2Guild_PrintDEBUG("Calling election due to lower rank") 
			self:SendElectionMessage(false)
			return
		end
			
		GGlocal.Leader = sender
		GGlocal.CurrMax= tonumber(sMsg)
		GGlocal.LastUpdate = time()
		GGlocal.CurrMaxVersion = 0
		GGlocal.awaitingQueryResponse = false
	end,

----------------------------
-- CalculateRank - 
----------------------------	
	CalculateRank = function(self)

		local GGlocal = Guild2Guild.LocalVars
		local GGVars = Guild2Guild_Vars	
		
		local officerBonus = 200
		
		if (GGVars.Passive or GGVars.Silent) then
			officerBonus = 100
		elseif (GGlocal.PlayerIsOfficer) then
			officerBonus = 900
		end
		
		local numIgnores = 0;
		for player, value in pairs(GGlocal.ignores) do
			if (GGlocal.channelRoster[player] or GGlocal.guildRoster[player]) then
				numIgnores = numIgnores + 1
			end
		end
		
		if numIgnores > 9 then
			numIgnores = 9
		end
		
		local ignoreCount = (9 - numIgnores) * 10
		
		local guildRelay = 0
		if (GGVars.GuildMemberNotify ~= nil and GGVars.GuildMemberNotify ~= "0") then
			guildRelay = 2
		end
		
		GGlocal.localRank = officerBonus + ignoreCount + guildRelay

		self:Guild2Guild_PrintDEBUG("CalculateRank", GGlocal.localRank)
	end,
		
----------------------------
-- HandleChannelSyncMessage - 
----------------------------

	HandleChannelSyncMessage = function(self,message,sender,addOnMessage,guid)
		local GGlocal = Guild2Guild.LocalVars

		self:Guild2Guild_PrintDEBUG("relay heartbeat:"..message.."->"..sender,addOnMessage,"HandleChannelSyncMessage")

		local found,sVersion,version,guild,officer,sCmd
		found,_,sVersion,guild,officer,sCmd = string.find(message,"<G2G([^>]+)>(.*);(%w)(%w)")
		if (found ~= 1) then 
			sCmd = "L"
			found,_,sVersion,guild,officer = string.find(message,"<G2G([^>]+)>(.*);(%w)")
		end
		if (found ~= 1) then return end
			
		version = tonumber(sVersion)
		if (version > self.VerNum and not GGlocal.WarnedVersionNum) then
			self:DCF("A new version of Guild2Guild was detected, please upgrade",1)
			GGlocal.WarnedVersionNum = true;
		end

		if (sCmd == "L" or sCmd == "I") then
			self:UpdateRelayInfo(guild,sender,version,officer, sCmd=="I",addOnMessage,guid)

		elseif (sCmd == "Q" and GGlocal.Leader == UnitName("player")) then
			self:SendCrossGuildSyncMessage("L", "PLAYER", sender)

		elseif (sCmd == "R") then
			self:HandleRejection(guild,sender)
		end
	end,

----------------------------
-- UpdateRelayInfo - 
----------------------------
	UpdateRelayInfo = function(self,guild,sender,version,officer, reintialize, addOnMessage, guid)
		self:Guild2Guild_PrintDEBUG(guild, sender, version, officer, addOnMessage,"UpdateRelayInfo")
		local GGlocal = Guild2Guild.LocalVars
		local GGVars = Guild2Guild_Vars	

		if (addOnMessage) then
			GGlocal.VerifiedGuilds[guild] = true
		end

		if (GGlocal.VerifiedGuilds[guild] == nil) then
			-- in order to avoid drunk guild names, ask for the addon message directly
			if (GGlocal.Leader == UnitName("player") and version >= 810) then
				self:SendCrossGuildSyncMessage("Q", "PLAYER", sender)
				GGlocal.VerifiedGuilds[guild] = false
			end
		end
		
		if ((GGlocal.Leader == UnitName("player")) and not(GGlocal.VerifiedGuilds[guild])) then
			return
		end
			
		if (GGlocal.AlliedGuilds == nil or (GGlocal.AlliedGuilds[guild] ~= nil and GGlocal.AlliedGuilds[guild])) then
			if (GGVars.ShowNewRelayMessages and (GGlocal.Guilds[guild] ~= nil and GGlocal.Guilds[guild][1] ~= sender)) then
				self:DCF(guild.." just elected a new relay: ".. sender,1)
			end

			if ((GGlocal.Leader == UnitName("player") and (GetGuildInfo("player") ~= guild)) and 
					(reinitialize or 
					 GGlocal.Guilds[guild] == nil or 
					 (GGlocal.Guilds[guild] ~= nil and GGlocal.Guilds[guild][1] ~= sender))) then
				if (version < 810) then
					self:SendCrossGuildSyncMessage("L", "CHANNEL", nil)
				else
					self:SendCrossGuildSyncMessage("L", "PLAYER", sender)
				end
			end
			
			GGlocal.Guilds[guild] = {sender,version,officer == "9",time(),GGlocal.VerifiedGuilds[guild]}
			GGlocal.Relays[sender] = guild
			GGlocal.versions[sender] = version
			GGlocal.gLeader[guild] = sender
			GGVars.CachedPlayerIDs[sender] = guid
		else
			if (GGlocal.AlliedGuilds[guild] == nil) then
				self:DCF("Refused incoming connection from:"..guild.." initiated by:".. sender,1)
				GGlocal.AlliedGuilds[guild] = false
				GGlocal.VerifiedGuilds[guild] = false
			end
		end
	end,

----------------------------
-- HandleRejection - 
----------------------------
	HandleRejection = function(self,guild,sender)
		local GGlocal = Guild2Guild.LocalVars

		self:DCF("The connection to the guild:"..guild.." was refused by ".. sender,1)
		if (GGlocal.AlliedGuilds[guild] == nil or GGlocal.AlliedGuilds[guild] == false) then
			GGlocal.AlliedGuilds[guild] = false
			GGlocal.VerifiedGuilds[guild] = false
			GGlocal.Guilds[guild] = nil
		end
	end,

----------------------------
-- HandleOutgoingGuildMessage - 
----------------------------

	HandleOutgoingGuildMessage = function(self, event,message, sender)
		local GGlocal = Guild2Guild.LocalVars
	
--		self:Guild2Guild_PrintDEBUG("outgoing message",sender, message, "HandleOutgoingGuildMessage")
		if (sender == UnitName("player")) and (string.find(message,"%[.*%]:%s") or string.find(message,"Guild2Guild:")) then return end
		local sMod = "G"
		if event == "CHAT_MSG_OFFICER" then
			sMod = "O"
		end
		local sMsg = {"G2G"..sMod.."["..sender.."]: "..message}

		local nMessages = 1
		local cut = 128;
		if (string.len(sMsg[1]) > 251) then
			nMessages = 2;
			local secondString = string.sub(sMsg[1],cut)
			local linkEnd = string.find(secondString,"|r")
			local linkStart = string.find(secondString,"|c")
			if (linkEnd ~= nil and linkEnd > 0 and (linkStart == nil or linkStart < 0 or linkStart > linkEnd)) then
				cut = string.find(sMsg[1],"|c[^%]]-%]|h|r",cut)
				
				if (cut < 0) then
					cut = 127
				end
				
				secondString = string.sub(sMsg[1],cut)
			end
				
			sMsg[2] = "G2G"..sMod.."["..sender.."]: "..secondString;
			sMsg[1] = string.sub(sMsg[1],1,cut-1)
		end
		for msg = 1, nMessages do
			for key, value in pairs(GGlocal.Guilds) do
				if (key ~= GetGuildInfo("player")) then
					if (value and value ~= nil and value[1] ~= nil and value[1] ~= UnitName("player") and value[5]) then
						if (value[2] < 729) then
							print("i got to this part!")
							ChatThrottleLib:SendChatMessage("NORMAL", "G2G", sMsg[msg],"WHISPER",GetDefaultLanguage("player"),value[1])
						else
							ChatThrottleLib:SendAddonMessage("NORMAL", "G2G", sMsg[msg], "WHISPER",value[1])
						end
					end
				end
			end
		end	
	end,
	
----------------------------
-- HandleChatMessageSystem - 
----------------------------

	HandleChatMessageSystem = function(self, arg1, guid)
		local GGlocal = Guild2Guild.LocalVars
	
		local player;
		local event;
		
		_, _, player = string.find(arg1, G2G_ONLINE)
		if (player) then
--			self:Guild2Guild_PrintDEBUG(event,arg1,player, "online") 
			if (GGlocal.guildRoster[player] == nil) then
				self:Guild2Guild_PrintDEBUG("skipping", event,arg1,player, "player not in guild") 
				return
			end
			event = "N"
			self:SendOutgoingAuxMessage(player,event, "");
			return
		end
			
		_, _, player = string.find(arg1, G2G_OFFLINE)
		if (player) then
			if (GGlocal.guildRoster[player] == nil) then
				self:Guild2Guild_PrintDEBUG("skipping", event,arg1,player, "player not in guild") 
				return
			end

--			self:Guild2Guild_PrintDEBUG(event,arg1,player, "offline") 
			event = "F"
			self:SendOutgoingAuxMessage(player,event, "");
			return
		end

		_, _, player = string.find(arg1, G2G_JOINED)
		if (player) then
			GGlocal.guildRoster[player] = true
--			self:Guild2Guild_PrintDEBUG(event,arg1,player, "joined") 
			event = "J"
			self:SendOutgoingAuxMessage(player,event, "");
			return
		end
		
		_, _, player = string.find(arg1, G2G_LEFT)
		if (player) then
			GGlocal.guildRoster[player] = nil
--			self:Guild2Guild_PrintDEBUG(event,arg1,player, "left") 
			event = "L"
			self:SendOutgoingAuxMessage(player,event, "");
			return
		end		

		_, _, promoter, player, rank = string.find(arg1, G2G_PROMO)
		if (player) then
--			self:Guild2Guild_PrintDEBUG(event,arg1,promoter, player, rank, "promo")
			event = "P"
			self:SendOutgoingAuxMessage(player,event,promoter..";"..rank);
			return
			 
		end
			
		_, _, demoter, player, rank = string.find(arg1, G2G_DEMOTE)
		if (player) then
--			self:Guild2Guild_PrintDEBUG(event,arg1,demoter, player, rank, "demote")
			event = "D"
			self:SendOutgoingAuxMessage(player,event, demoter..";"..rank);
			return
		end
		
	end,

----------------------------
-- HandleChatMessageAchievement - 
----------------------------
	HandleChatMessageAchievement = function(self, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12)
		self:Guild2Guild_PrintDEBUG("HandleChatMessageAchievement", arg1, arg2, arg12)

		_, _, _, achievement = string.find(arg1, G2G_ACHIEVEMENT)

                local extra = achievement..";"..arg12..";"
		local event;
		event = "C"
		self:SendOutgoingAuxMessage(arg2,event, extra);
	end,

----------------------------
-- SendOutgoingAuxMessage - 
----------------------------

	SendOutgoingAuxMessage = function(self, player, event, extra)
		local GGlocal = Guild2Guild.LocalVars
		self:Guild2Guild_PrintDEBUG("outgoing message",player, event, extra, "SendOutgoingAuxMessage")

		local sMod = "X"
		local sMsg = sMod..";"..event..";"..player..";"..GetGuildInfo("player")..";"..extra

		for key, value in pairs(GGlocal.Guilds) do
			if (key ~= GetGuildInfo("player")) then
				if (value and value ~= nil and value[1] ~= nil and value[1] ~= UnitName("player") and value[5]) then
					if (value[2] > 741) then
						ChatThrottleLib:SendAddonMessage("BULK", "G2G",sMsg,"WHISPER",value[1])
					end
				end
			end
		end	
	end,
	
----------------------------
-- ForwardAddOnMessage - 
----------------------------

	ForwardAddOnMessage = function (self, sAddon, message,sender)
		local GGlocal = Guild2Guild.LocalVars
		local GGVars = Guild2Guild_Vars	
		
		
		if (sender == UnitName("player") and not (GGlocal.receivedAddonMessage == nil) and sAddon == GGlocal.receivedAddonMessage[1] and message == GGlocal.receivedAddonMessage[2]) then
			return
		end
		
		if ( time() > GGlocal.lastAddonMessageTime) then  -- rudimentary chat throttling
			GGlocal.lastAddonMessageTime = time()
		else
			return
		end
		
		if (GGVars.addons == nil) then
			GGVars.addons = DefaultGuild2Guild_Vars.addons;
		end
		
		if (GGVars.RelayAddonMessages == nil) then
			GGVars.RelayAddonMessages = DefaultGuild2Guild_Vars.RelayAddonMessages;
		end
		
		if (not (GGVars.RelayAddonMessages)) then
			return
		end
		
		if (GGVars.NewAddonDefault == nil) then
			GGVars.NewAddonDefault = DefaultGuild2Guild_Vars.NewAddonDefault;
		end
			
		if (GGVars.addons[sAddon] == nil) then
			GGVars.addons[sAddon] = GGVars.NewAddonDefault;
		elseif not (GGVars.addons[sAddon]) then
--			self:Guild2Guild_PrintDEBUG("rejecting message",sAddon, message, sender, "ForwardAddOnMessage")
			return
		end
		
--		self:Guild2Guild_PrintDEBUG("outgoing message",sAddon, message, sender, "ForwardAddOnMessage")
		local sMsg = "A"..sAddon..";"..message

		if (string.len(sMsg) > 251) then
			self:Guild2Guild_PrintDEBUG("message too long",sAddon, message, sender, "ForwardAddOnMessage")
			GGVars.addons[sAddon] = false;
			return
		end

		for key, value in pairs(GGlocal.Guilds) do
			if (key ~= GetGuildInfo("player")) then
				if (value and value ~= nil and value[1] ~= nil and value[1] ~= UnitName("player") and value[5]) then
					if (value[2] > 734) then
						ChatThrottleLib:SendAddonMessage("BULK", "G2G",sMsg,"WHISPER",value[1])					
					end
				end
			end
		end
	end,

----------------------------
-- HandleForwardedAddonMessage - 
----------------------------
	HandleForwardedAddonMessage = function (self, message)
		local found, addon, sMsg
		local GGlocal = Guild2Guild.LocalVars
		local GGVars = Guild2Guild_Vars	
		
		found,_, addon, sMsg = string.find(message,"A([^;]-);(.*)")
		
		if (GGVars.addons == nil) then
			GGVars.addons = DefaultGuild2Guild_Vars.addons;
		end
			
		if (GGVars.addons[addon] == nil) then
			GGVars.addons[addon] = true;
		elseif not (GGVars.addons[addon]) then
--			self:Guild2Guild_PrintDEBUG("rejecting message",sAddon, sMsg, "HandleForwardedAddonMessage")
			return
		end
		
		self:Guild2Guild_PrintDEBUG("received",addon,sMsg, "HandleForwardedAddonMessage")

		GGlocal.receivedAddonMessage = {addon,sMsg}
		
		if (found) then
			ChatThrottleLib:SendAddonMessage("BULK",addon,sMsg,"GUILD")
		end
	end,

----------------------------
-- HandleForwardedAuxMessage - 
----------------------------
	HandleForwardedAuxMessage = function (self, message)
		self:Guild2Guild_PrintDEBUG("received",message, "HandleForwardedAuxMessage")
		self:SendG2GSyncMessage("X",message)
	end,

----------------------------
-- HandleGuildAuxMessage - 
----------------------------
	HandleGuildAuxMessage = function (self, message)
		local found, guild, rest
		local GGlocal = Guild2Guild.LocalVars
		local GGVars = Guild2Guild_Vars	
		
		if (GGVars.Silent) then
			return
		end
		
		found,_, event, player, guild, rest = string.find(message,"(.);([^;]-);([^;]-);(.*)")
		
		self:Guild2Guild_PrintDEBUG("received",event,player, guild, rest, "HandleGuildAuxMessage")

		local sMsg = nil;
		if (event == "N" and not(GGVars.GuildMemberNotify == "0" or GGlocal.friends[player])) then
			sMsg = string.format(ERR_FRIEND_ONLINE_SS, player, player).." ("..guild..")"
			PlaySound("FriendJoinGame")
		elseif (event == "F" and not(Guild2Guild_Vars.GuildMemberNotify == "0" or GGlocal.friends[player])) then
			sMsg = string.format(ERR_FRIEND_OFFLINE_S, player).." ("..guild..")"
		elseif (event == "J") then
			sMsg = string.format(ERR_GUILD_JOIN_S, player).." ("..guild..")"
		elseif (event == "L") then
			sMsg = string.format(ERR_GUILD_LEAVE_S, player).." ("..guild..")"
		elseif (event == "P") then
			local promoter, rank;
			_, _, promoter, rank = string.find (rest, "([^;]-);(.*)")
			sMsg = string.format(ERR_GUILD_PROMOTE_SSS, promoter, player, rank).." ("..guild..")"
		elseif (event == "D") then
			local promoter, rank;
			_, _, promoter, rank = string.find (rest, "([^;]-);(.*)")
			sMsg = string.format(ERR_GUILD_DEMOTE_SSS, promoter, player, rank).." ("..guild..")"		
		elseif (event == "A") then
			self:Guild2Guild_PrintDEBUG("displaying ",event,player, guild, rest, "HandleGuildAuxMessage")
			for i=1, NUM_CHAT_WINDOWS do
				chatFrame = getglobal("ChatFrame"..i);
				if (Guild2Guild.IsChatTypeVisible("GUILD_ACHIEVEMENT", chatFrame)) then
					ChatFrame_OnEvent(chatFrame, "CHAT_MSG_GUILD_ACHIEVEMENT",  rest .." ("..guild..")", player, "", "", player, "", 0, 0, "", 0, 172);
				end
			end
		elseif (event == "B") then
			self:Guild2Guild_PrintDEBUG("displaying ",event,player, guild, rest, "HandleGuildAuxMessage")
			achievement = rest;
			sMsg = string.format(G2G_F_ACHIEVEMENT, player, player, achievement).." ("..guild..")"		
			for i=1, NUM_CHAT_WINDOWS do
				chatFrame = getglobal("ChatFrame"..i);
				if (Guild2Guild.IsChatTypeVisible("GUILD_ACHIEVEMENT", chatFrame)) then
					ChatFrame_OnEvent(chatFrame, "CHAT_MSG_GUILD_ACHIEVEMENT",  sMsg, player, "", "", player, "", 0, 0, "", 0, 172, "");
				end
			end
			sMsg = nil
		elseif (event == "C") then
			found,_, achievement, guid = string.find(rest,"([^;]-);([^;]-);")
			self:Guild2Guild_PrintDEBUG("displaying ",event,player, guild, achievement, guid, "HandleGuildAuxMessage")
			GGVars.CachedPlayerIDs[player] = guid

			local coloredName = GetColoredName("CHAT_MSG_GUILD_ACHIEVEMENT", sMsg, player, "", "", player, "", 0, 0, "", 0, 172, guid);

			sMsg = string.format(G2G_F_ACHIEVEMENT, player, coloredName, achievement).." ("..guild..")"		
			for i=1, NUM_CHAT_WINDOWS do
				chatFrame = getglobal("ChatFrame"..i);
				if (Guild2Guild.IsChatTypeVisible("GUILD_ACHIEVEMENT", chatFrame)) then
					ChatFrame_OnEvent(chatFrame, "CHAT_MSG_GUILD_ACHIEVEMENT",  sMsg, player, "", "", player, "", 0, 0, "", 0, 172, guid);
				end
			end
			sMsg = nil
		end
		
		if (sMsg == nil) then
			return
		end
				
		self:AddSystemMessage(sMsg)
		
	end,
	
----------------------------
-- AddSystemMessage - 
----------------------------	

	AddSystemMessage = function (self, message)
		local info = ChatTypeInfo["SYSTEM"];
	
		DEFAULT_CHAT_FRAME:AddMessage(message, info.r, info.g, info.b, info.id);
	end,

----------------------------
-- HandleIncomingGuildMessage - 
----------------------------

	HandleIncomingGuildMessage = function(self, message, sender, guid)
		local GGlocal = Guild2Guild.LocalVars
		local GGVars = Guild2Guild_Vars	

--		self:Guild2Guild_PrintDEBUG("inc:",message, sender, "HandleIncomingGuildMessage")

		if (string.find(message,"G2GOFF:12345")==1) then
			self:DCF("Guild2Guild shutting down! Requested by "..sender,1)
			self:Slash_Command("off")
			return
		end
		if (string.find(message,"G2GREPORT")==1) then
			self:ReportStatus(sender)
			return
		end
		if (string.sub(message,1,1)=="<") then
			local addOnMessage = true
			self:HandleChannelSyncMessage(message, sender, addOnMessage, guid)
			return
		end

		if (GGlocal.Relays[sender] ~= nil) then
		if (GGlocal.gLeader[GGlocal.Relays[sender]] ~= sender) then -- If the current sender isn't a guild leader, ignore
			return
		end
		if (GGlocal.versions[sender] < 810) then -- If the leader is using old version, ignore
			return
		end
			self:Guild2Guild_PrintDEBUG2("leader version",GGlocal.versions[sender],"HandleIncomingGuildMessage")
			if (message == GGlocal.PreviousMessage) then  -- prevent duplicate messages from coming accidentally
				return
			end
			GGlocal.PreviousMessage = message
			GGlocal.PreviousSender = sender
			-- send the message out to the guild
			if (string.sub(message,1,1)=="A") then
				self:HandleForwardedAddonMessage(message)
				return
			elseif (string.sub(message,1,1)=="X") then
				self:HandleForwardedAuxMessage(message)
				return
			end

			-- debug
--			self:Guild2Guild_PrintDEBUG("incoming message",message,"HandleIncomingGuildMessage")
			local sChan = "OFFICER"
			if string.sub(message,4,4) == "G" then
				if not (GGVars.EchoGuild) then
					return      -- don't send messages if echoing is off
				end
				sChan = "GUILD"					
			else
				if not (GGVars.EchoOfficer) then
					return      -- don't send messages if echoing is off
				end
			end
			if (sChan == "OFFICER" and GGlocal.OfficerRank ~= nil and not GGlocal.PlayerIsOfficer) then
				if (not GGlocal.OfficersWarned) then
					ChatThrottleLib:SendChatMessage("NORMAL", "G2G", "G2GO["..sender.."]: Guild2Guild: Warning officer chat is not connected to "..GetGuildInfo("player"),"WHISPER",GetDefaultLanguage("player"),sender)
					GGlocal.OfficersWarned = true
				end
				return
			end

			local sMsg = string.sub(message,5)
			return ChatThrottleLib:SendChatMessage("NORMAL", "G2G", sMsg,sChan,GetDefaultLanguage("player"),sID)
		else
			if (GGlocal.RejectedRelays[sender] == nil) then
				self:SendCrossGuildSyncMessage("Q", "PLAYER", sender)
				GGlocal.RejectedRelays[sender] = {false,time()}
			elseif (not GGlocal.RejectedRelays[sender][1] and time() - GGlocal.RejectedRelays[sender][2] > 10) then
				GGlocal.RejectedRelays[sender][1] = true
				self:SendRejectionLetter(sender)
				self:DCF("Refused incoming message from: ".. sender,1)
			end
		end

	end,

----------------------------
-- ReportStatus - 
----------------------------

	ReportStatus = function(self, sender)
		local sON, sOFF, sNOTSET = "ON", "OFF", "NOT SET"

		local GGVars = Guild2Guild_Vars	
		local GGlocal = Guild2Guild.LocalVars

		ChatThrottleLib:SendChatMessage("BULK", "G2G", "Version Number: "..self.Version,"WHISPER",GetDefaultLanguage("player"),sender)
		for guild, relay in pairs(GGlocal.Guilds) do
			if relay[3] then sTemp = "true" else sTemp = "false" end
			ChatThrottleLib:SendChatMessage("BULK", "G2G", "Connected to: "..guild.." using "..relay[1]..": Ver"..relay[2]..", Officer: "..sTemp,"WHISPER",GetDefaultLanguage("player"),sender)
		end

		local sTemp = ""
		sRejectedConnections = ""
		local count = 0
		local rejectCount = 0
		if (GGlocal.AlliedGuilds ~= nil) then
			for guild, value in pairs(GGlocal.AlliedGuilds) do
				if (value) then
					if count > 0 then sTemp = sTemp.."," end
					sTemp = sTemp..guild
					count = count+1
				else
					if rejectCount > 0 then sRejectedConnections = sRejectedConnections.."," end
					sRejectedConnections = sRejectedConnections..guild
					rejectCount = rejectCount +1
				end
			end
		else
			sTemp = sNOTSET
		end
		ChatThrottleLib:SendChatMessage("BULK", "G2G", "Allied Guilds:"..sTemp,"WHISPER",GetDefaultLanguage("player"),sender)
		count = 0
		sTemp = ""
		if rejectCount > 0 then ChatThrottleLib:SendChatMessage("BULK", "G2G", "Rejected Connections:"..sRejectedConnections,"WHISPER",GetDefaultLanguage("player"),sender) end
		rejectCount = 0
		sRejectedConnections = ""
		
		if (GGlocal.VerifiedGuilds ~= nil) then
			for guild, value in pairs(GGlocal.VerifiedGuilds) do
				if (value) then
					if count > 0 then sTemp = sTemp.."," end
					sTemp = sTemp..guild
					count = count+1
				else
					if rejectCount > 0 then sRejectedConnections = sRejectedConnections.."," end
					sRejectedConnections = sRejectedConnections..guild
					rejectCount = rejectCount +1
				end
			end
		else
			sTemp = sNOTSET
		end
		ChatThrottleLib:SendChatMessage("BULK", "G2G", "Verified Guilds:"..sTemp,"WHISPER",GetDefaultLanguage("player"),sender)
		if rejectCount > 0 then ChatThrottleLib:SendChatMessage("BULK", "G2G", "Unverified Guilds:"..sRejectedConnections,"WHISPER",GetDefaultLanguage("player"),sender) end
		if (GGlocal.OfficerRank ~= nil) then sTemp = GGlocal.OfficerRank else sTemp = sNOTSET end
		ChatThrottleLib:SendChatMessage("BULK", "G2G", "Officer Rank:"..sTemp,"WHISPER",GetDefaultLanguage("player"),sender)
		if GGVars.EchoGuild then sTemp = sON else sTemp = sOFF end
		ChatThrottleLib:SendChatMessage("BULK", "G2G", "Guild chat relay is: "..sTemp,"WHISPER",GetDefaultLanguage("player"),sender)
		if GGVars.EchoOfficer then sTemp = sON else sTemp = sOFF end
		ChatThrottleLib:SendChatMessage("BULK", "G2G", "Officer chat relay is: "..sTemp,"WHISPER",GetDefaultLanguage("player"),sender)
		if GGVars.ShowNewRelayMessages then sTemp = sON else sTemp = sOFF end
		ChatThrottleLib:SendChatMessage("BULK", "G2G", "Relay Change Notification is: "..sTemp,"WHISPER",GetDefaultLanguage("player"),sender)
		if GGVars.Startdelay then sTemp = GGVars.Startdelay else sTemp = sNOTSET end
		ChatThrottleLib:SendChatMessage("BULK", "G2G", "The Startdelay is: "..sTemp,"WHISPER",GetDefaultLanguage("player"),sender)
		ChatThrottleLib:SendChatMessage("BULK", "G2G", "Oldest Version Seen: "..GGlocal.OldestVersion,"WHISPER",GetDefaultLanguage("player"),sender)
		for player, version in pairs(GGlocal.versions) do
			ChatThrottleLib:SendChatMessage("BULK", "G2G", "  "..player..": "..version,"WHISPER",GetDefaultLanguage("player"),sender)
		end

	end,

----------------------------
-- SetActive - 
----------------------------
	SetActive = function(self,active)
		local GGVars = Guild2Guild_Vars
		GGVars.Active = active;
		self:Event_Manager()
		self:Init_Channel()	
	end,
	
--[[ 		
		����������������������������
		   Slash Command Goodness	  
		����������������������������
]]--

	Slash_Command = function(self,sCmdIn)
		local GGVars = Guild2Guild_Vars
		local cColors = Guild2Guild.tColors
		local GGlocal = Guild2Guild.LocalVars
		local sON, sOFF, sNOTSET = cColors.cGreen.."ON", cColors.cRed.."OFF", cColors.cRed.."NOT SET"
		local tCmds, sCmd = {}
--		self:Guild2Guild_PrintDEBUG(sCmdIn,Slash_Command)

		for sCmd in string.gmatch(sCmdIn,"%w+") do
--			self:Guild2Guild_PrintDEBUG(sCmd,Slash_Command)
			table.insert(tCmds,string.lower(sCmd))
		end
		-- G2G ON
		if tCmds[1] == "on" then
			if not GGVars.Active then
				self:DCF("is now "..sON,1)
				self:ResetLocalVariables()
				self:SetActive(true)
			else
				self:DCF("Guild2Guild:ON",-1)
			end		
		-- G2G OFF
		elseif tCmds[1] == "off" then
			if GGVars.Active then
				self:SetActive(false)
				GGlocal.CurrMax = 0
				GGlocal.CurrMax = 0
				GGlocal.CurrMaxVersion = 0
				GGlocal.LastUpdate = time()
				GGlocal.Leader = nil
				self:DCF("is now "..sOFF,1)
			else
				self:DCF("Guild2Guild:OFF",-1)
			end	
		-- PASSIVE
		elseif tCmds[1] == "passive" then
			if tCmds[2] then
				if tCmds[2] == "on" then
					GGVars.Passive = true
				elseif tCmds[2] == "off" then
					GGVars.Passive = false
				else
					self:DCF(false,0)
					return
				end
			else
				GGVars.Passive = not(GGVars.Passive)
			end
			local sTemp = sOFF
			if GGVars.Passive then
				sTemp = sON
			end
			self:DCF("Passive mode is now "..sTemp,1)
			self:CalculateRank()
		-- SILENT
		elseif tCmds[1] == "silent" then
			if tCmds[2] then
				if tCmds[2] == "on" then
					GGVars.Silent = true
				elseif tCmds[2] == "off" then
					GGVars.Silent = false
				else
					self:DCF(false,0)
					return
				end
			else
				GGVars.Silent = not(GGVars.Silent)
			end
			local sTemp = sOFF
			if GGVars.Silent then
				sTemp = sON
			end
			self:DCF("Silent mode is now "..sTemp,1)
			self:CalculateRank()			
				  
		-- CHANNEL
		elseif tCmds[1] == "channel" then   --How to set Channel in frame 2--
			if tCmds[2] then
				if GGVars.Channel then
					LeaveChannelByName(GGVars.Channel)
				end
				GGVars.Channel = tCmds[2]				
				self:Init_Channel()
				self:DCF("Channel is now set to: "..cColors.cWhite..tCmds[2],1)
			else
				self:DCF(false,0)
			end		   
		-- GCHAT
		elseif tCmds[1] == "gchat" then
			if tCmds[2] == "on" and not GGVars.EchoGuild then
				GGVars.EchoGuild = true
				self:DCF("Guild chat linking is now "..sON,1)
			elseif tCmds[2] == "off" and GGVars.EchoGuild then
				GGVars.EchoGuild = false
				self:DCF("Guild chat linking is now "..sOFF,1)	 
			elseif tCmds[2] == "off" and not GGVars.EchoGuild
			  or tCmds[2] == "on" and GGVars.EchoGuild
			  then
				self:DCF("Guild Chat",-1)
			else
				self:DCF(false,0)
			end	   
		-- OCHAT
		elseif tCmds[1] == "ochat" then
			if tCmds[2] == "on" and not GGVars.EchoOfficer then
				GGVars.EchoOfficer = true
				self:DCF("Officer chat linking is now "..sON,1)
			elseif tCmds[2] == "off" and GGVars.EchoOfficer then
				GGVars.EchoOfficer = false
				self:DCF("Officer chat linking is now "..sOFF,1)
			elseif tCmds[2] == "off" and not GGVars.EchoOfficer
			  or tCmds[2] == "on" and GGVars.EchoOfficer
			  then
				self:DCF("Officer Chat",-1)
			else
				self:DCF(false,0)
			end
		-- RELAYNOTIFY
		elseif tCmds[1] == "relaynotify" then
			if tCmds[2] == "on" and not GGVars.ShowNewRelayMessages then
				GGVars.ShowNewRelayMessages = true
				self:DCF("Relay Change Notification is now "..sON,1)
			elseif tCmds[2] == "off" and GGVars.ShowNewRelayMessages then
				GGVars.ShowNewRelayMessages = false
				self:DCF("Relay Change Notification is now "..sOFF,1)	 
			elseif tCmds[2] == "off" and not GGVars.ShowNewRelayMessages
			  or tCmds[2] == "on" and GGVars.ShowNewRelayMessages
			  then
				self:DCF("Relay Change Notification",-1)
			else
				self:DCF(false,0)
			end	   			
		-- FORCE
		elseif tCmds[1] == "force" then
			local sendToChannel = true
			self:SendLeaderMessage(sendToChannel)
		-- DEBUG
		elseif tCmds[1] == "debug" then
			if tCmds[2] == "on" and not GGVars.Debug then
				GGVars.Debug = true
				self:DCF("Debugging is now "..sON,1)
			elseif tCmds[2] == "off" and GGVars.Debug then
				GGVars.Debug = false
				self:DCF("Debugging is now "..sOFF,1)				
			elseif tCmds[2] == "off" and not GGVars.Debug
			  or tCmds[2] == "on" and GGVars.Debug
			  then
				self:DCF("Debug",-1)
			else
				self:DCF(false,0)
			end   
      	-- StartDelay    --Sart delay trigger for page1
		elseif tCmds[1] == "startdelay" then
			if tCmds[2] then
				GGVars.Startdelay = tonumber(tCmds[2])
				self:DCF("Startdelay is now set to: "..cColors.cWhite..tCmds[2],1)
			else
				self:DCF(false,0)
			end
      	-- Password  --How to set password in frame 2
		elseif tCmds[1] == "password" then
			GGVars.Password = tCmds[2]
			self:Init_Channel()
			local sTemp
			if GGVars.Password then sTemp = cColors.cWhite..GGVars.Password else sTemp = sNOTSET end
			self:DCF("Password is now set to: "..cColors.cWhite..sTemp,1)
		-- REPORT
		elseif tCmds[1] == "report" then
			local sTemp
			self:DCF(cColors.cGreen.."settings:",1)
			if GGVars.Active then sTemp = sON else sTemp = sOFF end
			self:DCF("Guild2Guild is: "..sTemp,1)
			self:DCF("Version Number: "..self.Version,1)
			if GGVars.Passive then sTemp = sON else sTemp = sOFF end
			self:DCF("Passive mode is: "..sTemp,1)
			if GGVars.Silent then sTemp = sON else sTemp = sOFF end
			self:DCF("Silent mode is: "..sTemp,1)
			for guild, relay in pairs(GGlocal.Guilds) do
				if relay[3] then sTemp = "true" else sTemp = "false" end
--				self:Guild2Guild_PrintDEBUG(guild,relay[1],relay[2],relay[3],sTemp,"report")
				self:DCF("Connected to: "..guild.." using "..relay[1]..": Ver"..relay[2]..", Officer: "..sTemp,1)
			end
			sTemp = ""
			sRejectedConnections = ""
			local count = 0
			local rejectCount = 0
			if (GGlocal.AlliedGuilds ~= nil) then
				for guild, value in pairs(GGlocal.AlliedGuilds) do
					if (value) then
						if count > 0 then sTemp = sTemp.."," end
						sTemp = sTemp..guild
						count = count+1
					else
						if rejectCount > 0 then sRejectedConnections = sRejectedConnections.."," end
						sRejectedConnections = sRejectedConnections..guild
						rejectCount = rejectCount +1
					end
				end
			else
				sTemp = sNOTSET
			end
			self:DCF("Allied Guilds:"..sTemp,1)
			count = 0
			sTemp = ""
			if rejectCount > 0 then self:DCF("Rejected Connections:"..sRejectedConnections) end
			rejectCount = 0
			sRejectedConnections = ""
						
			if (GGlocal.VerifiedGuilds ~= nil) then
				for guild, value in pairs(GGlocal.VerifiedGuilds) do
					if (value) then
						if count > 0 then sTemp = sTemp.."," end
						sTemp = sTemp..guild
						count = count+1
					else
						if rejectCount > 0 then sRejectedConnections = sRejectedConnections.."," end
						sRejectedConnections = sRejectedConnections..guild
						rejectCount = rejectCount +1
					end
				end
			else
				sTemp = sNOTSET
			end
			self:DCF("Verified Guilds:"..sTemp,1)
			if rejectCount > 0 then self:DCF("Unverified Guilds:"..sRejectedConnections,1) end
			if (GGlocal.OfficerRank ~= nil) then sTemp = GGlocal.OfficerRank else sTemp = sNOTSET end
			self:DCF("Officer Rank:"..sTemp,1)
			if GGVars.EchoGuild then sTemp = sON else sTemp = sOFF end
			self:DCF("Guild chat relay is: "..sTemp,1)
			if GGVars.EchoOfficer then sTemp = sON else sTemp = sOFF end
			self:DCF("Officer chat relay is: "..sTemp,1)
			if GGVars.ShowNewRelayMessages then sTemp = sON else sTemp = sOFF end
			self:DCF("Relay Change Notification is: "..sTemp,1)
			if GGVars.Channel then sTemp = cColors.cWhite..GGVars.Channel else sTemp = sNOTSET end
			self:DCF("The channel is: "..sTemp,1)
			if GGVars.Startdelay then sTemp = cColors.cWhite..GGVars.Startdelay else sTemp = sNOTSET end
			self:DCF("The Startdelay is: "..sTemp,1)
			if GGVars.Password then sTemp = cColors.cWhite..GGVars.Password else sTemp = sNOTSET end
			self:DCF("The Password is: "..sTemp,1)
			self:DCF("Oldest Version Seen: "..GGlocal.OldestVersion,1)
			for sender, version in pairs(GGlocal.versions) do
				self:DCF("  "..sender..": "..version)
			end
            				
			--if GGVars.Debug then sTemp = sON else sTemp = sOFF end
			--self:DCF("Debugging is: "..sTemp)
            
		-- HELP
		elseif tCmds[1] == "help" then
			local sPre = cColors.cWhite.."     /g2g "
			local sA = cColors.cSilver.."["..cColors.cGold
			local sZ = cColors.cSilver.."]"
			local sOnOff = "ON"..cColors.cSilver.."||"..cColors.cGold.."OFF"
			self:DCF(cColors.cGreen.."v"..Guild2Guild.Version..cColors.cSilver.." - "..cColors.cWhite.." by Jaxom of Hellfire, Thank you to Âlvana of Zul'jin - Previously by Durthos of Proudmoore, Originally by Elviso of Mug'Thol"..cColors.cSilver.." - "..cColors.cRed.."jaxom"..cColors.cWhite.."@"..cColors.cBlue.."sky.com",1)
			self:DCF("To turn this addon on or off:")
			self:DCF(sPre..sA..sOnOff..sZ)
			self:DCF("To turn passive mode on or off:")
			self:DCF(sPre.."passive "..sOnOff..sZ)	
			self:DCF("To turn silent mode on or off:")
			self:DCF(sPre.."silent "..sOnOff..sZ)	
			self:DCF("To turn guild chat on or off:")
			self:DCF(sPre.."gchat "..sA..sOnOff..sZ)
			self:DCF("To turn officer chat on or off:")
			self:DCF(sPre.."ochat "..sA..sOnOff..sZ)
			self:DCF("To turn relay change notification on or off:")
			self:DCF(sPre.."relaynotify "..sA..sOnOff..sZ)		
			self:DCF("To set or change the hidden channel used by this addon:")
			self:DCF(sPre.."channel "..sA.."MY_CHANNEL"..sZ)
			self:DCF("To view your settings:")
			self:DCF(sPre.."report ") 
			self:DCF("To create a stack for debugging purposes:")
			self:DCF(sPre.."stackdump ") 
		-- STACKDUMP
		elseif tCmds[1] == "stackdump" then
			self:DCF("stackdump created. Please email your guild2guild saved variables file to jaxom@sky.com.",1)
			table.insert(GGVars.debugStack,self:Guild2Guild_Clone(GGlocal.debugStack))
			GGVars.debugAddOns = self:Guild2Guild_GetAddOns()
		-- DEFAULT
--		elseif tCmds[1] == "test" then

--		local event = "C";
--		local player = "Jaxom";
--		local extra = "|cffffff00|Hachievement:768:030000000021A890:1:6:10:9:4294967295:4294967295:4294967295:4294967295|h[Explore Tirisfal Glades]|h|r;0x0300000003376CEE;";
		local sMsg = event..";"..player..";"..GetGuildInfo("player")..";"..extra
		
		self:HandleGuildAuxMessage(sMsg);
--[[
			ChatThrottleLib:SendAddonMessage("NORMAL", "G2G", "|cffffff00|Hachievement:768:030000000021A890:1:6:10:9:4294967295:4294967295:4294967295:4294967295|h[Explore Tirisfal Glades]|h|r;0x0300000003376CEE;", "WHISPER",tCmds[2])
			ChatThrottleLib:SendAddonMessage("NORMAL", "G2G", "|cffffff00|Hachievement:768:030000000021A890:1:6:10:9:4294967295:4294967295:4294967295:4294967295|h[Explore Tirisfal Glades]|h|r;0x0300000003376CEE;", "WHISPER",tCmds[2])			
		
		ChatThrottleLib:ClearPipe(ChatThrottleLib:PipeName("G2G", "WHISPER", tCmds[2]))
--                self:HandlePlayerLeaving(tCmds[2]);		
]]--
		else
			self:DCF("Type "..cColors.cWhite.."/g2g help"..cColors.cSilver.." for a list of commands.",1)
		end
	end,

--[[ 		
		������������������������
		  Accessory Functions	  
		������������������������
]]--

-------------------------------------------------------------------------------
-- Guild2Guild_GetAddOns - return a list of addons that are loaded
-------------------------------------------------------------------------------
	Guild2Guild_GetAddOns = function (self)
		local addlist = ""
		for i = 1, GetNumAddOns() do
			local name, title, notes, enabled, loadable, reason, security = GetAddOnInfo(i)
	
			local loaded = IsAddOnLoaded(i)
			if (loaded) then
				if not name then name = "Anonymous" end
				name = name:gsub("[^a-zA-Z0-9]+", "")
				local version = GetAddOnMetadata(i, "Version")
				local class = getglobal(name)
				if not class or type(class)~='table' then class = getglobal(name:lower()) end
				if not class or type(class)~='table' then class = getglobal(name:sub(1,1):upper()..name:sub(2):lower()) end
				if not class or type(class)~='table' then class = getglobal(name:upper()) end
				if class and type(class)=='table' then
					if (class.version) then
						version = class.version
					elseif (class.Version) then
						version = class.Version
					elseif (class.VERSION) then
						version = class.VERSION
					end
				end
				local const = getglobal(name:upper().."_VERSION")
				if (const) then version = const end
	
				if type(version)=='table' then
					version = table.concat(version,":")
				end
	
				if (version) then
					addlist = addlist.."  "..name..", v"..version.."\n"
				else
					addlist = addlist.."  "..name.."\n"
				end
			end
		end
		return addlist
	end,
	
-------------------------------------------------------------------------------
-- AddStackMessage - Adds a debug message to the stack
-------------------------------------------------------------------------------

	AddStackMessage = function(self,sMsg)
		if (not (self.Initialized)) then return end
		local GGlocal = Guild2Guild.LocalVars
		local GGVars = Guild2Guild_Vars
		
		GGVars.logging = GGVars.logging or false
		GGVars.log = GGVars.log or {}
		GGVars.logsize = GGVars.logsize or 0
		if (GGVars.logging) then
			table.insert(GGVars.log, sMsg)
			if (GGVars.logsize >= 10000) then
				table.remove(GGVars.log,1)
			else
				GGVars.logsize = GGVars.logsize + 1
			end			
		end
		table.insert(GGlocal.debugStack, sMsg)
		if (GGlocal.stackCount >= 75) then
			table.remove(GGlocal.debugStack,1)
		else
			GGlocal.stackCount = GGlocal.stackCount + 1
		end
	end,

-------------------------------------------------------------------------------
-- DCF - outputs text to the user
-------------------------------------------------------------------------------

	-- lazy text output	    
	DCF = function(self,sMsg,iStyle,sExtra)
		local cColors = Guild2Guild.tColors
		local D_C_F = DEFAULT_CHAT_FRAME
		local sGG = cColors.cGreen.."[Guild2Guild] "
		if iStyle == 1 then
			self:AddStackMessage("DCF:"..sMsg)
			return D_C_F:AddMessage(sGG..cColors.cSilver..sMsg)
		elseif iStyle == 0 then
			return D_C_F:AddMessage(sGG..cColors.cRed.."ERROR: Option invalid or non-existant. No changes were made.")
		elseif iStyle == -1 then
			return D_C_F:AddMessage(sGG..cColors.cWhite..sMsg..": "..cColors.cSilver.."Option already set. No changes were made.")
		elseif iStyle == 5 then
			return D_C_F:AddMessage(cColors.cRed.."[G2G DEBUG:"..cColors.cGold..sExtra..cColors.cRed.."] "..cColors.cWhite..sMsg)		
		else
			self:AddStackMessage("DCF:"..sMsg)
			return D_C_F:AddMessage(cColors.cSilver..sMsg)
		end
	end,	  

-------------------------------------------------------------------------------
-- Guild2Guild_PrintDEBUG - Print's a debug message to the debug window if it is visible
-------------------------------------------------------------------------------

	Guild2Guild_PrintDEBUG = function(self, ...)
	end,


	Guild2Guild_PrintDEBUG2 = function(self, ...)

		local debugWin;
		for i=1, NUM_CHAT_WINDOWS do
			if (GetChatWindowInfo(i):lower() == "g2gdebug") then
				debugWin = i;
				break;
			end
		end

		local out = time()..",";
		for i = 1, select("#", ...) do
			if (i > 1) then out = out .. ", "; end
			local currentArg = select(i, ...)
			local argType = type(currentArg);
			if (argType == "string") then
				out = out .. '"'..currentArg..'"';
			elseif (argType == "number") then
				out = out .. currentArg;
			else
				out = out .. dump(currentArg);
			end
		end
		self:AddStackMessage(out)
		if (not debugWin) then
			return
		end

		getglobal("ChatFrame"..debugWin):AddMessage(out, 1.0, 1.0, 0.3);
	end,

-------------------------------------------------------------------------------
-- Guild2Guild_Clone - return a copy of the table t
-------------------------------------------------------------------------------
	Guild2Guild_Clone = function (self,t) 
		local new = {}             -- create a new table
		local i, v = next(t, nil)  -- i is an index of t, v = t[i]
		while i do
			if type(v)=="table" then v=self:Guild2Guild_Clone(v) end
			new[i] = v
			i, v = next(t, i)        -- get next index
		end
		return new
	end,


-------------------------------------------------------------------------------
-- JoinChannel - Joins a channel
-------------------------------------------------------------------------------

	JoinChannel = function(self,channel,password)
		if(GetChannelName(channel) == 0) then
			self:Guild2Guild_PrintDEBUG("JoinChannel : Joining channel "..channel.." with password ("..tostring(password)..")");
			local zoneChannel, channelName = JoinChannelByName(channel,password,DEFAULT_CHAT_FRAME:GetID());
		else
			self:Guild2Guild_PrintDEBUG("JoinChannel : Already in channel "..channel);
    end
    
    
    
---------------------------------------------------------
    -- LDB Display for Guild2Guild --
---------------------------------------------------------
     
	--Local-- NOTE: Probably dont need half of these!
    
    local Guild2Guild_Vars = Guild2Guild_Vars
    local g2gldb = LibStub:GetLibrary("LibDataBroker-1.1")
    local g2gicon = LibStub:GetLibrary("LibDBIcon-1.0") 
    local g2gtip = LibStub:GetLibrary("LibQTip-1.0")  --Loaded to Enable Channel Roster display if no LDB dislpay--
  
    
        --Start with Minimap Button--
    
        --LDB supported Minimap Button--
            
            local g2gldb = LibStub:GetLibrary("LibDataBroker-1.1"):NewDataObject("Guild2Guild", {
            type = "launcher",
	        text = "Guild2Guild",
            tocname = "Guild2Guild",
            icon = "Interface\\AddOns\\Guild2Guild\\Guild2Guild",
            OnClick = function(self, button)
            if (button == "LeftButton") then
		        ToggleGuildFrame() 
	        elseif (button == "RightButton") then
		        InterfaceOptionsFrame_OpenToCategory("Guild2Guild") 
                end
            end,
            OnTooltipShow = function(tooltip)
                tooltip:AddLine('Guild2Guild')
                tooltip:AddLine('|cffffff00Left click for Guild Panel')
                tooltip:AddLine('|cffffff00Right Click for G2G Interface Panel')
            end,
        })

        local g2gicon = LibStub:GetLibrary("LibDBIcon-1.0")
        g2gicon:Register("Guild2Guild", g2gldb, Guild2Guild_Vars.minimap)    
        
        
            
    --CHANNEL ROSTER LDB TOOTIP--
    
    --Follow with LDB Tooltip display on mouse over for Channel Roster--
    
    
    
    

-------------------------------------------------------
   -- INTERFACE OPTIONS MENU -- 
-------------------------------------------------------

    local GGlocal = Guild2Guild.LocalVars
    local GGVars = Guild2Guild_Vars
    
   -- FRAME 1 --
   
    
	local guild2guild = CreateFrame("Frame", "Guild2Guild", UIParent)
	guild2guild:Hide()
    guild2guild:IsResizable(true)
    guild2guild:SetMinResize(350,250)
	guild2guild.name = "Guild2Guild"
    guild2guild:SetBackdropColor(0, 0, 0, 1)
	guild2guild:SetWidth(250)
	guild2guild:SetHeight(400)
	guild2guild:SetPoint("CENTER", UIParent, "CENTER")
	InterfaceOptions_AddCategory(guild2guild)

	local title = guild2guild:CreateFontString("Guild2GuildTitle", "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -20)
	title:SetText("Guild2Guild V 8.1.3")
    
    
    -- Show Allied Guilds, Channel and Current Connections --
    
    -- Allied Guilds --
    
    local infoEditBox = CreateFrame("EditBox", "Guild2GuildInfoEditBox", guild2guild)
    infoEditBox:SetPoint ("TOPLEFT",155,-82)
    infoEditBox:IsResizable(true)
	infoEditBox:SetMultiLine(true)
	infoEditBox:SetMaxLetters(999)
	infoEditBox:EnableMouse(false)
	infoEditBox:SetAutoFocus(false)
	infoEditBox:SetFontObject(GameFontNormal)
	infoEditBox:SetWidth(250)
	infoEditBox:SetHeight(60)
    infoEditBox:SetText("") 
    infoEditBox:SetScript("OnShow", function(frame)
        local sTemp = ""		
        local count = 0
            if (GGlocal.AlliedGuilds ~= nil) then
			for guild, value in pairs(GGlocal.AlliedGuilds) do
				if (value) then
					if count > 0 then sTemp = sTemp.."," end
					sTemp = sTemp..guild
					count = count+1
				end
			end
		else
			sTemp = sNOTSET
		end
        frame:SetText(""..sTemp)       
    end)
                  
    
	infoEditBox:Show()

    local infoEditBoxText = infoEditBox:CreateFontString("Guild2GuildInfoEditBoxTitle", "ARTWORK", "GameFontHighlightLarge")
	infoEditBoxText:SetPoint("TOPLEFT", infoEditBox, -110, 30)
	infoEditBoxText:SetText("|cff007fffDisplay")
    
    local infoEditBoxText2 = infoEditBox:CreateFontString("Guild2GuildInfoEditBoxTitle", "ARTWORK", "GameFontHighlightLarge")
	infoEditBoxText2:SetPoint("TOPLEFT", infoEditBox, -120, 2)
	infoEditBoxText2:SetText("|cff00aa00AlliedGuilds:")
    
    -- Guild Relay Channel -- 
    
    local infoCEditBox = CreateFrame("EditBox", "Guild2GuildInfoCEditBox", guild2guild)
    infoCEditBox:SetPoint ("TOPLEFT",210,-137)
    infoCEditBox:IsResizable(true)
	infoCEditBox:EnableMouse(false)
	infoCEditBox:SetAutoFocus(false)
	infoCEditBox:SetFontObject(GameFontNormal)
	infoCEditBox:SetWidth(250)
	infoCEditBox:SetHeight(30)
    infoCEditBox:SetText("")       
    infoCEditBox:SetScript("OnShow", function(frame)
		frame:SetText(""..channel)
        end) 
        
	infoCEditBox:Show()
    
    local infoCEditBoxText = infoCEditBox:CreateFontString("Guild2GuildInfoEditBoxTitle", "ARTWORK", "GameFontNormalLarge")
	infoCEditBoxText:SetPoint("TOPLEFT", infoCEditBox, -175, -5)
	infoCEditBoxText:SetText("|cff00aa00Guild Relay Channel:")
    
    
    -- Current Connections --
    
    local infoLEditBox = CreateFrame("EditBox", "Guild2GuildInfoLEditBox", guild2guild)
    infoLEditBox:SetPoint ("TOPLEFT",210,-172)
    infoLEditBox:IsResizable(true)
	infoLEditBox:SetMultiLine(true)
	infoLEditBox:SetMaxLetters(999)
	infoLEditBox:EnableMouse(false)
	infoLEditBox:SetAutoFocus(false)
	infoLEditBox:SetFontObject(GameFontNormal)
	infoLEditBox:SetWidth(250)
	infoLEditBox:SetHeight(30)
    infoLEditBox:SetText("") 
    infoLEditBox:SetScript("OnShow", function(frame)
        local sTemp = ""		
        local count = 0
            if (GGlocal.Relays ~= nil) then
			for relays, value in pairs(GGlocal.Relays) do
				if (value) then
					if count > 0 then sTemp = sTemp.."," end
					sTemp = sTemp..relays
					count = count+1
				end
			end
		else
			sTemp = sNOTSET
		end
        frame:SetText(""..sTemp)       
    end)
        
	infoLEditBox:Show()
    
    local infoLEditBoxText = infoLEditBox:CreateFontString("Guild2GuildInfoEditBoxTitle", "ARTWORK", "GameFontNormalLarge")
	infoLEditBoxText:SetPoint("TOPLEFT", infoLEditBox, -175, 2)
	infoLEditBoxText:SetText("|cff00aa00Current Connections:")

     -- Options title --
    
    local optiog2gitle = guild2guild:CreateFontString("Guild2GuildOptionsTitle", "ARTWORK", "GameFontHighlightLarge")
	optiog2gitle:SetPoint("TOPLEFT", 16, -207)
	optiog2gitle:SetText("|cff007fffOptions")
    
             
                    
    -- Hide minimap Button --
    
    local mini = CreateFrame("CheckButton", "Guild2GuildButton1", guild2guild)
	mini:SetWidth(26)
	mini:SetHeight(26)
	mini:SetPoint("TOPLEFT", 16, -237)
    mini:SetChecked(Guild2Guild_Vars.minimap.hide == true)
    mini:SetScript("OnClick", function(self)
            if self:GetChecked() then
            g2gicon:Hide("Guild2Guild")
            Guild2Guild_Vars.minimap.hide = (true)
            DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffMinimap Button is now OFF");
            else 
            g2gicon:Show("Guild2Guild")
            Guild2Guild_Vars.minimap.hide = (false)
            DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffMinimap Button is now ON");
            end
	end--function
    )
   
	mini:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
	mini:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
	mini:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
	mini:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")

	local miniText = mini:CreateFontString("Guild2GuildButton1Title", "ARTWORK", "GameFontHighlight")
	miniText:SetPoint("LEFT", mini, "RIGHT", 0, 2)
	miniText:SetText("|CFF00AA00Hide Minimap Button|r")
    
    local miniText2 = mini:CreateFontString("Guild2GuildButton1Title", "ARTWORK", "GameFontHighlightSmall")
	miniText2:SetPoint("LEFT", mini, "RIGHT", 5, -10)
    miniText2:SetText("LDB Slidebar Icon is Available")
    
    -- Guild Chat on/off --

	local echoGuild = CreateFrame("CheckButton", "Guild2GuildButton1", guild2guild)
	echoGuild:SetWidth(26)
	echoGuild:SetHeight(26)
	echoGuild:SetPoint("TOPLEFT", 16, -267)
    echoGuild:SetText()
    echoGuild:SetChecked(Guild2Guild_Vars.EchoGuild == true)
	echoGuild:SetScript("OnClick", function(self)
            if self:GetChecked() then
			Guild2Guild_Vars.EchoGuild = (true)
            DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffGuild Chat mode is now ON");
            else
            Guild2Guild_Vars.EchoGuild = (false)
            DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffGuild Chat mode is now OFF");
            end
       end)   --function 
    
    
	echoGuild:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
	echoGuild:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
	echoGuild:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
	echoGuild:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")

	local echoGuildText = echoGuild:CreateFontString("Guild2GuildButton1Title", "ARTWORK", "GameFontHighlight")
	echoGuildText:SetPoint("LEFT", echoGuild, "RIGHT", 0, 2)
	echoGuildText:SetText("|CFF00AA00Guild Chat|r- (ON/OFF)")
    
   
    -- Officer Chat on/off --

	local echoOfficer = CreateFrame("CheckButton", "Guild2GuildButton1", guild2guild)
	echoOfficer:SetWidth(26)
	echoOfficer:SetHeight(26)
	echoOfficer:SetPoint("TOPLEFT", 16, -297)
    echoOfficer:SetText("")
    echoOfficer:SetChecked(Guild2Guild_Vars.EchoOfficer == true)
	echoOfficer:SetScript("OnClick", function(self)
            if self:GetChecked() then
			Guild2Guild_Vars.EchoOfficer = (true)
            DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffOfficer Chat mode is now ON");
            else
            Guild2Guild_Vars.EchoOfficer = (false)
            DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffOfficer Chat mode is now OFF");
            end
       end)   --function 
    
    
	echoOfficer:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
	echoOfficer:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
	echoOfficer:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
	echoOfficer:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")

	local echoOfficerText = echoOfficer:CreateFontString("Guild2GuildButton1Title", "ARTWORK", "GameFontHighlight")
	echoOfficerText:SetPoint("LEFT", echoOfficer, "RIGHT", 0, 2)
	echoOfficerText:SetText("|CFF00AA00Officer Chat|r - (Requires Officer Rank)")
    
    -- Passive mode on/off --
    
    local pPassive = CreateFrame("CheckButton", "Guild2GuildButton2", guild2guild)
	pPassive:SetWidth(26)
	pPassive:SetHeight(26)
	pPassive:SetPoint("TOPLEFT", 16, -327)
    pPassive:SetText()
    pPassive:SetChecked(Guild2Guild_Vars.Passive == true)
	pPassive:SetScript("OnClick", function(self)
            if self:GetChecked() then
			Guild2Guild_Vars.Passive = (true)
            DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffPassive mode is now ON");
            else
            Guild2Guild_Vars.Passive = (false)
            DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffPassive mode is now OFF");
            end
       end)   --function 

	pPassive:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
	pPassive:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
	pPassive:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
	pPassive:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")

	local pPassiveText = pPassive:CreateFontString("Guild2GuildButton2Title", "ARTWORK", "GameFontHighlight")
	pPassiveText:SetPoint("LEFT", pPassive, "RIGHT", 0, 2)
	pPassiveText:SetText("|CFF00AA00Passive Mode|r - for slow connections. (Last Relay)")
    
    -- Relay Notification Module on/off --
    
    local relayGuild = CreateFrame("CheckButton", "Guild2GuildButton2", guild2guild)
	relayGuild:SetWidth(26)
	relayGuild:SetHeight(26)
	relayGuild:SetPoint("TOPLEFT", 16, -357)
    relayGuild:SetText()
    relayGuild:SetChecked(Guild2Guild_Vars.ShowNewRelayMessages == true)
	relayGuild:SetScript("OnClick", function(self)
            if self:GetChecked() then
			Guild2Guild_Vars.ShowNewRelayMessages = (true)
            DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffRelay Change Notification is now ON");
            else
            Guild2Guild_Vars.ShowNewRelayMessages = (false)
            DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffRelay Change Notification is now OFF");
            end
       end)   --function 

	relayGuild:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
	relayGuild:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
	relayGuild:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
	relayGuild:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")

	local relayGuildText = relayGuild:CreateFontString("Guild2GuildButton2Title", "ARTWORK", "GameFontHighlight")
	relayGuildText:SetPoint("LEFT", relayGuild, "RIGHT", 0, 2)
	relayGuildText:SetText("|CFF00AA00Relay Change|r - Notifies if any Guild Relay is changed")
    
    
    
    -- End Frame 1 --
    
    -- FRAME 2 --  -- LAYOUT PERFECT DON'T TOUCH IT JAX :)--
    
      
    
    -- Create Setup frames --
    
	local setup = CreateFrame("Frame", "Setup", UIParent)
	setup:Hide()
    setup:IsResizable(true)
	setup.name = "Setup"
    setup.parent = "Guild2Guild"
    setup:SetBackdropColor(0, 0, 0, 1)
	setup:SetWidth(250)
	setup:SetHeight(600)
	setup:SetPoint("CENTER", UIParent, "CENTER")
	InterfaceOptions_AddCategory(setup)

	local setuptitle = setup:CreateFontString("SetupSetupTitle", "ARTWORK", "GameFontNormalLarge")
	setuptitle:SetPoint("TOPLEFT", 16, -20)
	setuptitle:SetText("Guild2Guild Setup, Beta, under development")
   
    
    -- Allied Guilds --
    
    local infoEditBox2 = CreateFrame("EditBox", "SetupInfoEditBox2", setup)
    infoEditBox2:SetPoint ("TOPLEFT",26,-42)
	infoEditBox2:EnableMouse(false)
	infoEditBox2:SetAutoFocus(false)
	infoEditBox2:SetFontObject(GameFontNormalLarge)
	infoEditBox2:SetWidth(300)
	infoEditBox2:SetHeight(20)
    infoEditBox2:SetText("")
	infoEditBox2:Show()


    local infoEditBoxText2 = infoEditBox2:CreateFontString("SetupInfoEditBox2Title", "ARTWORK", "GameFontNormalLarge")
	infoEditBoxText2:SetPoint("TOPLEFT", infoEditBox2, 5, -10)
	infoEditBoxText2:SetText("|cff007fffIMPORTANT NOTE: |CFFAA0000Guild Leader Only")
    
    local infoEditBoxText2a = infoEditBox2:CreateFontString("SetupInfoEditBox2aTitle", "ARTWORK", "GameFontNormal")
	infoEditBoxText2a:SetPoint("BOTTOMLEFT", infoEditBox2, 5, -75)
	infoEditBoxText2a:SetWidth(300)
	infoEditBoxText2a:SetHeight(60)
    infoEditBoxText2a:SetFontObject(GameFontNormal)
    infoEditBoxText2a:SetJustifyH("LEFT")
    infoEditBoxText2a:SetJustifyV("LEFT")
	infoEditBoxText2a:SetText("If your guild already uses |cff007fffGuild2Guild|r then you do not have to do anything to set it up. If the Allied Guilds and Relay Channel are shown on the Main Interface Window everything is done Automatically.")
    
    local infoEditBoxText2b = infoEditBox2:CreateFontString("SetupInfoEditBox2bTitle", "ARTWORK", "GameFontHighlightLarge")
	infoEditBoxText2b:SetPoint("BOTTOMLEFT", infoEditBox2, 5, -130)
    infoEditBoxText2b:SetWidth(300)
    infoEditBoxText2b:SetFontObject(GameFontNormal)
	infoEditBoxText2b:SetText("Only the Guild Leader or Officers with           |cff007fff'Edit Guild Info Text'|r                                                Can see the rest of this page and make Changes.")
    
    
    -- Relay Channel enter --
    
    local channelInput = CreateFrame("EditBox", "SetupChannelInput", setup, "InputBoxTemplate")
	channelInput:SetPoint("TOPLEFT", 30, -220)
	channelInput:SetAutoFocus(false)
	channelInput:EnableMouse(true)
	channelInput:SetWidth(200)
	channelInput:SetHeight(20)
    channelInput:SetFontObject(GameFontNormal)
	channelInput:SetMaxLetters(30)
	channelInput:SetScript("OnTextChanged", function(self, isUserInput)
        end)
    
    channelInput:SetScript("OnShow",function(frame)
        frame:SetText(""..channel)
        if ( CanEditGuildInfo() ) then
        channelInput:Show();
        else
        channelInput:Hide();
     end
  end)
 
    
    local channelInputText = channelInput:CreateFontString("SetupChannelInputTitle", "ARTWORK", "GameFontHighlight")
	channelInputText:SetPoint("BOTTOMLEFT", channelInput, 2, -15)
	channelInputText:SetText("This is the Channel you use for the Guild2Guild relay.")
    
    local channelInputText2 = channelInput:CreateFontString("SetupChannelInputTitle", "ARTWORK", "GameFontHighlight")
	channelInputText2:SetPoint("BOTTOMLEFT", channelInput, 2, 23)
	channelInputText2:SetText("|cff007fffGuild Relay Channel")
    
    -- Password Input --
    
    local passInput = CreateFrame("EditBox", "SetupPassInput", setup, "InputBoxTemplate")
	passInput:SetPoint("TOPLEFT", 30, -280)
	passInput:SetAutoFocus(false)
	passInput:EnableMouse(true)
	passInput:SetWidth(200)
	passInput:SetHeight(20)
    passInput:SetFontObject(GameFontNormal)
	passInput:SetMaxLetters(30)
    passInput:IsPassword()
   -- passInput:Hide()
    passInput:SetScript("OnTextChanged", function(self, isUserInput)
        end)
    -- write to GGVars.password, would require individual entry of password, once!--
    
    passInput:SetScript("OnShow",function(frame)
        frame:SetText(""..password)
         if ( CanEditGuildInfo() ) then
        passInput:Show();
        else
        passInput:Hide();
     end
  end)
    
    
    local passInputText = passInput:CreateFontString("SetupPassInputTitle", "ARTWORK", "GameFontHighlight")
	passInputText:SetPoint("BOTTOMLEFT", passInput, 2, -15)
	passInputText:SetText("Enter Channel Password. (This only needs to be done once)")
    
    local passInputText2 = passInput:CreateFontString("SetupPassInputTitle", "ARTWORK", "GameFontHighlight")
	passInputText2:SetPoint("BOTTOMLEFT", passInput, 2, 23)
	passInputText2:SetText("|cff007fffChannel Password")
    
     -- Allied Guild Input --
    
    local guildInput = CreateFrame("EditBox", "SetupGuildInput", setup, "InputBoxTemplate")
	guildInput:SetPoint("TOPLEFT", 30, -340)
    guildInput:SetMultiLine(false)
	guildInput:SetAutoFocus(false)
	guildInput:EnableMouse(true)
	guildInput:SetWidth(200)
	guildInput:SetHeight(20)
	guildInput:SetMaxLetters(500)
    guildInput:SetFontObject(GameFontNormal)
    guildInput:SetScript("OnTextChanged", function(self, isUserInput)
        end)
    
    -- BIG NOTE: cmd A = allied guilds text on click save button
    
   guildInput:SetScript("OnShow", function(frame)
        local sTemp = ""		
        local count = 0
            if (GGlocal.AlliedGuilds ~= nil) then
			for guild, value in pairs(GGlocal.AlliedGuilds) do
				if (value) then
					if count > 0 then sTemp = sTemp.."," end
					sTemp = sTemp..guild
					count = count+1
				end
			end
		else
			sTemp = sNOTSET
		end
        frame:SetText(""..sTemp)       
    end)
        if ( CanEditGuildInfo() ) then
        guildInput:Show();
        else
        guildInput:Hide();
     end
     
    
    local guildInputButton = CreateFrame("Button", "SetupGuildInputButton", guildInput, "UIPanelButtonTemplate")
    guildInputButton:SetPoint("TOPLEFT", guildInput, 255, 3)
    guildInputButton:SetWidth(80)
    guildInputButton:SetHeight(22)
    guildInputButton:SetText("Save All")
    guildInputButton:SetScript("OnClick", function(self, guildInput, passInput, ChannelInput)
      --  if (GGlocal.AlliedGuilds ~= nil) then
      --  SetGuildInfoText("<G2G;P:("");C:("");A:("");>");    
    DEFAULT_CHAT_FRAME:AddMessage("|cff00aa00[Guild2Guild] - |cff007fffSorry This Button does not work Yet");
    end)
    
   
    -- Needs to save all 3 editboxes to GuildInfo text in correct format --
          
        
--   changed all 3 boxes now save on this one button

    local guildInputText = guildInput:CreateFontString("SetupGuildInputTitle", "ARTWORK", "GameFontHighlight")
	guildInputText:SetPoint("BOTTOMLEFT", guildInput, 2, -15)
	guildInputText:SetText("Enter name of Allied Guilds seperated by a |CFFAA0000Coma , .")
    
    local guildInputText1 = guildInput:CreateFontString("SetupGuildInputTitle", "ARTWORK", "GameFontHighlight")
	guildInputText1:SetPoint("BOTTOMLEFT", guildInput, 2, -30)
    guildInputText1:SetText("(IE: |cff007fffGuild1|CFFAA0000,|cff007fffGuild2|CFFAA0000,|cff007fffGuild3)")

    local guildInputText2 = guildInput:CreateFontString("SetupGuildInputTitle", "ARTWORK", "GameFontHighlight")
	guildInputText2:SetPoint("BOTTOMLEFT", guildInput, 2, 23)
	guildInputText2:SetText("|cff007fffAllied Guilds")
    
    local guildInputText3 = guildInput:CreateFontString("SetupGuildInputTitle", "ARTWORK", "GameFontHighlight")
	guildInputText3:SetPoint("BOTTOMLEFT", guildInput, 2, -45)
	guildInputText3:SetText("|cffffd200NOTE: Guild Names are Case Sensitive")
    
    -- Edit function control --
  
   
    -- End Frame 2 --
    
    -- FRAME 3 --
   
    local infowidth = InterfaceOptionsFramePanelContainer:GetWidth()
    local info = CreateFrame("Frame", "Info", UIParent)
	info:Hide()
    info:IsResizable(true)
	info.name = "Info"
    info.parent = "Guild2Guild"
	info:SetBackdropColor(0, 0, 0, 1)
    info:SetWidth(infowidth+45)
	info:SetHeight(1300)
	info:SetPoint("CENTER", UIParent, "CENTER")
	info:SetFrameStrata("DIALOG")
	InterfaceOptions_AddCategory(info)

	local infotitle = info:CreateFontString("InfoInfoTitle", "ARTWORK", "GameFontNormalLarge")
	infotitle:SetPoint("TOPLEFT", 20, -10)
	infotitle:SetText("Guild2Guild Information")
    
    -- Information Panel --
    
	local infoscroll = CreateFrame("ScrollFrame", "Info", info, "UIPanelScrollFrameTemplate")
	infoscroll:SetPoint("TOPLEFT", info, "TOPLEFT", 8, -30)
	infoscroll:SetPoint("BOTTOMRIGHT", info, "BOTTOMRIGHT", -30, 8)

	local infoEditBox = CreateFrame("EditBox", nil, info)
	infoEditBox:SetMultiLine(true)
	infoEditBox:SetMaxLetters(1200)
    infoEditBox:IsResizable(true)
	infoEditBox:EnableMouse(false)
	infoEditBox:SetAutoFocus(false)
    infoEditBox:SetPoint("TOPLEFT", info, "TOPLEFT", 10, -40)
	infoEditBox:SetFontObject(ChatFontNormal)
    infoEditBox:SetWidth(320)
	infoEditBox:SetHeight(1500)
--	infoEditBox:SetScript("OnEscapePressed", function() info:Hide() end)
    infoEditBox:SetText("")
    
    -- Features --
    
    local infotext1 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontNormalLarge")
    infotext1:SetPoint("TOPLEFT", infoEditBox, 10, -20)
    infotext1:SetWidth(320)
    infotext1:SetText("--     FEATURES     --")
    
    local infotext2 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext2:SetPoint("TOPLEFT", infoEditBox, 25, -55)
    infotext2:SetWidth(320)
    infotext2:SetJustifyH("LEFT")
    infotext2:SetJustifyV("LEFT")
    infotext2:SetText("|cffffd200#|r You can enable either guild chat, officer chat, or both.")
    
    local infotext3 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext3:SetPoint("TOPLEFT", infoEditBox, 25, -85)
    infotext3:SetWidth(330)
    infotext3:SetJustifyH("LEFT")
    infotext3:SetJustifyV("LEFT")
    infotext3:SetText("|cffffd200#|r Completely secure since the transmission channel is via in game whispers. The public channel that you set is used for cross guild synchronization only.")
    
    local infotext4 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext4:SetPoint("TOPLEFT", infoEditBox, 25, -150)
    infotext4:SetWidth(320)
    infotext4:SetJustifyH("LEFT")
    infotext4:SetJustifyV("LEFT")
    infotext4:SetText("|cffffd200#|r Everyone with the addon will see the guild chat as though it came directly from the person that sent the message. Clicking on their name will have all the same functionality as the regular WOW UI.|r|cffffd200 \If they do not have the addon installed you will see |cffffff9a[sender1]|cff20ff20[sender2]|r\ (|cffffff9a1|r = the current link to your guild, |cff20ff202|r = the person sending the message.)")
    
    local infotext5 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext5:SetPoint("TOPLEFT", infoEditBox, 25, -250)
    infotext5:SetWidth(320)
    infotext5:SetJustifyH("LEFT")
    infotext5:SetJustifyV("LEFT")
    infotext5:SetText("|cffffd200#|r More than two people from either guild can have the add-on running at once, in fact its encouraged to have multiple guild members with the addon for stability.")
    
    local infotext6 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext6:SetPoint("TOPLEFT", infoEditBox, 25, -310)
    infotext6:SetWidth(320)
    infotext6:SetJustifyH("LEFT")
    infotext6:SetJustifyV("LEFT")
    infotext6:SetText("|cffffd200#|r Allows item linking and Forwards messages that other addons send to the guild addon channel.")
    
    local infotext7 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext7:SetPoint("TOPLEFT", infoEditBox, 25, -355)
    infotext7:SetWidth(320)
    infotext7:SetJustifyH("LEFT")
    infotext7:SetJustifyV("LEFT")
    infotext7:SetText("|cffffd200#|r |cffffd200NOTE:|r If there are |cffff2020NO Allied Guilds|r listed in the \|cffffd200Guild Info Text|r\ then Guild2Guild will Shut-Down. This is to ensure that Guild2Guild cannot randomly connect to other guilds.")
    
    -- Slash Commands --
    
    local infotext8 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontNormalLarge")
    infotext8:SetPoint("TOPLEFT", infoEditBox, 10, -450)
    infotext8:SetWidth(320)
    infotext8:SetText("--    Optional Slash Commands    --")
    
    local infotext9 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext9:SetPoint("TOPLEFT", infoEditBox, 25, -480)
    infotext9:SetWidth(320)
    infotext9:SetJustifyH("LEFT")
    infotext9:SetJustifyV("LEFT")
    infotext9:SetText("|cffffd200#|r To turn  on or off: |cffff7f3f/g2g [on|off]")
    
    
    local infotext11 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext11:SetPoint("TOPLEFT", infoEditBox, 25, -500)
    infotext11:SetWidth(320)
    infotext11:SetJustifyH("LEFT")
    infotext11:SetJustifyV("LEFT")
    infotext11:SetText("|cffffd200#|r To view all your settings: |cffff7f3f/g2g report")
    
    local infotext12 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext12:SetPoint("TOPLEFT", infoEditBox, 25, -525)
    infotext12:SetWidth(320)
    infotext12:SetJustifyH("LEFT")
    infotext12:SetJustifyV("LEFT")
    infotext12:SetText("|cffffd200#|r |cffff2020ADVANCED:|r If something really strange happens you can type     |cffff7f3f/g2g stackdump|r which will take a snapshot of the last few minutes of Guild2Guild activity. If you then send me an email (|cffffd200Jaxom@dragonsweyr.co.uk|r) of your Guild2Guild saved variables file for that Character when you log out. Then I will be better able to debug what went wrong.")
    
    -- Setup --
    
    local infotext15 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontNormalLarge")
    infotext15:SetPoint("TOPLEFT", infoEditBox, 10, -650)
    infotext15:SetWidth(320)
    infotext15:SetText("--     How to Setup Guild2Guild     --")
    
    local infotext16 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontNormalLarge")
    infotext16:SetPoint("TOPLEFT", infoEditBox, 15, -675)
    infotext16:SetWidth(320)
    infotext16:SetText("GUILD LEADERS")
    
    local infotext17 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext17:SetPoint("TOPLEFT", infoEditBox, 25, -700)
    infotext17:SetWidth(320)
    infotext17:SetJustifyH("LEFT")
    infotext17:SetJustifyV("LEFT")
    infotext17:SetText("|cffffd200#|r You MUST limit the guilds that you can connect to using an Allied Guild list, and automatically set the channel and password by adding a string like: (below) to your guild information (through the guild info menu).")  
    
    local infotext18 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext18:SetPoint("TOPLEFT", infoEditBox, 25, -780)
    infotext18:SetWidth(320)
    infotext18:SetJustifyH("LEFT")
    infotext18:SetJustifyV("LEFT")
    infotext18:SetText("|cffffd200#|r <G2G;C:|cff20ff20CHANNEL we want to use|r;P:|cff20ff20PASSWORD to keep it secret|r;A:|cff20ff20GUILD NAME 1|r,|cff20ff20GUILD NAME 2|r,|cff20ff20GUILD NAME 3|r,|cff20ff20ETC|r;>")
    
    local infotext19 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext19:SetPoint("TOPLEFT", infoEditBox, 25, -820)
    infotext19:SetWidth(320)
    infotext19:SetJustifyH("LEFT")
    infotext19:SetJustifyV("LEFT")
    infotext19:SetText("|cffffd200#|r |cffff2020Example:|r <G2G;C:Fredschannel;P:Flig2gone;A:Death to the king,Lushness,Dire Dawn Raiders;>")
    
    local infotext20 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext20:SetPoint("TOPLEFT", infoEditBox, 25, -855)
    infotext20:SetWidth(320)
    infotext20:SetJustifyH("LEFT")
    infotext20:SetJustifyV("LEFT")
    infotext20:SetText("|cffffd200#|r |cff20ff20Channel|r is the name of the channel you want Guild2Guild to use to coordinate relays.")
    
    local infotext21 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext21:SetPoint("TOPLEFT", infoEditBox, 25, -890)
    infotext21:SetWidth(320)
    infotext21:SetJustifyH("LEFT")
    infotext21:SetJustifyV("LEFT")
    infotext21:SetText("|cffffd200#|r |cff20ff20Password|r is the password for that channel.(Password is optional, you don't need to use it if you don't want to have a password.)")
    
    local infotext22 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext22:SetPoint("TOPLEFT", infoEditBox, 25, -935)
    infotext22:SetWidth(320)
    infotext22:SetJustifyH("LEFT")
    infotext22:SetJustifyV("LEFT")
    infotext22:SetText("|cffffd200#|r |cff20ff20Guild Name 1|r and |cff20ff20Guild Name 2|r are the names of two or more guilds that you would like to allow to connect to this one.         |cffff2020(Guild names are Case Sensitive)|r.")
    
    local infotext23 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext23:SetPoint("TOPLEFT", infoEditBox, 25, -990)
    infotext23:SetWidth(320)
    infotext23:SetJustifyH("LEFT")
    infotext23:SetJustifyV("LEFT")
    infotext23:SetText("|cffffd200#|r Guild to Guild will automatically promote people that are allowed to speak in the officer channel to relays. This is so that the officer chat can be relayed as well.")
    
    -- History --
    
    local infotext24 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontNormalLarge")
    infotext24:SetPoint("TOPLEFT", infoEditBox, 10, -1070)
    infotext24:SetWidth(320)
    infotext24:SetText("--     History     --")
    
    local infotext25 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext25:SetPoint("TOPLEFT", infoEditBox, 25, -1095)
    infotext25:SetWidth(320)
    infotext25:SetJustifyH("LEFT")
    infotext25:SetJustifyV("LEFT")
    infotext25:SetText("|cffffd200#|r  To the few very dedicated people that have maintained G2G in chronological responsibility:")
    
    local infotext26 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext26:SetPoint("TOPLEFT", infoEditBox, 25, -1125)
    infotext26:SetWidth(320)
    infotext26:SetJustifyH("LEFT")
    infotext26:SetJustifyV("LEFT")
    infotext26:SetText("|cffffd200#|r Original Author - Elviso of Mug'Thol.")
    
    local infotext27 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext27:SetPoint("TOPLEFT", infoEditBox, 25, -1145)
    infotext27:SetWidth(320)
    infotext27:SetJustifyH("LEFT")
    infotext27:SetJustifyV("LEFT")
    infotext27:SetText("|cffffd200#|r Modified by - Tassleoff.")
    
    local infotext28 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext28:SetPoint("TOPLEFT", infoEditBox, 25, -1165)
    infotext28:SetWidth(320)
    infotext28:SetJustifyH("LEFT")
    infotext28:SetJustifyV("LEFT")
    infotext28:SetText("|cffffd200#|r Previous Author - Durthos of Proudmoore.")
    
    local infotext29 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext29:SetPoint("TOPLEFT", infoEditBox, 25, -1185)
    infotext29:SetWidth(320)
    infotext29:SetJustifyH("LEFT")
    infotext29:SetJustifyV("LEFT")
    infotext29:SetText("|cffffd200#|r Update Author - Âlvana of Zul'jin.")
    
    local infotext30 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext30:SetPoint("TOPLEFT", infoEditBox, 25, -1205)
    infotext30:SetWidth(320)
    infotext30:SetJustifyH("LEFT")
    infotext30:SetJustifyV("LEFT")
    infotext30:SetText("|cffffd200#|r Current Manager/Author - Jaxom of Hellfire.")
    
    -- Error Reporting --
    
    local infotext31 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontNormalLarge")
    infotext31:SetPoint("TOPLEFT", infoEditBox, 10, -1270)
    infotext31:SetWidth(320)
    infotext31:SetText("--   Error Reporting   --")
    
    local infotext32 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext32:SetPoint("TOPLEFT", infoEditBox, 25, -1290)
    infotext32:SetWidth(320)
    infotext32:SetJustifyH("LEFT")
    infotext32:SetJustifyV("LEFT")
    infotext32:SetText("|cffffd200#|r Please post all errors on |cff20ff20http://wow.curseforge.com/addons/guild2guild/tickets/|r and not on curse.com. Thank You.")
    
    local infotext33 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext33:SetPoint("TOPLEFT", infoEditBox, 25, -1330)
    infotext33:SetWidth(320)
    infotext33:SetJustifyH("LEFT")
    infotext33:SetJustifyV("LEFT")
    infotext33:SetText("|cffffd200#|r I think thats everything....Jaxom")
    
    local infotext34 = infoEditBox:CreateFontString("InfoEditBox", "ARTWORK", "GameFontHighlight")
    infotext34:SetPoint("TOPLEFT", infoEditBox, 25, -1350)
    infotext34:SetWidth(320)
    infotext34:SetJustifyH("LEFT")
    infotext34:SetJustifyV("LEFT")
    infotext34:SetText("|cffffd200.|r")
    
	infoscroll:SetScrollChild(infoEditBox)
 
 
    -- End Frame 3 --

    -- End INTERFACE OPTIONS PANEL --





    
    
end 
};
  
    --Chat Throttle lib hook--
    
  if (_G.ChatThrottleLib) then
  local rehook = false
  if(_G.ChatThrottleLib.version ~= 20) then
    rehook = true
    Guild2Guild.Guild2Guild_PrintDEBUG(Guild2Guild,"Failed to find my version of ChatThrottleLib: new version found", _G.ChatThrottleLib.version)
  elseif (_G.ChatThrottleLib.ClearPipe == nil) then
    rehook = true
    Guild2Guild.Guild2Guild_PrintDEBUG(Guild2Guild,"Failed to find my version of ChatThrottleLib: Someone else loaded it first", _G.ChatThrottleLib.version)
  end

  if (rehook) then
    function _G.ChatThrottleLib:ClearPipe (pipename)
      Guild2Guild.Guild2Guild_PrintDEBUG(Guild2Guild, "Running Stub ClearPipe")
    end
  
    function _G.ChatThrottleLib:PipeName (prefix, chattype, destination)
      return (prefix..(chattype or "SAY")..(destination or ""))
    end
  end
end



 
  
  
 

--[[��� EOF ���]]--