DBM:RegisterMapSize("DragonSoul", 
	1, 3106.7084960938, 2063.0651855469,	-- Dragonblight
	2, 397.49887572464, 264.99992263558,	-- Maw of Go'rath (Caution: map data from game files is wrong here)
	3, 427.50311666243, 285.00046747363,	-- Maw of Shu'ma (Caution: map data from game files is wrong here)
	4, 185.19921875, 123.466796875,			-- Eye of Eternity
--	5, 1.5, 1,								-- Gunship (It doesn't actually have usuable coords, useless map data)
--	6, 1.5, 1,								-- Spine (Same probelm as above)
	7, 1108.3515625, 738.900390625			-- Maelstrom
)