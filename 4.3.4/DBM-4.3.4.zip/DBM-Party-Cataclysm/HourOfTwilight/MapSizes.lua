DBM:RegisterMapSize("HourofTwilight",
	1, 3043.7498779297, 2029.1665039062,
	2, 0, 0
)