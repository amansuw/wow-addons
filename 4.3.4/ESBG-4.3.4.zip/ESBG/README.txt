

Get rid of all those annoying pesky GCD error sounds so you can enjoy the nice sound of battle instead.

Enjoy
Install Guide READ ME FIRST

Extract the \sound folder into your <DIR>\World of Warcraft\Data\(language*)


Example

H:\World of Warcraft\Data\enUS\Sound\

    * enUS or any other language 


