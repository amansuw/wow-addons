if not Skinner:isAddonEnabled("DragonCore") then return end

function Skinner:DragonCore()

	self:keepFontStrings(Dragon_Frame)
	self:keepFontStrings(Dragon_BarBlocker)
	
end
