if not Skinner:isAddonEnabled("ConcessionStand") then return end

function Skinner:ConcessionStand()

	self:addSkinFrame{obj=ConcessionStandFrame, nb=true}

end
