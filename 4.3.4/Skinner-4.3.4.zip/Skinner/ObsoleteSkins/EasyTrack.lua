
function Skinner:EasyTrack()

	self:applySkin(EasyTrackFrame)

end
