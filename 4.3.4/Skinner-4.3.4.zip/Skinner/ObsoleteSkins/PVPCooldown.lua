
function Skinner:PVPCooldown()

	self:applySkin(PVPCooldownFrame)

end
