
function Skinner:GCInfo()

	self:applySkin(GCInfoFrame)

end
