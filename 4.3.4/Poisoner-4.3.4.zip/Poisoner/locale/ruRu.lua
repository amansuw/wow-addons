if  (GetLocale() == "ruRU") then

-- Contributors: humfras, Itonohito, StingerSoft

local Poison_unknown = ".*яд%s*([IVX]*)"
local CPName = GetItemInfo(3775);	--Verkrüppelndes Gift
local MPName = GetItemInfo(5237);	--Gedankenbenebelndes Gift
local DPName = GetItemInfo(2892);	--Tödliches Gift
local IPName = GetItemInfo(6947);	--Sofort wirkendes Gift
local WPName = GetItemInfo(10918);	--Wundgift

	if (CPName == nil) then
	CPName = Poison_unknown
	end
	if (MPName == nil) then
	MPName = Poison_unknown
	end
	if (DPName == nil) then
	DPName = Poison_unknown
	end
	if (IPName == nil) then
	IPName = Poison_unknown
	end
	if (WPName == nil) then
	WPName = Poison_unknown
	end
	
-- 
-- Regular expressions to match poison names
-- 
Poisoner_Patterns = {
	""..CPName.."",
	""..MPName.."",
	""..DPName.."",
	""..IPName.."",
	""..WPName.."",
	"%w+ точило",
	"%w+ грузило",
	".*масло маны",
	".*волшебное масло",
	"Масло льда",
	"Масло Тьмы",
    --    ".*яд%s*([IVX]*)"
};

--
-- Other internal strings
--

-- the pattern to search for in a tooltip for the number of charges
-- remaining on an expendable item
POISONER_PATTERN_CHARGES = "^(%d+) зарядов$";

--
-- Display strings
--

-- tooltip strings
POISONER_MINIMAPBUTTON_TIP1 = "Poisoner";
-- error messages
POISONER_COMMANDERROR = "Неизвестная команда Poisoner: ";
POISONER_DRAGERROR = "Ошибка перемещения кнопки Poisoner";
POISONER_POSITIONERROR = "Неизвестная ошибка позиционирования";

end
