if  (GetLocale() == "zhCN" or GetLocale() == "zhTW") then

-- Contributors: 

local Poison_unknown = ".*毒[药藥]%s*([IVX]*)"
local CPName = GetItemInfo(3775);	--Verkrüppelndes Gift
local MPName = GetItemInfo(5237);	--Gedankenbenebelndes Gift
local DPName = GetItemInfo(2892);	--Tödliches Gift
local IPName = GetItemInfo(6947);	--Sofort wirkendes Gift
local WPName = GetItemInfo(10918);	--Wundgift

	if (CPName == nil) then
	CPName = Poison_unknown
	end
	if (MPName == nil) then
	MPName = Poison_unknown
	end
	if (DPName == nil) then
	DPName = Poison_unknown
	end
	if (IPName == nil) then
	IPName = Poison_unknown
	end
	if (WPName == nil) then
	WPName = Poison_unknown
	end
	
-- 
-- Regular expressions to match poison names
-- 
Poisoner_Patterns = {
	""..CPName.."",
	""..MPName.."",
	""..DPName.."",
	""..IPName.."",
	""..WPName.."",
	".*磨刀石",
	".*平衡石",
	".*法力之油",
	".*巫师之油",
	"冰霜之油",
	"暗影之油",
    --    ".*毒[药藥]%s*([IVX]*)"
};

--
-- Display strings
--

-- tooltip strings
-- error messages



end
