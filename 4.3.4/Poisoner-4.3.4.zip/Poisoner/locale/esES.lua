if  (GetLocale() == "esES") then

-- Contributors: humfras, 

local Poison_unknown = "Veneno .*"
local CPName = GetItemInfo(3775);	--Verkr�ppelndes Gift
local MPName = GetItemInfo(5237);	--Gedankenbenebelndes Gift
local DPName = GetItemInfo(2892);	--T�dliches Gift
local IPName = GetItemInfo(6947);	--Sofort wirkendes Gift
local WPName = GetItemInfo(10918);	--Wundgift

	if (CPName == nil) then
	CPName = Poison_unknown
	end
	if (MPName == nil) then
	MPName = Poison_unknown
	end
	if (DPName == nil) then
	DPName = Poison_unknown
	end
	if (IPName == nil) then
	IPName = Poison_unknown
	end
	if (WPName == nil) then
	WPName = Poison_unknown
	end

-- 
-- Regular expressions to match poison names
-- 
Poisoner_Patterns = {
	""..CPName.."",
	""..MPName.."",
	""..DPName.."",
	""..IPName.."",
	""..WPName.."",
	"Piedra de afilar %w+",
	"Contrapeso %w+",
	"Aceite de man�.*",
	"Aceite de zahor�.*",
	"Aceite de Escarcha",
	"Aceite de las Sombras",
    --    "Veneno .*" -- not a very good pattern, but without grouping...
};

--
-- Display strings
--

-- tooltip strings
-- error messages



end
