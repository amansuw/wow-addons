-- Heaven is a S0c7

-- Show the help.
local function ShowHelp()
   if RoguedarEnabled then
      DEFAULT_CHAT_FRAME:AddMessage("Roguedar "..RoguedarVersion.." is on, type \"/RD off\" to turn it off.", 0.0, 0.85, 0.0);
   else
      DEFAULT_CHAT_FRAME:AddMessage("Roguedar "..RoguedarVersion.." is off, type \"/RD on\" to turn it on.", 0.0, 0.85, 0.0);
   end
   if RoguedarSound == 1 then
      DEFAULT_CHAT_FRAME:AddMessage("Roguedar Sound is on, type \"/RD soundoff\" to turn it off.", 0.0, 0.85, 0.0);
   else
      DEFAULT_CHAT_FRAME:AddMessage("Roguedar Sound is off, type \"/RD soundon\" to turn it on.", 0.0, 0.85, 0.0);
   end
   PlaySoundFile("Interface\\AddOns\\Roguedar\\ping.mp3");   
end -- local function ShowHelp()

function enabledisableroutine() -- update frame display

	if RoguedarEnabled == false then
		RDradartext:SetText("RD Disabled", 1, 0.25, 0);
	end
	
	if RoguedarEnabled == true then
		RDradartext:SetText("RD Enabled", 1, 0.25, 0);
	end
	
end

-- Slash command assignment.
function RoguedarCommand(command)
   local argc, argv = 0, {};
   gsub(command, "[^%s]+", function (word) argc=argc+1; argv[argc]=word; end);

   if (argc == 1) and (argv[1] == "help") then
      ShowHelp();
   elseif (argc == 1) and (argv[1] == "off") then
      DEFAULT_CHAT_FRAME:AddMessage("Roguedar "..RoguedarVersion.." is off, type \"/RD on\" to turn it on.", 0.0, 0.85, 0.0);
      RoguedarEnabled = false;
	  enabledisableroutine();
      RoguedarFrame:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
   elseif (argc == 1) and (argv[1] == "on") then
      DEFAULT_CHAT_FRAME:AddMessage("Roguedar "..RoguedarVersion.." is on, type \"/RD off\" to turn it off.", 0.0, 0.85, 0.0);
      RoguedarEnabled = true;
	  enabledisableroutine();
      RoguedarFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
   elseif (argc == 1) and (argv[1] == "debug") then
      DEFAULT_CHAT_FRAME:AddMessage("Roguedar "..RoguedarVersion.." debug is on, type \"/RD undebug\" to turn debugging off.", 0.0, 0.85, 0.0);
      Roguedar = true;
   elseif (argc == 1) and (argv[1] == "undebug") then
      DEFAULT_CHAT_FRAME:AddMessage("Roguedar "..RoguedarVersion.." debug is off, type \"/RD debug\" to turn debugging on.", 0.0, 0.85, 0.0);
      Roguedar = false;
   elseif (argc == 1) and (argv[1] == "move") then
  	--USERMESSAGE HANDLED IN FUNCTION
         Roguedarupdateframeposition();
   elseif (argc == 1) and (argv[1] == "soundon") then
	 DEFAULT_CHAT_FRAME:AddMessage("Roguedar Sound is on, type \"/RD soundoff\" to turn it off.", 0.0, 0.85, 0.0);
         RoguedarSound = 1;
   elseif (argc == 1) and (argv[1] == "soundoff") then
	 DEFAULT_CHAT_FRAME:AddMessage("Roguedar Sound is off, type \"/RD soundon\" to turn it on.", 0.0, 0.85, 0.0);
         RoguedarSound = 0;
   else
      ShowHelp();
   end
end -- function RoguedarCommand()

-- 
-- On load assignments.
--
function RoguedarOnLoad()

local colourintred = 0;
local colourintgreen = 0;
local colourintblue = 0;
local targetenemyflag = 0;
local selfnamefield = nil;
local dummyoutput = nil;
local sourcefaction = nil;
local selffaction = nil;
local spellisstealth = nil;
local inbattleground = nil;
local frameflashingflag = 0;
local getenemyvar1 = nil;
local getenemyvar2 = nil;
local getenemyvar3 = nil;
local mouseclickbutton = nil;
local warningTime = time();
--
local UNITFLAG_HOSTILEPC =  0x548;
--


   RoguedarVersion = "1.5";   -- Version number.

   --
   -- Register a command handler.
   -- 
   SlashCmdList["ROGUEDARCMD"] = RoguedarCommand;
   SLASH_ROGUEDARCMD1 = "/rd";
   SLASH_ROGUEDARCMD2 = "/roguedar";
   
   if RoguedarEnabled == nil then
      RoguedarEnabled = true;
   end

   if RoguedarDebug == nil then
      RoguedarDebug = false;
   end

   RoguedarFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");

   
  --Additional settings
  
  RDradartext:SetText("RD loaded", 1, 1, 1);

  	if RoguedarEnabled == false then
		RDradartext:SetText("RD Disabled", 1, 0.25, 0);
	end

   return;
end -- function RoguedarOnLoad()

--Update Frame Position function
function Roguedarupdateframeposition() -- redundant command used for testing only


RoguedarX, RoguedarY = GetCursorPosition();--

--RDradartext:SetText("WARNING", 1, 0.25, 0.25);

DEFAULT_CHAT_FRAME:AddMessage(UIFrameIsFading(RDradartext), 1, 1, 1);

DEFAULT_CHAT_FRAME:AddMessage("Roguedar Updating Position to x "..RoguedarX.." and y "..RoguedarY, 0.0, 0.85, 0.0);--Notify user of updating
end -- end function


-- 
-- Handle events registered
--
function RoguedarOnEvent(event, ...) 
   local timestamp, type, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags, spellId, spellName = select(1, ...)
   
	-- do nothing if disabled
	if RoguedarEnabled == false then
      return;
	end
   
	if (warningTime == nil) then
		warningTime = time();
	end
   
   
   if ((time() - warningTime) < 4) then
		return;
	end
   
   --pulser refresh
   	if (UIFrameIsFading(RDradartext) ~= 1) then
		if (frameflashingflag == 1) then
		frameflashingflag = 0;
		RDradartext:SetText("Scanning..", 0, 1, 0);
		RDbgimage:SetTexture(0, 0, 0, 0.5);
		end
	end
   
   --______________

   --
   -- Look for interesting SPELL_CAST_SUCCESS events.
   --
   if event == "COMBAT_LOG_EVENT_UNFILTERED" and type == "SPELL_CAST_SUCCESS" then
      --
      -- Enable for verbose logging. potential for spam
      --
      -- DEFAULT_CHAT_FRAME:AddMessage("".. spellId .." "..spellName.." " .. sourceName .. ".", 0.41, 0.8, 0.94);
--set color
	colourintred = 0.41;
	colourintgreen = 0.8;
	colourintblue = 0.94;
	targetenemyfactionflag = 0;
	
	-- Detect target hostility.
-- in battle detection has been removed till i can fix it. Hence the teb errors
	   selfnamefield = UnitName("player");
	   if (sourceName ~= selfnamefield) then --if not self
			if (bit.band(sourceFlags, 0x0040) == 0x0040) or (bit.band(sourceFlags, 0x0020) == 0x0020) then -- if hostile or neurtal ANTthing
                colourintred = 1; -- over ride out put color to red
                colourintgreen = 0.2;
                colourintblue = 0.2;
                targetenemyfactionflag = 1;
			end
		end

-- _________________________

spellisstealth = 0;
      --
      -- Detect Rogues casting Vanish.
      --
      if spellId == 1856 then 
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Vanish.", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      elseif spellId == 1857 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Vanish rank 2.", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      elseif spellId == 26889 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Vanish rank 3.", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      --
      -- Detect Rogues casting Stealth.
      --
     -- elseif spellId == 1784 then changed for 3.3
	  elseif spellId == 1784 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Stealth.", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      elseif spellId == 1785 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Stealth rank 2 (speed reduced by 40%).", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      elseif spellId == 1786 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Stealth rank 3 (speed reduced by 35%).", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      elseif spellId == 1787 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Stealth rank 4 (speed reduced by 30%).", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      --
      -- Detect Druids casting Prowl.
      --
      --elseif spellId == 5215 then
	  elseif spellId == 5215 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Prowl.", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      elseif spellId == 6783 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Prowl rank 2 (speed reduced by 35%).", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      elseif spellId == 9913 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Prowl rank 3 (speed reduced by 30%).", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      --
      -- Detect Night Elves casting Shadowmeld.
      --
      elseif spellId == 58984 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Shadowmeld.", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
	  --
	  -- Detect Hunter Camouflage
	  --
	  elseif spellId == 51753 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Camouflage.", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      --
      -- Detect Mages casting Invisibility.
      --
      elseif spellId == 66 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName.." cast Invisibility.", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      --
      -- Detect Invisibility potions.
      --
      elseif spellId == 3680 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName .. " used a Lesser Invisibility Potion (15 seconds).", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      elseif spellId == 11392 then
         DEFAULT_CHAT_FRAME:AddMessage(""..sourceName .. " used an Invisibility Potion (18 seconds).", colourintred, colourintgreen, colourintblue);
	spellisstealth = 1;
      else
	 return;
    end
    if (targetenemyfactionflag == 1) then -- if determined to be hostile
      if (spellisstealth == 1) then -- is spell iS a stealth spell
         DEFAULT_CHAT_FRAME:AddMessage("Hostile Stealth Detected!!!", 1, 0, 0); -- notify of Hostile stealth
		 -- update frame
		 RDradartext:SetText("WARNING", 1, 0.25, 0); 
		 frameflashingflag = 1;
		 UIFrameFlash(RDradartext, 0.25, 0.25, 3.75, 1, 0.5, 0.5);
		 RDbgimage:SetTexture(1, 0, 0, 0.5);
		 warningTime = time();
		 --frame --- 
         if RoguedarSound == 1 then --play sound
            PlaySoundFile("Interface\\AddOns\\Roguedar\\ping.mp3");     
	     --DEFAULT_CHAT_FRAME:AddMessage("SOUND WOULD PLAY!", 0.41, 0.8, 0.94); --Debug Line
         end
      end
   end
   end
end -- function RoguedarOnEvent()

function RoguedarOnRightMouseClick(mouseclickbutton)
	if mouseclickbutton == RightButton then
		DEFAULT_CHAT_FRAME:AddMessage("Menu not implemented yet.", 0.2, 0.2, 1);
	end
end -- function RoguedarOnRightMouseClick
