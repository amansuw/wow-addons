local name = ...
local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function(self, event, arg1)
	if arg1 == name then
		local r, g = "|cFFFF0000", "|cFF22FF22"
		if XLootMigrationWarned then
			print(("%s%s%s has also been moved into %sXLoot%s."):format(g, name, r, g, r))
		else
			print(("%s%s%s has been moved into %sXLoot%s, available on Curse or WoWInterface, sorry for the inconvenience!"):format(g, name, r, g, r))
			XLootMigrationWarned = true
		end
	end
end)