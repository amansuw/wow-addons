﻿if GetLocale() ~= "esES" then return end

AddonLoader.L = {
	explain = "Usted puede sobreescribir las condiciones de Addon Loader para cada Addon. Sobreescribir sólo se activa después de volver a cargar la Interfaz de Usuario. Addons en gris en la lista están usando actualmente sus condiciones de carga por defecto.",
	hideloading = "Ocultar Mensajes de Carga",
	reset = "Restablecer",
}
