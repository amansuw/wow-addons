Buffet is a simple water/food managing addon inspired by
[BaudConsumables](http://wow.curse.com/downloads/details/5827/) and
[Munchies](http://www.wowinterface.com/downloads/info8174-Munchies.html).

Unlike Baud and Munchies, Buffet does not swap items on the action bar (the
noise bothered me).  Instead it edits macros on the fly (out of combat) to
provide you with the best food, water, potions, stones, and bandages.

To make Buffet work, you must provide two macros, "AutoHP" and "AutoMP".  Drop
these on your action bar like any other macro, Buffet will change the macros as
needed to provide you with food and drink out of combat, potions and stones in
combat, and bandages on shift (HP macro only, of course).  Buffet will always
pick the smaller stack if equal-strength items are found.  Conjured items will
always be preferred over permanent ones.
