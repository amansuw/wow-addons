������������������������������������������������������������������������
Guild2Guild v8.1 - Maintained by jaxom of Hellfire (jaxomuk) jaxom@dragonsweyr.co.uk
Updated by �lvana of Zul'jin
Updated by Durthos of Proudmoore - dbeleznay@shaw.ca
Modified by Tassleoff
Originally by Elviso of Mug'Thol - elviso@kenman.net
������������������������������������������������������������������������
Enables communication between 2 or more guilds via a separate (private) chat channel, 
which translates the messages between the 2 or more guild chats. Two users are required 
to have this addon for it to work (1 in each guild), however only 1 user per guild is 
required to have Guild2Guild for all members of both guilds to reap the benefits. For 
example, guild chat from guild A will appear in guild B's guild chat, and vice-versa.

== Features ==
� Works for officer chat as well. You can enable either guild chat, officer chat, or both.
� Allows item linking
� Completely secure since the transmission channel is via in game whispers. The public
channel that you set is used for cross guild synchronization only
* You can set the add-on to be even more secure by limiting the guilds that you will
accept relays from (in case someone with the addon has characters in multiple guilds)
* forwards messages that other addons send to the guild addon channel
* unlike previous versions, more than two people from either guild can have the add-on 
running at once (in fact its encouraged for stability)
* Everyone with the addon will see the guild chat as though it came directly from the
person that sent the message. Clicking on their name will have all the same functionality
as the regular WOW UI.


== USAGE ==
To use Guild2Guild, just download and install like any other addon, and have a friend (in a
different guild) do the same. Then, decide upon a synchronization channel, and set both of
your G2G's to the same channel, like so:

/g2g channel relaychannel

Once the channel is set, simply enable G2G as such:

/g2g on

You should now be ready for intra-guild communications!

== GUILDMASTERS ==

You can limit the guilds that you can connect to using a white list, and automatically set 
the channel and password by adding a string like: 

<G2G;C:channel;P:secret;A:Guild1,Guild2;>

to your guild information (through the guild options menu). 
Where channel is the name of the channel you want guild2guild to use to coordinate relays, 
password is the password for that channel, and Guild1 and Guild2 are the names of two or more
guilds that you would like to allow to connect to this one.

(Password is optional, you don't need to use it if you don't want to have a password.)

Alternately you can create a custom build of guild2guild for your guild to use by editing the file
DefaultConfiguration.lua to use a new channel, and channel password, and then reposting this
add on to your guild website. 

Guild to Guild will automatically promote people that are allowed to speak in the officer 
channel to relays. This is so that the officer chat can be relayed as well.

== KNOWN BUGS ==
none

== Summary of in-game help commands ==

To view the usage of Guild2Guild:

  /g2g help

To turn this addon on or off:

  /g2g [on|off]

To turn guild chat on or off:

  /g2g gchat [on|off]

To turn officer chat on or off:

  /g2g ochat [on|off]
  
To turn relay change notification on or off:

  /g2g relaynotify [on|off]

To turn on passive mode (for slow connections - be the last person to be elected relay)

  /g2g passive [on|off]

To turn on silent mode (block all incoming messages from the allied guilds)

  /g2g silent [on|off]

To set or change the hidden synchronization channel used by this addon:

  /g2g channel [MY_CHANNEL]

To view your settings:

  /g2g report

(ADVANCED: If something really strange happens you can type /g2g stackdump which will take a 
snapshot of the last few minutes of guild2guild activity. If you mail me your guild2guild saved 
variables file when you log out then I will be better able to debug what went wrong.)

== ADDON LICENSE ==

You are free to copy, distribute, display, and perform these addons and to make derivative addons under the following conditions: 
--Attribution. You must attribute all add ons in the manner specified by Jaxom of Hellfire (Jaxomuk). 
--Noncommercial. You may not use these add ons for commercial purposes. 
--Share Alike. If you alter, transform, or build upon these add ons, you may distribute the resulting add on only under a license identical to this one. 
--For any reuse or distribution, you must make clear to others the license terms of these add ons. Any of these conditions can be waived if you get permission from Jaxom of Hellfire (Jaxomuk). Your fair use and other rights are in no way affected by the above.

== COPYRIGHT ==

All World or Warcraft game related content and images are the property of Blizzard Entertainment, Inc. and protected by U.S. and international copyright laws. The Addon (code and supporting files) is property of Durthos of Proudmoore and protected by U.S. and international copyright laws. 

