----------------------------------------
-- Group Calendar 5 Copyright 2009, 2010 John Stephen, wobbleworks.com
-- All rights reserved, unauthorized redistribution is prohibited
----------------------------------------

if GroupCalendar then
	error("You must disable previous versions of Group Calendar in order to run Group Calendar 5")
end

_, GroupCalendar = ...

GroupCalendar.DebugColorCode = "|cffcc88ff"
GroupCalendar.AddonPath = "Interface\\Addons\\"..select(1, ...).."\\"
GroupCalendar.UIElementsLibTexturePath = GroupCalendar.AddonPath
GroupCalendar.Debug = {}
GroupCalendar.Clock = {}

if not RAID_CLASS_COLOR_CODES then
	RAID_CLASS_COLOR_CODES = {}
	
	for vClassID, vColor in pairs(RAID_CLASS_COLORS) do
		RAID_CLASS_COLOR_CODES[vClassID] = string.format("|cff%02x%02x%02x", vColor.r * 255 + 0.5, vColor.g * 255 + 0.5, vColor.b * 255 + 0.5)
	end
end

MCAddon = GroupCalendar

function MCAddon:New(pMethodTable, ...)
	local vObject
	
	if type(pMethodTable) ~= "table" then
		error("table expected")
	end
	
	if pMethodTable.New then
		vObject = pMethodTable:New(...)
	else
		vObject = {}
	end
	
	vObject.Inherit = self.Inherit
	vObject.InheritOver = self.InheritOver
	
	vObject:InheritOver(pMethodTable, ...)
	
	return vObject
end

function MCAddon:InheritOver(pMethodTable, ...)
	for vKey, vValue in pairs(pMethodTable) do
		if self[vKey] then
			if not self.Inherited then
				self.Inherited = {}
			end
			
			self.Inherited[vKey] = self[vKey]
		end
		
		self[vKey] = vValue
	end
	
	if pMethodTable.Construct then
		pMethodTable.Construct(self, ...)
	end
end

function MCAddon:Inherit(pMethodTable, ...)
	for vKey, vValue in pairs(pMethodTable) do
		if self[vKey] then
			if not self.Inherited then
				self.Inherited = {}
			end
			
			if not self.Inherited[vKey] then
				self.Inherited[vKey] = vValue
			end
		else
			self[vKey] = vValue
		end
	end
	
	if pMethodTable.Construct then
		pMethodTable.Construct(self, ...)
	end
end

function MCAddon:DuplicateTable(pTable, pRecurse, pDestTable)
	if not pTable then
		return nil
	end
	
	local vTable
	
	if pDestTable then
		if type(pDestTable) ~= "table" then
			error("table expected for pDestTable")
		end
		
		vTable = pDestTable
	else
		vTable = {}
	end
	
	if pRecurse then
		for vKey, vValue in pairs(pTable) do
			if type(vValue) == "table" then
				vTable[vKey] = self:DuplicateTable(vValue, true)
			else
				vTable[vKey] = vValue
			end
		end
	else
		self:CopyTable(vTable, pTable)
	end
	
	return vTable
end

function MCAddon:CopyTable(pDestTable, pTable)
	for vKey, vValue in pairs(pTable) do
		pDestTable[vKey] = vValue
	end
end

function MCAddon:HookScript(pFrame, pScriptID, pFunction)
	if not pFrame:GetScript(pScriptID) then
		pFrame:SetScript(pScriptID, pFunction)
	else
		pFrame:HookScript(pScriptID, pFunction)
	end
end
