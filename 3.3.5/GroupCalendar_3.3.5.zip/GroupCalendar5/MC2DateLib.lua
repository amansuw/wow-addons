local Addon = MCAddon

MCAddon.DateLib =
{
	Version = 1,
	Addon = MCAddon,
	
	cDaysInMonth = {31, 28, 31, 30,  31,  30,  31,  31,  30,  31,  30,  31},
	cDaysToMonth = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365},
	cMinutesPerDay = 1440,
	cSecondsPerDay = 86400,
	ServerToLocalOffset = 0, -- Offset which, when added to the server time yields the local time
}

if GetLocale() == "enUS" then
	MCAddon.DateLib.cLongDateFormat = "$month $day, $year"
	MCAddon.DateLib.cShortDateFormat = "$monthNum/$day"
	MCAddon.DateLib.cLongDateFormatWithDayOfWeek = "$dow $month $day, $year"
else
	MCAddon.DateLib.cLongDateFormat = "$day. $month $year"
	MCAddon.DateLib.cShortDateFormat = "$day.$monthNum"
	MCAddon.DateLib.cLongDateFormatWithDayOfWeek = "$dow $day. $month $year"
end

MCAddon.DateLib.CALENDAR_MONTH_NAMES =
{
	MONTH_JANUARY,
	MONTH_FEBRUARY,
	MONTH_MARCH,
	MONTH_APRIL,
	MONTH_MAY,
	MONTH_JUNE,
	MONTH_JULY,
	MONTH_AUGUST,
	MONTH_SEPTEMBER,
	MONTH_OCTOBER,
	MONTH_NOVEMBER,
	MONTH_DECEMBER,
}

-- Month names show up differently for full date displays in some languages

MCAddon.DateLib.CALENDAR_FULLDATE_MONTH_NAMES =
{
	FULLDATE_MONTH_JANUARY,
	FULLDATE_MONTH_FEBRUARY,
	FULLDATE_MONTH_MARCH,
	FULLDATE_MONTH_APRIL,
	FULLDATE_MONTH_MAY,
	FULLDATE_MONTH_JUNE,
	FULLDATE_MONTH_JULY,
	FULLDATE_MONTH_AUGUST,
	FULLDATE_MONTH_SEPTEMBER,
	FULLDATE_MONTH_OCTOBER,
	FULLDATE_MONTH_NOVEMBER,
	FULLDATE_MONTH_DECEMBER,
}

MCAddon.DateLib.CALENDAR_WEEKDAY_NAMES =
{
	WEEKDAY_SUNDAY,
	WEEKDAY_MONDAY,
	WEEKDAY_TUESDAY,
	WEEKDAY_WEDNESDAY,
	WEEKDAY_THURSDAY,
	WEEKDAY_FRIDAY,
	WEEKDAY_SATURDAY,
}

----------------------------------------
-- Server date/time functions
----------------------------------------

function MCAddon.DateLib:GetServerTime()
	return self:ConvertHMToTime(GetGameTime())
end

function MCAddon.DateLib:GetServerDateTime()
	local _, vMonth, vDay, vYear = CalendarGetDate()
	
	if not vMonth or vMonth <= 0 then
		Addon:ErrorMessage("GetServerDateTime: CalendarGetDate() not ready")
		Addon:DebugStack()
		return
	end
	
	return self:ConvertMDYToDate(vMonth, vDay, vYear), self:GetServerTime(), vMonth, vDay, vYear
end

function MCAddon.DateLib:GetServerDateTime60()
	return self:GetServerDateTime60FromLocalDateTime60(self:GetLocalDateTime60())
end

function MCAddon.DateLib:GetServerDateTimeStamp()
	local vDate, vTime60 = self:GetServerDateTime60()
	
	return vDate * self.cSecondsPerDay + vTime60
end

function MCAddon.DateLib:GetServerMonthOffsetDate(pDate)
	local vMonth, vDay, vYear = ConvertDateToMDY(pDate)
	local _, vCurrentMonth, vCurrentDay, vCurrentYear = CalendarGetDate()
	
	return vMonth - vCurrentMonth, vDay
end

----------------------------------------
-- local date/time functions
----------------------------------------

function MCAddon.DateLib:GetLocalTime()
	local vDate = date("*t")
	
	return self:ConvertHMToTime(vDate.hour, vDate.min)
end

function MCAddon.DateLib:GetLocalMDY()
	local vDate = date("*t")
	
	return vDate.month, vDate.day, vDate.year
end

function MCAddon.DateLib:GetLocalDate()
	return self:ConvertMDYToDate(self:GetLocalMDY())
end

function MCAddon.DateLib:GetLocalDateTime()
	local vDate = date("*t")
	
	return self:ConvertMDYToDate(vDate.month, vDate.day, vDate.year), self:ConvertHMToTime(vDate.hour, vDate.min)
end

function MCAddon.DateLib:GetLocalYMDHMS()
	local vDate = date("*t")
	
	return vDate.year, vDate.month, vDate.day, vDate.hour, vDate.min, vDate.sec
end

function MCAddon.DateLib:GetLocalDateTime60()
	local vDate = date("*t")
	
	return self:ConvertMDYToDate(vDate.month, vDate.day, vDate.year), self:ConvertHMSToTime60(vDate.hour, vDate.min, vDate.sec)
end

function MCAddon.DateLib:GetLocalDateTimeStamp()
	local vDate, vTime60 = self:GetLocalDateTime60()
	
	return vDate * self.cSecondsPerDay + vTime60
end

----------------------------------------
-- UTC date/time functions
----------------------------------------

function MCAddon.DateLib:GetUTCTime()
	local vDate = date("!*t")
	
	return self:ConvertHMToTime(vDate.hour, vDate.min)
end

function MCAddon.DateLib:GetUTCDateTime()
	local vDate = date("!*t")
	
	return self:ConvertMDYToDate(vDate.month, vDate.day, vDate.year), self:ConvertHMToTime(vDate.hour, vDate.min)
end

function MCAddon.DateLib:GetUTCDateTime60()
	local vDate = date("!*t")
	
	return self:ConvertMDYToDate(vDate.month, vDate.day, vDate.year), self:ConvertHMSToTime60(vDate.hour, vDate.min, vDate.sec)
end

function MCAddon.DateLib:GetUTCDateTimeStamp()
	local vDate, vTime60 = self:GetUTCDateTime60()
	
	return vDate * self.cSecondsPerDay + vTime60
end

----------------------------------------
-- Time zone conversions
----------------------------------------

function MCAddon.DateLib:GetLocalTimeFromServerTime(pServerTime)
	if not pServerTime then
		return nil
	end
	
	local vLocalTime = pServerTime + self:GetServerToLocalOffset()

	if vLocalTime < 0 then
		vLocalTime = vLocalTime + self.cMinutesPerDay
	elseif vLocalTime >= self.cMinutesPerDay then
		vLocalTime = vLocalTime - self.cMinutesPerDay
	end
	
	return vLocalTime
end

function MCAddon.DateLib:GetServerTimeFromLocalTime(pLocalTime)
	local vServerTime = pLocalTime - self:GetServerToLocalOffset()

	if vServerTime < 0 then
		vServerTime = vServerTime + self.cMinutesPerDay
	elseif vServerTime >= self.cMinutesPerDay then
		vServerTime = vServerTime - self.cMinutesPerDay
	end
	
	return vServerTime
end

function MCAddon.DateLib:GetLocalDateTimeFromServerDateTime(pServerDate, pServerTime)
	if not pServerTime then
		return pServerDate, nil
	end
	
	local vLocalTime = pServerTime + self:GetServerToLocalOffset()
	local vLocalDate = pServerDate
	
	if vLocalTime < 0 then
		vLocalTime = vLocalTime + self.cMinutesPerDay
		vLocalDate = vLocalDate - 1
	elseif vLocalTime >= self.cMinutesPerDay then
		vLocalTime = vLocalTime - self.cMinutesPerDay
		vLocalDate = vLocalDate + 1
	end
	
	return vLocalDate, vLocalTime
end

function MCAddon.DateLib:GetServerDateTimeFromLocalDateTime(pLocalDate, pLocalTime)
	if not pLocalTime then
		return pLocalDate, nil
	end
	
	local vServerTime = pLocalTime - self:GetServerToLocalOffset()
	local vServerDate = pLocalDate
	
	if vServerTime < 0 then
		vServerTime = vServerTime + self.cMinutesPerDay
		vServerDate = vServerDate - 1
	elseif vServerTime >= self.cMinutesPerDay then
		vServerTime = vServerTime - self.cMinutesPerDay
		vServerDate = vServerDate + 1
	end
	
	return vServerDate, vServerTime
end

function MCAddon.DateLib:GetServerDateTime60FromLocalDateTime60(pLocalDate, pLocalTime60)
	if not pLocalTime60 then
		return pLocalDate, nil
	end
	
	local vServerTime60 = pLocalTime60 - self:GetServerToLocalOffset() * 60
	local vServerDate = pLocalDate
	
	if vServerTime60 < 0 then
		vServerTime60 = vServerTime60 + self.cSecondsPerDay
		vServerDate = vServerDate - 1
	elseif vServerTime60 >= self.cSecondsPerDay then
		vServerTime60 = vServerTime60 - self.cSecondsPerDay
		vServerDate = vServerDate + 1
	end
	
	return vServerDate, vServerTime60
end

function MCAddon.DateLib:AddOffsetToDateTime(pDate, pTime, pOffset)
	local vDateTime = pDate * self.cMinutesPerDay + pTime + pOffset
	
	return math.floor(vDateTime / self.cMinutesPerDay), math.fmod(vDateTime, self.cMinutesPerDay)
end

function MCAddon.DateLib:AddOffsetToDateTime60(pDate, pTime60, pOffset60)
	local vDateTime60 = pDate *  self.cSecondsPerDay + pTime60 + pOffset60
	
	return math.floor(vDateTime60 / self.cSecondsPerDay), math.fmod(vDateTime60, self.cSecondsPerDay)
end

function MCAddon.DateLib:GetServerDateTimeFromSecondsOffset(pSeconds)
	-- Calculate the local date and time of the reset (this is done in
	-- local date/time since it has a higher resolution)

	local vLocalDate, vLocalTime60 = self:GetLocalDateTime60()
	
	vLocalDate, vLocalTime60 = self:AddOffsetToDateTime60(vLocalDate, vLocalTime60, pSeconds)
	
	local vLocalTime = math.floor(vLocalTime60 / 60)

	-- Convert to server date/time

	return self:GetServerDateTimeFromLocalDateTime(vLocalDate, vLocalTime)
end

----------------------------------------
----------------------------------------

function MCAddon.DateLib:GetDateTimeFromTimeStamp(pTimeStamp)
	return math.floor(pTimeStamp / self.cSecondsPerDay), math.floor(math.fmod(pTimeStamp, self.cSecondsPerDay) / 60)
end

function MCAddon.DateLib:GetShortTimeString(pTime)
	if pTime == nil then
		return nil
	end
	
	if GetCVarBool("timeMgrUseMilitaryTime") then
		local vHour, vMinute = self:ConvertTimeToHM(pTime)
		
		return format(TEXT(TIME_TWENTYFOURHOURS), vHour, vMinute)
	else
		local vHour, vMinute, vAMPM = self:ConvertTimeToHMAMPM(pTime)
		
		if vAMPM == 0 then
			return format(TEXT(TIME_TWELVEHOURAM), vHour, vMinute)
		else
			return format(TEXT(TIME_TWELVEHOURPM), vHour, vMinute)
		end
	end
end

function MCAddon.DateLib:ConvertTimeToHM(pTime)
	if not pTime then
		return
	end
	
	local vMinute = math.fmod(pTime, 60)
	local vHour = math.floor((pTime - vMinute) / 60 + 0.5)
	
	return vHour, vMinute
end

function MCAddon.DateLib:ConvertTime60ToHMS(pTime60)
	if not pTime60 then
		return
	end
	
	local vSecond = math.fmod(pTime60, 60)
	local vHourMinute = math.floor((pTime60 - vSecond) / 60 + 0.5)
	local vMinute = math.fmod(vHourMinute, 60)
	local vHour = math.floor((vHourMinute - vMinute) / 60 + 0.5)
	
	return vHour, vMinute, vSecond
end

function MCAddon.DateLib:ConvertHMToTime(pHour, pMinute)
	if not pHour
	or not pMinute then
		return
	end
	
	return pHour * 60 + pMinute
end

function MCAddon.DateLib:ConvertHMSToTime60(pHour, pMinute, pSecond)
	return pHour * 3600 + pMinute * 60 + pSecond
end

function MCAddon.DateLib:ConvertTimeToHMAMPM(pTime)
	local vHour, vMinute = self:ConvertTimeToHM(pTime)
	local vAMPM
	
	if vHour < 12 then
		vAMPM = 0
		
		if vHour == 0 then
			vHour = 12
		end
	else
		vAMPM = 1

		if vHour > 12 then
			vHour = vHour - 12
		end
	end

	return vHour, vMinute, vAMPM
end

function MCAddon.DateLib:ConvertHMAMPMToTime(pHour, pMinute, pAMPM)
	local vHour
	
	if pAMPM == 0 then
		vHour = pHour
		if vHour == 12 then
			vHour = 0
		end
	else
		vHour = pHour + 12
		if vHour == 24 then
			vHour = 12
		end
	end
	
	return self:ConvertHMToTime(vHour, pMinute)
end

----------------------------------------
-- Date/time string conversion
----------------------------------------

function MCAddon.DateLib:GetLongDateString(pDate, pIncludeDayOfWeek)
	if not pDate then	
		return
	end
	
	local vFormat
	
	if pIncludeDayOfWeek then
		vFormat = self.cLongDateFormatWithDayOfWeek
	else
		vFormat = self.cLongDateFormat
	end
	
	return self:GetFormattedDateString(pDate, vFormat)
end

function MCAddon.DateLib:GetShortDateString(pDate, pIncludeDayOfWeek)
	if not pDate then	
		return
	end
	
	return self:GetFormattedDateString(pDate, self.cShortDateFormat)
end

function MCAddon.DateLib:FormatNamed(pFormat, pFields)
	return string.gsub(pFormat, "%$(%w+)", pFields)
end

function MCAddon.DateLib:GetFormattedDateString(pDate, pFormat)
	local vMonth, vDay, vYear = self:ConvertDateToMDY(pDate)
	
	local vDate =
			{
				dow = self.CALENDAR_WEEKDAY_NAMES[self:GetDayOfWeekFromDate(pDate) + 1],
				month = self.CALENDAR_MONTH_NAMES[vMonth],
				monthNum = vMonth,
				day = vDay,
				year = vYear,
			}
	
	return self:FormatNamed(pFormat, vDate)
end

----------------------------------------
-- Time zone estimation
----------------------------------------

function MCAddon.DateLib:CalculateTimeZoneOffset()
	local vServerDate, vServerTime = self:GetServerDateTime()
	local vLocalDate, vLocalTime = self:GetLocalDateTime()
	local vUTCDate, vUTCTime = self:GetUTCDateTime()
	
	local vLocalDateTime = vLocalDate * 1440 + vLocalTime
	local vServerDateTime = vServerDate * 1440 + vServerTime
	local vUTCDateTime = vUTCDate * 1440 + vUTCTime
	
	local vServerToLocalOffset = self:RoundTimeOffsetToNearest30(vLocalDateTime - vServerDateTime)
	
	self.ServerUTCOffset = self:RoundTimeOffsetToNearest30(vUTCDateTime - vServerDateTime)
	
	if vServerToLocalOffset ~= self.ServerToLocalOffset then
		self.ServerToLocalOffset = vServerToLocalOffset
		Addon.EventLib:DispatchEvent("SERVER_TIME_OFFSET_CHANGED")
	end
end

function MCAddon.DateLib:GetServerToLocalOffset()
	if not self.DidCalculateZoneOffset then
		self.DidCalculateZoneOffset = true
		self:CalculateTimeZoneOffset()
	end
	
	return self.ServerToLocalOffset
end

function MCAddon.DateLib:GetServerUTCOffset()
	if not self.DidCalculateZoneOffset then
		self.DidCalculateZoneOffset = true
		self:CalculateTimeZoneOffset()
	end
	
	return self.ServerUTCOffset
end

function MCAddon.DateLib:RoundTimeOffsetToNearest30(pOffset)
	local vNegativeOffset
	local vOffset
	
	if pOffset < 0 then
		vNegativeOffset = true
		vOffset = -pOffset
	else
		vNegativeOffset = false
		vOffset = pOffset
	end
	
	vOffset = vOffset - (math.fmod(vOffset + 15, 30) - 15)
	
	if vNegativeOffset then
		return -vOffset
	else
		return vOffset
	end
end

----------------------------------------
-- Date properties
----------------------------------------

function MCAddon.DateLib:GetDaysInMonth(pMonth, pYear)
	if not pMonth
	or not pYear then
		return
	end
	
	if pMonth == 2 and self:IsLeapYear(pYear) then
		return self.cDaysInMonth[pMonth] + 1
	else
		return self.cDaysInMonth[pMonth]
	end
end

function MCAddon.DateLib:GetDaysToMonth(pMonth, pYear)
	if pMonth > 2 and self:IsLeapYear(pYear) then
		return self.cDaysToMonth[pMonth] + 1
	elseif pMonth == 2 then
		return self.cDaysToMonth[pMonth]
	else
		return 0
	end
end

function MCAddon.DateLib:GetDaysInYear(pYear)
	if self:IsLeapYear(pYear) then
		return 366
	else
		return 365
	end
end

function MCAddon.DateLib:IsLeapYear(pYear)
	return (math.fmod(pYear, 400) == 0)
	   or ((math.fmod(pYear, 4) == 0) and (math.fmod(pYear, 100) ~= 0))
end

function MCAddon.DateLib:GetDaysToDate(pMonth, pDay, pYear)
	local vDays
	
	vDays = self.cDaysToMonth[pMonth] + pDay - 1
	
	if self:IsLeapYear(pYear) and pMonth > 2 then
		vDays = vDays + 1
	end
	
	return vDays
end

function MCAddon.DateLib:ConvertMDYToDate(pMonth, pDay, pYear)
	if not pMonth or not pDay or not pYear then
		return
	end
	
	local vDays = 0
	
	for vYear = 2000, pYear - 1 do
		vDays = vDays + self:GetDaysInYear(vYear)
	end
	
	return vDays + self:GetDaysToDate(pMonth, pDay, pYear)
end

function MCAddon.DateLib:ConvertDateToMDY(pDate)
	if not pDate then
		return nil
	end
	
	local vDays = pDate
	local vYear = 2000
	local vDaysInYear = self:GetDaysInYear(vYear)
	
	while vDays >= vDaysInYear do
		vDays = vDays - vDaysInYear

		vYear = vYear + 1
		vDaysInYear = self:GetDaysInYear(vYear)
	end
	
	local vIsLeapYear = self:IsLeapYear(vYear)
	
	for vMonth = 1, 12 do
		local vDaysInMonth = self.cDaysInMonth[vMonth]
		
		if vMonth == 2 and vIsLeapYear then
			vDaysInMonth = vDaysInMonth + 1
		end
		
		if vDays < vDaysInMonth then
			return vMonth, vDays + 1, vYear
		end
		
		vDays = vDays - vDaysInMonth
	end
	
	return 0, 0, 0
end

function MCAddon.DateLib:GetDayOfWeek(pMonth, pDay, pYear)
	local vDayOfWeek = 6 -- January 1, 2000 is a Saturday
	
	for vYear = 2000, pYear - 1 do
		if self:IsLeapYear(vYear) then
			vDayOfWeek = vDayOfWeek + 2
		else
			vDayOfWeek = vDayOfWeek + 1
		end
	end
	
	vDayOfWeek = vDayOfWeek + self:GetDaysToDate(pMonth, pDay, pYear)
	
	return math.fmod(vDayOfWeek, 7)
end

function MCAddon.DateLib:GetDayOfWeekFromDate(pDate)
	return math.fmod(pDate + 6, 7);  -- + 6 because January 1, 2000 is a Saturday
end

function MCAddon.DateLib:CompareMDY(pMonth1, pDay1, pYear1, pMonth2, pDay2, pYear2)
	if not pYear1 then
		return false, not pYear2
	elseif not pYear2 then
		return true
	end
	
	if pYear1 < pYear2 then
		return true
	elseif pYear1 > pYear2 then
		return false
	end
	
	if pMonth1 < pMonth2 then
		return true
	elseif pMonth1 > pMonth2 then
		return false
	end
	
	if pDay1 < pDay2 then
		return true
	elseif pDay1 > pDay2 then
		return false
	end
	
	-- They're equal
	
	return false, true
end

function MCAddon.DateLib:CompareHM(pHour1, pMinute1, pHour2, pMinute2)
	if not pHour1 then
		return false, not pHour2
	elseif not pHour2 then
		return true
	end
	
	if pHour1 < pHour2 then
		return true
	elseif pHour1 > pHour2 then
		return false
	end
	
	if pMinute1 < pMinute2 then
		return true
	elseif pMinute1 > pMinute2 then
		return false
	end
	
	-- They're equal
	
	return false, true
end

function MCAddon.DateLib:CompareMDYHM(pMonth1, pDay1, pYear1, pHour1, pMinute1, pMonth2, pDay2, pYear2, pHour2, pMinute2)
	local vLess, vEqual = self:CompareMDY(pMonth1, pDay1, pYear1, pMonth2, pDay2, pYear2)
	
	if not vEqual then
		return vLess
	end
	
	return self:CompareHM(pHour1, pMinute1, pHour2, pMinute2)
end

function MCAddon.DateLib:CompareDateTime(pDate1, pTime1, pDate2, pTime2)
	if not pDate1 then
		return false, not pDate2
	elseif not pDate2 then
		return true
	end
	
	if pDate1 < pDate2 then
		return true
	elseif pDate1 > pDate2 then
		return false
	end
	
	if not pTime1 then
		return false, not pTime2
	elseif not pTime2 then
		return true
	end
	
	if pTime1 < pTime2 then
		return true
	elseif pTime1 > pTime2 then
		return false
	end
	
	-- They're equal
	
	return false, true
end