L["+Combat"] = true
L["-Combat"] = true
L["Combat status"] = true
L["Enter combat"] = true
L["In combat"] = true
L["Leave combat"] = true
L["Not in combat"] = true
