----------------------------------------
-- Group Calendar 5 Copyright 2005 - 2011 John Stephen, wobbleworks.com
-- All rights reserved, unauthorized redistribution is prohibited
----------------------------------------

GroupCalendar.Cooldowns = {}

