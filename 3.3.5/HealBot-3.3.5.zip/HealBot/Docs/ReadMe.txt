** HealBot Continued **

Latest Download from WoWInterface:  http://www.wowinterface.com/downloads/download6096-HealBotcontinued


Installing and Updating
=======================

1: Completely log off WoW
2: Copy the folders into your WoW Addons folder.
3: Logon to WoW on your main Healer.
4: As a priority you should open the options and configure spells, cures and buffs.


Updating Troubles
=================

***** If you get nil errors after updating *****

1: Completely log off WoW
2: Run the Reset_HealBot.bat file in the Healbot addon folder, this clears old saved Healbot settings from your WTF folder.
3: Logon to WoW on your main Healer.
4: As a priority you should open the options and configure spells, cures and buffs.


---------------
- The Folders -
---------------

Copy the folders into you Addons directory.
==========================================

Healbot                     = This is the main addon
TitanHealBot                = This is a plugin for the Titan bar addon, TitanHealBot is an optional plugin for people who use Titan.



Recommended Additions
=====================
SharedMedia                 = This addon is designed to be used by addons, it gives additional textures, fonts and sounds. This addon is recommended.
SharedMediaAdditionalFonts  = This addon can be used with SharedMedia to gives additional fonts. This addon is recommended.

http://wow.curse.com/downloads/wow-addons/details/sharedmedia.aspx
http://wow.curse.com/downloads/wow-addons/SearchResults.aspx?q=SharedMediaAdditionalFonts

